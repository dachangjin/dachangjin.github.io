//
//  TMFStatisticsReporter+Custom.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Custom)

- (void)et3_CUSTOM_EventWithHybridH5:(BOOL)hybridH5 eventID:(NSString *)eventID props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

- (void)et3_CUSTOM_EventWithHybridH5:(BOOL)hybridH5 eventID:(NSString *)eventID props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels duration:(NSInteger)duration configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

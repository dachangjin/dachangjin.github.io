//
//  TMFWebOfflineHandler.h
//  Pods
//
//  Created by klaudz on 20/4/2019.
//

#import <Foundation/Foundation.h>
#import "TMFWebOfflineWebViewControllerProtocol.h"

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 离线包网络请求处理器，负责获取URL，处理请求转发等操作
 */
@interface TMFWebOfflineHandler : NSObject

/**
 @brief 初始化离线包处理器
 
 @param webViewController webView容器实例
 @return 离线包处理器实例
 */
- (instancetype)initWithWebViewController:(UIViewController<TMFWebOfflineWebViewControllerProtocol> *)webViewController;

/**
 @brief 实现离线包webView容器协议 `TMFWebOfflineWebViewControllerProtocol` 的webView容器实例
 */
@property (nonatomic, assign, nullable, readonly) UIViewController<TMFWebOfflineWebViewControllerProtocol> *webViewController;

/**
 @brief webView处理器的清理工作
 */
- (void)clearWebViewController;

/**
 @brief 获得最终需要 WebView 加载访问的离线包 URL。
 
 @param URL 访问的原始URL
 @return 返回最终访问的URL
 @note 如果 `TMFWebOfflineService.fallbackEnabled` 设置为 `YES`，fallback 功能被开启。
    此方法会判断 URL 对应的离线包是否已经下载完成，如果未下载完成，将会返回该离线包的 fallbackURL。
 */
- (NSURL *)determinedURLWithURL:(NSURL *)URL;

/**
 @brief 处理WebView的加载请求
 
 @param request webView的请求
 */
- (void)handleRequest:(NSURLRequest *)request;

@end

NS_ASSUME_NONNULL_END

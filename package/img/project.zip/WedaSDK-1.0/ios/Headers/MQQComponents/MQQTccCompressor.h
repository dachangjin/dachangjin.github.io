//
//  MQQTccCompressor.h
//  MQQComponents
//
//  Created by klaudz on 29/10/2019.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT
NSErrorDomain const MQQTccCompressorErrorDomain;

@interface MQQTccCompressor : NSObject

+ (nullable NSData *)compressData:(NSData *)data error:(NSError * _Nullable * _Nullable)error;

+ (nullable NSData *)decompressData:(NSData *)data error:(NSError * _Nullable * _Nullable)error;

@end

NS_ASSUME_NONNULL_END

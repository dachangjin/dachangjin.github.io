//
//  MQQObjcEncryption.h
//  MQQSecure
//
//  Created by klaudz on 5/18/15.
//  Copyright (c) 2015 Tencent. All rights reserved.
//

#ifndef MQQObjcEncryption
#define MQQObjcEncryption


// 加解密GetClass、GetSelector方法，默认不变
#define MQQEGetClass(class)				objc_getClass(class)
#define MQQEGetSelector(selector)			sel_registerName(selector)
#define MQQDGetClass(encryptString) ({	\
    char* decryptString = MQQDC(encryptString);	\
    Class decryptClass = objc_getClass(decryptString);	\
    if (decryptString != NULL) { free(decryptString); decryptString = NULL; }	\
    decryptClass;	\
})
#define MQQDGetSelector(encryptString) ({	\
    char* decryptString = MQQDC(encryptString);	\
    SEL decryptSEL = sel_registerName(decryptString);	\
    if (decryptString != NULL) { free(decryptString); decryptString = NULL; }	\
    decryptSEL;	\
})

// 解密算法
#define XOR_KEY         64          // 异或Key值
#define XOR_INTEVAL     2173        // 异或偏移值
#define SEC_INTEVAL_1   1
#define SEC_INTEVAL_2   4
#define SEC_INTEVAL_3   2
#define SEC_INTEVAL_4   3
#define MQQDC(originCString)    ({	\
    size_t originCStringLength = strlen(originCString);	\
    char *targetCString = (char *)malloc(sizeof(char) * (originCStringLength + 1));	\
    memset(targetCString, 0, sizeof(char) * (originCStringLength + 1));	\
    size_t targetLength = 0;	\
    for (int index = 2; index < originCStringLength; index += 8) {	\
        unsigned int tempInt = (originCString[index] - '0') * 1000 + (originCString[index + 1]  - '0') * 100 + (originCString[index + 2] - '0') * 10 + (originCString[index + 3] - '0');	\
        targetCString[targetLength] = (tempInt ^ XOR_KEY) - XOR_INTEVAL;	\
        targetLength++;	\
    }	\
    size_t finalCStringLength = strlen(targetCString);	\
    char *finalCString = (char *)malloc(sizeof(char) * (finalCStringLength + 1));	\
    memset(finalCString, 0, sizeof(char) * (finalCStringLength + 1));	\
    for (int index = 0; index < finalCStringLength; index++) {	\
        unsigned char temp = targetCString[index];	\
        switch (index % 8) {	\
            case 0:	\
            case 4:	\
                finalCString[index] = temp - SEC_INTEVAL_1;	\
                break;	\
            case 1:	\
            case 7:	\
                finalCString[index] = temp - SEC_INTEVAL_2;	\
                break;	\
            case 2:	\
            case 6:	\
                finalCString[index] = temp - SEC_INTEVAL_3;	\
                break;	\
            case 3:	\
            case 5:	\
                finalCString[index] = temp - SEC_INTEVAL_4;	\
                break;	\
            default:	\
                break;	\
        }	\
    }	\
    free(targetCString); targetCString = NULL; \
    finalCString;	\
})	


#endif

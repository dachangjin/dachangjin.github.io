//
//  WKWebViewMessageHandler.h
//  weapps
//
//  Created by tommywwang on 2020/5/28.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WKWebViewMessageHandler : NSObject <WKScriptMessageHandler>

@end

NS_ASSUME_NONNULL_END

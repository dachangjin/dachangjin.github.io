//
//  TMFStatisticsHandler.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "TMFStatisticsConfiguration.h"
#import "TMFStatisticsViewControllerProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsHandler : NSObject

/**
 @brief 在 ViewController 创建时，做必要的初始化工作
*/
- (instancetype)initWithViewController:(UIViewController<TMFStatisticsViewControllerProtocol> *)viewController configuration:(nullable TMFStatisticsConfiguration *)configuration;

@property (nonatomic, assign, nullable, readonly) UIViewController<TMFStatisticsViewControllerProtocol> *viewController;

/**
 @brief 上报配置，仅作用于当前 TMFStatisticsHandler
*/
@property (nonatomic, copy, nullable, readonly) TMFStatisticsConfiguration *configuration;

/**
 @brief 用户标签，仅透传
*/
@property (nonatomic, copy, nullable) NSDictionary *lables;

/**
 @brief 在 ViewController 析构时，做必要的清理工作
*/
- (void)clearViewController;

/**
 @brief 在 ViewController 视图将要呈现时开始停留时长统计
*/
- (void)viewWillApper;

/**
 @brief 在 ViewController 视图消失时结束停留时长统计
*/
- (void)viewDidDisappear;

@end

@interface TMFStatisticsHandler (WebView)

/**
 @brief 判断组件能否处理WebView的网络请求
 @return 是否可以处理WebView的请求。YES，表明可处理，NO，表明不处理。
*/
- (BOOL)canHandleURL:(NSURL *)URL;

/**
 @brief 将WebView的网络请求转给组件
*/
- (void)handleURL:(NSURL *)URL;

/**
 @brief 统计WebView的加载结束
 @note 在 `-webView:didFinishNavigation:` 中调用
 @param webView 被统计的WebView对象
*/
- (void)handleFinishNavigation:(null_unspecified WKNavigation *)navigation fromWKWebView:(WKWebView *)webView;

@end

NS_ASSUME_NONNULL_END

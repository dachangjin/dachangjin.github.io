//
//  TMFStatisticsReporter+Strategy.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/28.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"
#import "TMFStatisticsReporter+Private.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Strategy)

- (void)configureStrategy;

- (void)destroyReportTimer;

- (void)reportWithDataFileds:(NSMutableDictionary<NSNumber *, NSString *> *)fileds configuration:(TMFStatisticsConfiguration *)configuration;

- (void)remainingCheck;

@end

NS_ASSUME_NONNULL_END

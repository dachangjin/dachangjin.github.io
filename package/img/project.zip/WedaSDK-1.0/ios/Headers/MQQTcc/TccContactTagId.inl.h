/*
 * TccContactsMgrTagId.inl
 *
 *  Created on: 2010-1-26
 *      Author: superguo
 */




/**
List of Content Types in Template's ContactItemFieldSet
Index  Title  Mapping (Hex)  Mapping UID  Field Types (Hex)        Field Types
00  Title			0x1000402e  KUidContactFieldVCardMapUnusedN  0x1000178c        KUidContactFieldPrefixName
01  First name		0x1000402e  KUidContactFieldVCardMapUnusedN  0x1000137c        KUidContactFieldGivenName
02  Middle name		0x1000402e  KUidContactFieldVCardMapUnusedN  0x1000178a        KUidContactFieldAdditionalName
03  Last name		0x1000402e  KUidContactFieldVCardMapUnusedN  0x1000137d        KUidContactFieldFamilyName
04  Suffix			0x1000402e  KUidContactFieldVCardMapUnusedN  0x1000178b        KUidContactFieldSuffixName
05  Mobile			0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x100039db  0x10003e71  KUidContactFieldPhoneNumber  KUidContactFieldVCardMapHOME  KUidContactFieldVCardMapCELL
06  Home tel		0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x100039db     KUidContactFieldPhoneNumber  KUidContactFieldVCardMapHOME
07  Home fax		0x1000402a  KUidContactFieldVCardMapTEL  0x10001791  0x100039db  0x100039de  KUidContactFieldFax  KUidContactFieldVCardMapHOME  KUidContactFieldVCardMapFAX
08  Pager			0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x10003e72  0x100039db  KUidContactFieldPhoneNumber  KUidContactFieldVCardMapPAGER  KUidContactFieldVCardMapHOME
09  Home email		0x10004020  KUidContactFieldVCardMapEMAILINTERNET  0x1000178e  0x100039db     KUidContactFieldEMail  KUidContactFieldVCardMapHOME
10  Home PO box		0x10004dea  KUidContactFieldVCardMapPOSTOFFICE  0x10004df4  0x100039db     KUidContactFieldPostOffice  KUidContactFieldVCardMapHOME
11  Home ex address	0x10004deb  KUidContactFieldVCardMapEXTENDEDADR  0x10004df5  0x100039db     KUidContactFieldExtendedAddress  KUidContactFieldVCardMapHOME
12  Home address	0x1000401d  KUidContactFieldVCardMapADR  0x1000130c  0x100039db     KUidContactFieldAddress  KUidContactFieldVCardMapHOME
13  Home city		0x10004dec  KUidContactFieldVCardMapLOCALITY  0x10004df6  0x100039db     KUidContactFieldLocality  KUidContactFieldVCardMapHOME
14  Home region		0x10004ded  KUidContactFieldVCardMapREGION  0x10004df7  0x100039db     KUidContactFieldRegion  KUidContactFieldVCardMapHOME
15  Home p'code		0x10004dee  KUidContactFieldVCardMapPOSTCODE  0x10004df8  0x100039db     KUidContactFieldPostcode  KUidContactFieldVCardMapHOME
16  Home country	0x10004def  KUidContactFieldVCardMapCOUNTRY  0x10004df9  0x100039db     KUidContactFieldCountry  KUidContactFieldVCardMapHOME
17  Company			0x10004026  KUidContactFieldVCardMapORG  0x1000130d        KUidContactFieldCompanyName
18  Job title		0x1000402c  KUidContactFieldVCardMapTITLE
19  Work mobile		0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x10003e71  0x100039da  KUidContactFieldPhoneNumber  KUidContactFieldVCardMapCELL  KUidContactFieldVCardMapWORK
20  Work tel		0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x100039da     KUidContactFieldPhoneNumber  KUidContactFieldVCardMapWORK
21  Work fax		0x1000402a  KUidContactFieldVCardMapTEL  0x10001791  0x100039da  0x100039de  KUidContactFieldFax  KUidContactFieldVCardMapWORK  KUidContactFieldVCardMapFAX
22  Work pager		0x1000402a  KUidContactFieldVCardMapTEL  0x1000130e  0x10003e72  0x100039da  KUidContactFieldPhoneNumber  KUidContactFieldVCardMapPAGER  KUidContactFieldVCardMapWORK
23  Work email		0x10004020  KUidContactFieldVCardMapEMAILINTERNET  0x1000178e  0x100039da     KUidContactFieldEMail  KUidContactFieldVCardMapWORK
24  Web page		0x1000402d  KUidContactFieldVCardMapURL  0x10004035        KUidContactFieldUrl
25  Work PO box		0x10004dea  KUidContactFieldVCardMapPOSTOFFICE  0x10004df4  0x100039da     KUidContactFieldPostOffice  KUidContactFieldVCardMapWORK
26  Work ex address	0x10004deb  KUidContactFieldVCardMapEXTENDEDADR  0x10004df5  0x100039da     KUidContactFieldExtendedAddress  KUidContactFieldVCardMapWORK
27  Work address	0x1000401d  KUidContactFieldVCardMapADR  0x1000130c  0x100039da     KUidContactFieldAddress  KUidContactFieldVCardMapWORK
28  Work city		0x10004dec  KUidContactFieldVCardMapLOCALITY  0x10004df6  0x100039da     KUidContactFieldLocality  KUidContactFieldVCardMapWORK
29  Work region		0x10004ded  KUidContactFieldVCardMapREGION  0x10004df7  0x100039da     KUidContactFieldRegion  KUidContactFieldVCardMapWORK
30  Work p'code		0x10004dee  KUidContactFieldVCardMapPOSTCODE  0x10004df8  0x100039da     KUidContactFieldPostcode  KUidContactFieldVCardMapWORK
31  Work country	0x10004def  KUidContactFieldVCardMapCOUNTRY  0x10004df9  0x100039da     KUidContactFieldCountry  KUidContactFieldVCardMapWORK
32  Birthday		0x1000401f  KUidContactFieldVCardMapBDAY  0x10004034        KUidContactFieldBirthday
33  Notes			0x10004025  KUidContactFieldVCardMapNOTE  0x1000401c        KUidContactFieldNote
34  Display name	0x1000402f  KUidContactFieldVCardMapUnusedFN
 * **/


#ifndef TCCCONTACTSMGRTAGID_INL_
#define TCCCONTACTSMGRTAGID_INL_

#define TAGID_CONTACT_FIELD_BASE 0x010
#define TAGID_CONTACT_FIELD_TEL_BASE 0x1000

#define TAG_CONTACT_FIELD_GIVEN_NAME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 1)	// ��
#define TAG_CONTACT_FIELD_FAMILY_NAME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 2)	// ��
#define TAG_CONTACT_FIELD_ADDITIONAL_NAME	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 3)	// ��������
#define TAG_CONTACT_FIELD_SUFFIX_NAME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 4)	// ������׺
#define TAG_CONTACT_FIELD_PREFIX_NAME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 5)	// ����ǰ׺
#define TAG_CONTACT_FIELD_FULL_NAME			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 6)	// ȫ������ʱʹ�ã����ֻ���ʽ�ֶ�
#define TAG_CONTACT_FIELD_COMPANY_NAME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 7)	// ��˾
#define TAG_CONTACT_FIELD_NOTE				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 8)	// ��ע
#define TAG_CONTACT_FIELD_JOBTITLE			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 9)	// TITLE				ְ��				fieldid = EPbkFieldIdJobTitle					fieldtypes = {KUidContactFieldUrl}		mapping = KUidContactFieldVCardMapTITLE
#define TAG_CONTACT_FIELD_EMAIL_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xb)	// EMAIL;INTERNET;HOME 	��ͥEMAIL��ַ��	fieldid = EPbkFieldIdEmailAddress	fieldtypes = {KUidContactFieldEMail, KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapEMAILINTERNET
#define TAG_CONTACT_FIELD_EMAIL				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xa)	// EMAIL;INTERNET		EMAIL��ַ��		fieldid = EPbkFieldIdEmailAddress 	fieldtypes = {KUidContactFieldEMail}	mapping = KUidContactFieldVCardMapEMAILINTERNET
#define TAG_CONTACT_FIELD_EMAIL_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xc)	// EMAIL;INTERNET;WORK	�칫EMAIL��ַ��	fieldid = EPbkFieldIdEmailAddress	fieldtypes = {KUidContactFieldEMail, KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapEMAILINTERNET
#define TAG_CONTACT_FIELD_URL				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xd)	// URL					������ҳ			fieldid = EPbkFieldIdURL			fieldtypes = {KUidContactFieldUrl}		mapping = KUidContactFieldVCardMapURL
#define TAG_CONTACT_FIELD_URL_HOME			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xe)	// URL;HOME				��ͥ��ҳ			fieldid = EPbkFieldIdURL			fieldtypes = {KUidContactFieldUrl, KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapURL
#define TAG_CONTACT_FIELD_URL_WORK			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0xf)	// URL;WORK				������ҳ			fieldid = EPbkFieldIdURL			fieldtypes = {KUidContactFieldUrl, KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapURL
#define TAG_CONTACT_FIELD_QQ				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x10)	// QQ�ţ��Զ����ֶΣ�S60û�ж�Ӧ
#define TAG_CONTACT_FIELD_POSTAL_OFFICE_BOX			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x11)	// ADRֵ�ĵ�1���� 			�ʼĵ�ַ			fieldid = EPbkFieldIdPOBox	fieldtypes = {KUidContactFieldPostOffice}								mapping = KUidContactFieldVCardMapPOSTOFFICE
#define TAG_CONTACT_FIELD_POSTAL_OFFICE_BOX_HOME	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x12)	// ADR;HOMEֵ�ĵ�1���� 		��ͥ�ʼĵ�ַ		fieldid = EPbkFieldIdPOBox	fieldtypes = {KUidContactFieldPostOffice, KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapPOSTOFFICE
#define TAG_CONTACT_FIELD_POSTAL_OFFICE_BOX_WORK	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x13)	// ADR;WORKֵ�ĵ�1���� 		�����ʼĵ�ַ		fieldid = EPbkFieldIdPOBox	fieldtypes = {KUidContactFieldPostOffice, KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapPOSTOFFICE
#define TAG_CONTACT_FIELD_EXTENDED_ADRESS			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x14)	// ADRֵ�ĵ�2����			��ַ��			fieldid = EPbkFieldIdExtendedAddress	fieldtypes = {KUidContactFieldExtendedAddress}									mapping = KUidContactFieldVCardMapEXTENDEDADR
#define TAG_CONTACT_FIELD_EXTENDED_ADRESS_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x15)	// ADR;HOMEֵ�ĵ�2���� 		��ͥ��ַ			fieldid = EPbkFieldIdExtendedAddress	fieldtypes = {KUidContactFieldExtendedAddress,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapEXTENDEDADR
#define TAG_CONTACT_FIELD_EXTENDED_ADRESS_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x16)	// ADR;WORKֵ�ĵ�2���� 		������ַ			fieldid = EPbkFieldIdExtendedAddress	fieldtypes = {KUidContactFieldExtendedAddress,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapEXTENDEDADR
#define TAG_CONTACT_FIELD_STREET_ADRESS				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x17)	// ADRֵ�ĵ�3����			�ֵ���ַ��		fieldid = EPbkFieldIdStreetAddress		fieldtypes = {KUidContactFieldAddress}									mapping = KUidContactFieldVCardMapADR
#define TAG_CONTACT_FIELD_STREET_ADRESS_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x18)	// ADR;HOMEֵ�ĵ�3���� 		��ͥ�ֵ���ַ		fieldid = EPbkFieldIdStreetAddress		fieldtypes = {KUidContactFieldAddress,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapADR
#define TAG_CONTACT_FIELD_STREET_ADRESS_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x19)	// ADR;WORKֵ�ĵ�3���� 		�����ֵ���ַ		fieldid = EPbkFieldIdStreetAddress		fieldtypes = {KUidContactFieldAddress,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapADR
#define TAG_CONTACT_FIELD_LOCALITY					MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1a)	// ADRֵ�ĵ�4����			���е�ַ��		fieldid = EPbkFieldIdCity				fieldtypes = {KUidContactFieldLocality}									mapping = KUidContactFieldVCardMapLOCALITY
#define TAG_CONTACT_FIELD_LOCALITY_HOME				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1b)	// ADR;HOMEֵ�ĵ�4���� 		��ͥ���е�ַ		fieldid = EPbkFieldIdCity				fieldtypes = {KUidContactFieldLocality,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapLOCALITY
#define TAG_CONTACT_FIELD_LOCALITY_WORK				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1c)	// ADR;WORKֵ�ĵ�4���� 		�������е�ַ		fieldid = EPbkFieldIdCity				fieldtypes = {KUidContactFieldLocality,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapLOCALITY
#define TAG_CONTACT_FIELD_REGION					MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1d)	// ADRֵ�ĵ�5����			ʡ��				fieldid = EPbkFieldIdState				fieldtypes = {KUidContactFieldRegion}									mapping = KUidContactFieldVCardMapREGION
#define TAG_CONTACT_FIELD_REGION_HOME				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1e)	// ADR;HOMEֵ�ĵ�5���� 		��ͥʡ			fieldid = EPbkFieldIdState				fieldtypes = {KUidContactFieldRegion,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapREGION
#define TAG_CONTACT_FIELD_REGION_WORK				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x1f)	// ADR;WORKֵ�ĵ�5���� 		����ʡ			fieldid = EPbkFieldIdState				fieldtypes = {KUidContactFieldRegion,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapREGION
#define TAG_CONTACT_FIELD_POSTAL_CODE				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x20)	// ADRֵ�ĵ�6����			�������룬		fieldid = EPbkFieldIdPostalCode		fieldtypes = {KUidContactFieldPostcode}									mapping = KUidContactFieldVCardMapPOSTCODE
#define TAG_CONTACT_FIELD_POSTAL_CODE_HOME			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x21)	// ADR;HOMEֵ�ĵ�6���� 		��ͥ��������		fieldid = EPbkFieldIdPostalCode		fieldtypes = {KUidContactFieldPostcode,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapPOSTCODE
#define TAG_CONTACT_FIELD_POSTAL_CODE_WORK			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x22)	// ADR;WORKֵ�ĵ�6���� 		������������		fieldid = EPbkFieldIdPostalCode		fieldtypes = {KUidContactFieldPostcode,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapPOSTCODE
#define TAG_CONTACT_FIELD_COUNTRY					MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x23)	// ADRֵ�ĵ�7����			���ҵ�����		fieldid = EPbkFieldIdCountry		fieldtypes = {KUidContactFieldCountry}									mapping = KUidContactFieldVCardMapCOUNTRY
#define TAG_CONTACT_FIELD_COUNTRY_HOME				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x24)	// ADR;HOMEֵ�ĵ�7���� 		��ͥ���ҵ���		fieldid = EPbkFieldIdCountry		fieldtypes = {KUidContactFieldCountry,	KUidContactFieldVCardMapHOME}	mapping = KUidContactFieldVCardMapCOUNTRY
#define TAG_CONTACT_FIELD_COUNTRY_WORK				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x25)	// ADR;WORKֵ�ĵ�7���� 		�������ҵ���		fieldid = EPbkFieldIdCountry		fieldtypes = {KUidContactFieldCountry,	KUidContactFieldVCardMapWORK}	mapping = KUidContactFieldVCardMapCOUNTRY
#define TAG_CONTACT_FIELD_BIRTHDAY					MAKE_TAG(TGTP_TI64, TAGID_CONTACT_FIELD_BASE + 0x26)	// BDAY						����				fieldid = EPbkFieldIdDate			fieldtypes = {KUidContactFieldBirthday}									mapping = KUidContactFieldVCardMapBDAY
#define TAG_CONTACT_FIELD_RING_TONE					MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x27)	// SOUND					�������� 			fieldid = EPbkFieldIdPersonalRingingToneIndication			fieldtypes = {KUidContactFieldRingTone} 		mapping = KUidContactFieldVCardMapSOUND
#define TAG_CONTACT_FIELD_GROUP						MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_BASE + 0x28)	// ����
#define TAG_CONTACT_FIELD_GROUP_ID					MAKE_TAG(TGTP_MV_TI32, TAGID_CONTACT_FIELD_BASE + 0x29)	// ����id,���ܶ����
#define TAG_CONTACT_FIELD_IS_FOCUS					MAKE_TAG(TGTP_TBOOL, TAGID_CONTACT_FIELD_BASE + 0x2A)	// �Ƿ�Ϊ��ע��
#define TAG_CONTACT_FIELD_YELLEW_HOT				MAKE_TAG(TGTP_TI32, TAGID_CONTACT_FIELD_BASE + 0x2B)	// ��ҳ����������ȶ�


// ���е绰�ֶε�mapping uid��ΪKUidContactFieldVCardMapTEL
#define TAG_CONTACT_FIELD_TEL				MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x1)	// TEL;				��ʱʹ�ã�S60û�ж�Ӧ
#define TAG_CONTACT_FIELD_TEL_CELL			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x2)	// TEL;CELL��		fieldid = EPbkFieldIdPhoneNumberMobile	fieldtypes = {KUidContactFieldPhoneNumber,  	KUidContactFieldVCardMapCELL}
#define TAG_CONTACT_FIELD_TEL_CELL_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x3)	// TEL;CELL;HOME��	fieldid = EPbkFieldIdPhoneNumberMobile	fieldtypes = {KUidContactFieldPhoneNumber,  	KUidContactFieldVCardMapCELL, 	KUidContactFieldVCardMapHOME}
#define TAG_CONTACT_FIELD_TEL_CELL_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x4)	// TEL;CELL;WORK��	fieldid = EPbkFieldIdPhoneNumberMobile	fieldtypes = {KUidContactFieldPhoneNumber,  	KUidContactFieldVCardMapCELL, 	KUidContactFieldVCardMapWORK}
#define TAG_CONTACT_FIELD_TEL_VOICE			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x5)	// TEL;VOICE��		fieldid = EPbkFieldIdPhoneNumberGeneral	fieldtypes = {KUidContactFieldPhoneNumber,  	KUidContactFieldVCardMapVOICE}
#define TAG_CONTACT_FIELD_TEL_VOICE_HOME	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x6)	// TEL;VOICE;HOME��	fieldid = EPbkFieldIdPhoneNumberHome	fieldtypes = {KUidContactFieldPhoneNumber,  	KUidContactFieldVCardMapVOICE, 	KUidContactFieldVCardMapHOME}
#define TAG_CONTACT_FIELD_TEL_VOICE_WORK	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x7)	// TEL;VOICE;WORK��	fieldid = EPbkFieldIdPhoneNumberWork	fieldtypes = {KUidContactFieldPhoneNumber,		KUidContactFieldVCardMapVOICE, 	KUidContactFieldVCardMapWORK}
#define TAG_CONTACT_FIELD_TEL_FAX			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x8)	// TEL;FAX��			fieldid = EPbkFieldIdFaxNumber			fieldtypes = {KUidContactFieldFax, 				KUidContactFieldVCardMapFAX}
#define TAG_CONTACT_FIELD_TEL_FAX_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x9)	// TEL;FAX;HOME��	fieldid = EPbkFieldIdFaxNumber			fieldtypes = {KUidContactFieldFax, 				KUidContactFieldVCardMapFAX,	KUidContactFieldVCardMapHOME}
#define TAG_CONTACT_FIELD_TEL_FAX_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xa)	// TEL;FAX;WORK��	fieldid = EPbkFieldIdFaxNumber			fieldtypes = {KUidContactFieldFax, 				KUidContactFieldVCardMapFAX,	KUidContactFieldVCardMapWORK}
#define TAG_CONTACT_FIELD_TEL_PAGER			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xb)	// TEL;PAGER��		fieldid = EPbkFieldIdPagerNumber		fieldtypes = {EPbkFieldIdPagerNumber, 			KUidContactFieldVCardMapPAGER}
#define TAG_CONTACT_FIELD_TEL_PAGER_HOME	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xc)	// TEL;PAGER;HOME��	S60û�ж�Ӧ
#define TAG_CONTACT_FIELD_TEL_PAGER_WORK	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xd)	// TEL;PAGER;WORK��	S60û�ж�Ӧ
#define TAG_CONTACT_FIELD_TEL_VIDEO			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xe)	// TEL;VIDEO��		fieldid = EPbkFieldIdPhoneNumberVideo	fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapVIDEO}
#define TAG_CONTACT_FIELD_TEL_VIDEO_HOME	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0xf)	// TEL;VIDEO;HOME��	fieldid = EPbkFieldIdPhoneNumberVideo	fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapVIDEO, 	KUidContactFieldVCardMapHOME}
#define TAG_CONTACT_FIELD_TEL_VIDEO_WORK	MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x10)	// TEL;VIDEO;WORK��	fieldid = EPbkFieldIdPhoneNumberVideo	fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapVIDEO, 	KUidContactFieldVCardMapWORK}
#define TAG_CONTACT_FIELD_TEL_CAR			MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x11)	// TEL;CAR��			fieldid = ?								fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapCAR}
#define TAG_CONTACT_FIELD_TEL_CAR_HOME		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x12)	// TEL;CAR;HOME��	fieldid = ?								fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapCAR, 	KUidContactFieldVCardMapHOME}
#define TAG_CONTACT_FIELD_TEL_CAR_WORK		MAKE_TAG(TGTP_TSTR16, TAGID_CONTACT_FIELD_TEL_BASE + 0x13)	// TEL;CAR;WORK��	fieldid = ?								fieldtypes = {KUidContactFieldPhoneNumber, 	KUidContactFieldVCardMapCAR, 	KUidContactFieldVCardMapWORK}

#define TAG_CONTACT_FIELD_TEL_RANG_BEGIN	TAG_CONTACT_FIELD_TEL
#define TAG_CONTACT_FIELD_TEL_RANG_END		TAG_CONTACT_FIELD_TEL_CAR_WORK


#define TAG_CONTACT_FIELD_ALARM_BASE				0x1060     // alarm base
#define TAG_CONTACT_FIELD_ALARM_ITEM				MAKE_TAG(TGTP_TI32, TAG_CONTACT_FIELD_ALARM_BASE + 1)   // �¼����Ѽ�¼
#define TAG_CONTACT_FIELD_CONTITEM_ID				MAKE_TAG(TGTP_TI32, TAG_CONTACT_FIELD_ALARM_BASE + 2)   // ��ϵ��id
#define TAG_CONTACT_FIELD_ALARM_ID					MAKE_TAG(TGTP_TI32, TAG_CONTACT_FIELD_ALARM_BASE + 3)   // �¼�����id(��ϵͳ��������ֵ)
#define TAG_CONTACT_FIELD_ALARM_TYPE				MAKE_TAG(TGTP_TI32, TAG_CONTACT_FIELD_ALARM_BASE + 4)   // �¼���������(Ƶ�ʶ�)
#define TAG_CONTACT_FIELD_ALARM_TIME				MAKE_TAG(TGTP_TI64, TAG_CONTACT_FIELD_ALARM_BASE + 5)   // �¼�����ʱ��
#define TAG_CONTACT_FIELD_ALARM_TIPINFO				MAKE_TAG(TGTP_TSTR16, TAG_CONTACT_FIELD_ALARM_BASE + 6) // �¼���������

#define TAG_SMS_INFO_BASE							0x1080     // SMS base
#define TAG_SMS_INFO_ID								MAKE_TAG(TGTP_TI32, TAG_SMS_INFO_BASE + 1)				//����ID
#define TAG_SMS_INFO_DETAILS						MAKE_TAG(TGTP_TSTR16, TAG_SMS_INFO_BASE + 2)			//��ϵ������
#define TAG_SMS_INFO_TIME							MAKE_TAG(TGTP_TI64, TAG_SMS_INFO_BASE + 3)				//ʱ��
#define TAG_SMS_INFO_PARENT							MAKE_TAG(TGTP_TI32, TAG_SMS_INFO_BASE + 4)				//ʲô������
#define TAG_SMS_INFO_UNREAD							MAKE_TAG(TGTP_BINARY, TAG_SMS_INFO_BASE + 5)			//�Ƿ���δ����Ϣ
#define TAG_SMS_INFO_DESCRIPTION					MAKE_TAG(TGTP_TSTR16, TAG_SMS_INFO_BASE + 6)			//��������
#define TAG_SMS_INFO_NUMBER							MAKE_TAG(TGTP_TSTR16, TAG_SMS_INFO_BASE + 7)			//����
#define TAG_SMS_INFO_CNTID							MAKE_TAG(TGTP_TI32, TAG_SMS_INFO_BASE + 8)			//��ϵ��ID

#define TAG_CALLLOG_INFO_BASE							0x1200     // CallLog base
#define TAG_CALLLOG_INFO_ID								MAKE_TAG(TGTP_TI32, TAG_CALLLOG_INFO_BASE + 1)				//LOGID
#define TAG_CALLLOG_INFO_TYPE						MAKE_TAG(TGTP_TSTR16, TAG_CALLLOG_INFO_BASE + 2)				//LOG���ͣ��ѽ�/δ��/������
#define TAG_CALLLOG_INFO_NUM							MAKE_TAG(TGTP_TI64, TAG_CALLLOG_INFO_BASE + 3)				//����
#define TAG_CALLLOG_INFO_NAME							MAKE_TAG(TGTP_TI32, TAG_CALLLOG_INFO_BASE + 4)				//��ϵ������
#define TAG_CALLLOG_INFO_STARTTIME							MAKE_TAG(TGTP_BINARY, TAG_CALLLOG_INFO_BASE + 5)			//��ʼʱ��
#define TAG_CALLLOG_INFO_DURATION					MAKE_TAG(TGTP_TSTR16, TAG_CALLLOG_INFO_BASE + 6)			//
#define TAG_CALLLOG_INFO_CNTID							MAKE_TAG(TGTP_TSTR16, TAG_CALLLOG_INFO_BASE + 7)			//��ϵ��ID

#endif /* TCCCONTACTSMGRTAGID_INL_ */

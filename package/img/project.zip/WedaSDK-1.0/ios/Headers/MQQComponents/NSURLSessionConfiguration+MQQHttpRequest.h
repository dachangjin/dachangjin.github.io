//
//  NSURLSessionConfiguration+MQQHttpRequest.h
//  MQQSecure
//
//  Created by klaudz on 26/7/2016.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURLSessionConfiguration (MQQHttpRequest)

+ (NSURLSessionConfiguration *)mqqBackgroundSessionConfigurationWithIdentifier:(NSString *)identifier;

@end

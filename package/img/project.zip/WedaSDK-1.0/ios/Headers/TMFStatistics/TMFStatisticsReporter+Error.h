//
//  TMFStatisticsReporter+Error.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Error)

- (void)et6_ERROR_EventWithError:(nullable NSError *)error configuration:(nullable TMFStatisticsConfiguration *)configuration;

- (void)et6_ERROR_EventWithException:(nullable NSException *)exception configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

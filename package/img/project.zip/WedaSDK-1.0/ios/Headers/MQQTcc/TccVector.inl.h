

//ΪTccStr�ر����ı��ػ��������Ч��
template<typename X>
inline void TccVectorMoveItem(X& dst, X& src){dst = src;}

#if 1
TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccStr16& dst, TccStr16& src){
	TccStr16::Swap(dst, src);
	src.Clear();
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccStr8& dst, TccStr8& src){
	TccStr8::Swap(dst, src);
	src.Clear();
}
#endif

TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccCntrPair<ti32, TccStr16>& dst, TccCntrPair<ti32, TccStr16>& src){
	dst.iFirst = src.iFirst;
	TccStr16::Swap(dst.iSecond, src.iSecond);
	src.iSecond.Clear();
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccCntrPair<TccStr16, ti32>& dst, TccCntrPair<TccStr16, ti32>& src){
	TccStr16::Swap(dst.iFirst, src.iFirst);
	src.iFirst.Clear();
	dst.iSecond = src.iSecond;
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccCntrPair<ti32, TccStr8>& dst, TccCntrPair<ti32, TccStr8>& src){
	dst.iFirst = src.iFirst;
	TccStr8::Swap(dst.iSecond, src.iSecond);
	src.iSecond.Clear();
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccVectorMoveItem(TccCntrPair<TccStr8, ti32>& dst, TccCntrPair<TccStr8, ti32>& src){
	TccStr8::Swap(dst.iFirst, src.iFirst);
	src.iFirst.Clear();
	dst.iSecond = src.iSecond;
}




template <typename T, typename _traits>
TccVector<T, _traits>::TccVector(){
	iData = NULL;
	iLen = 0;
	iSize = 0;
}

template <typename T, typename _traits>
TccVector<T, _traits>::~TccVector(){
	Clear();
}


template <typename T, typename _traits>
inline T* TccVector<T, _traits>::Ptr() const {
	return iData;
}

template <typename T, typename _traits>
inline ti32 TccVector<T, _traits>::Size() const {
	return iLen;
}

template <typename T, typename _traits>
inline void TccVector<T, _traits>::SetSize(ti32 aSize){
	TccAssert(aSize<=iSize);
	iLen = aSize;
}

template <typename T, typename _traits>
inline ti32 TccVector<T, _traits>::MaxSize() const {return iSize;}



template <typename T, typename _traits>
T& TccVector<T, _traits>::Back(){
	TccAssert(iLen > 0); 
	return iData[iLen - 1];
}

template <typename T, typename _traits>
T& TccVector<T, _traits>::Front(){ 
	TccAssert(iLen > 0); 
	return iData[0];
}

template <typename T, typename _traits>
inline typename TccVector<T, _traits>::Iterator 
TccVector<T, _traits>::Begin() const{
	return Iterator(iLen, 0, iData);
}

template <typename T, typename _traits>
inline typename TccVector<T, _traits>::Iterator 
TccVector<T, _traits>::End() const{
	return Iterator(iLen, iLen, iData);
}


template <typename T, typename _traits>
inline void TccVector<T, _traits>::Begin(Iterator& it) const{
	return it.Set(iLen, 0, iData);
}

template <typename T, typename _traits>
inline void TccVector<T, _traits>::End(Iterator& it) const{
	return it.Set(iLen, iLen, iData);
}

#if 0
template <typename T, typename _traits>
void TccVector<T, _traits>::PushBackL(const T& element){
	if(iLen == iSize){
		ResizeL(iSize + _TccVectorIncreaseSize);
	}
	iData[iLen] = element;
	iLen++;
}
#endif

template <typename T, typename _traits>
inline void TccVector<T, _traits>::PushBackA(const T& element){
	TccAssert(iLen < iSize);
	iData[iLen] = element;
	iLen++;
}


template <typename T, typename _traits>
terror TccVector<T, _traits>::Resize(ti32 asize){
	if(asize > iSize){
		T* _tdata = new T[asize];
		if(NULL == _tdata) return _TccErrNoMemory;
		for (ti32 i = 0; i < iLen; i++){
			TccVectorMoveItem(_tdata[i], iData[i]);
		}
		if(iData != NULL){
			delete []iData;
		}
		iData = _tdata;
		_tdata = NULL;
		iSize = asize;
	}
	return _TccErrNone;
}

template <typename T, typename _traits>
inline terror TccVector<T, _traits>::PushBack(const T& element){
	return PushBack(element, _TccVectorIncreaseSize);
}

template <typename T, typename _traits>
terror TccVector<T, _traits>::PushBack(const T& element, ti32 aIncreaseSize){
	TccAssert(aIncreaseSize > 0);
	terror aErr = _TccErrNone;
	if(iLen == iSize){
		aErr = Resize(iSize + aIncreaseSize);
	}
	if(_TccErrNone == aErr){
		iData[iLen] = element;
		iLen++;
	}
	return aErr;
}


template <typename T, typename _traits>
inline terror TccVector<T, _traits>::Insert(ti32 nIndex, const T& element){
	return Insert(nIndex, element, _TccVectorIncreaseSize);
}

template <typename T, typename _traits>
terror TccVector<T, _traits>::Insert(ti32 nIndex, const T& element, ti32 aIncreaseSize){
	TccAssert(nIndex >= 0 && nIndex <= iLen && aIncreaseSize > 0);
	terror aErr = _TccErrNone;
	if(iLen == iSize){
		aErr = Resize(iSize + aIncreaseSize);
	}
	if(_TccErrNone == aErr){
		if(nIndex < 0)nIndex = 0;
		if(nIndex > iLen)nIndex = iLen;
		for(ti32 i = iLen; i > nIndex; i--){
			TccVectorMoveItem(iData[i], iData[i - 1]);
		}
		iData[nIndex] = element;
		iLen++;
	}
	return aErr;
}


template <typename T, typename _traits>
void TccVector<T, _traits>::PopBack(){
	if(iLen > 0) --iLen;
}

template <typename T, typename _traits>
void TccVector<T, _traits>::PopBackAndDestroy(){
	if(iLen > 0){
		_traits::DeleteHandle(iData[iLen - 1]);
		--iLen;
	}
}

template <typename T, typename _traits>
inline tbool TccVector<T, _traits>::Empty() const{
	return (iLen == 0); 
}

template <typename T, typename _traits>
inline void TccVector<T, _traits>::Zero(){
	iLen = 0; 
}


template <typename T, typename _traits>
void TccVector<T, _traits>::Clear(){
	if(iData != NULL){
		delete []iData;
		iData = NULL;
	}
	iSize = 0;
	iLen = 0;
}

template <typename T, typename _traits>
void TccVector<T, _traits>::Destroy(){
	if(iData != NULL){
		for(ti32 i = 0 ; i < iLen; i++){
			_traits::DeleteHandle(iData[i]);
		}
		delete []iData;
		iData = NULL;
	}
	iSize = 0;
	iLen = 0;
}

template <typename T, typename _traits>
T& TccVector<T, _traits>::operator[](ti32 aIndex){
	TccAssert((iSize > aIndex && aIndex >= 0));
	if(iLen <= aIndex)
		iLen = aIndex + 1;
	return iData[aIndex];
}


template <typename T, typename _traits>
inline T& TccVector<T, _traits>::At(ti32 aIndex){
	TccAssert((iSize > aIndex && aIndex >= 0));
	if(iLen <= aIndex)
		iLen = aIndex + 1;
	return iData[aIndex];
}

template <typename T, typename _traits>
inline const T& TccVector<T, _traits>::At(ti32 aIndex) const{
	TccAssert((iSize > aIndex && aIndex >= 0));
	return iData[aIndex];
}

template <typename T, typename _traits>
const T& TccVector<T, _traits>::operator[](ti32 aIndex) const {
	TccAssert((iLen > aIndex && aIndex >= 0)); 
	return iData[aIndex];
}

template <typename T, typename _traits>
void TccVector<T, _traits>::Remove(ti32 aIndex){
	TccAssert((iLen > aIndex && aIndex >= 0));
	//T a = iData[aIndex];
	for(ti32 i = aIndex + 1; i < iLen; i++){
		TccVectorMoveItem(iData[i - 1], iData[i]);
	}
	//memmove
	iLen--;
	//return a;
}

template <typename T, typename _traits>
void TccVector<T, _traits>::RemoveAndDestroy(ti32 aIndex){
	TccAssert((iLen > aIndex && aIndex >= 0));
	_traits::DeleteHandle(iData[aIndex]);
	for(ti32 i = aIndex + 1; i < iLen; i++){
		TccVectorMoveItem(iData[i - 1], iData[i]);
	}
	//memmove
	iLen--;
}

template <typename T, typename _traits>
void TccVector<T, _traits>::Erase(const T& element){
	ti32 index = Search(element);
	if(index < 0) return;
	Remove(index);
}

template <typename T, typename _traits>
void TccVector<T, _traits>::EraseAndDestroy(const T& element){
	ti32 index = Search(element);
	if(index < 0) return;
	return RemoveAndDestroy(index);
}


template <typename T, typename _traits>
void TccVector<T, _traits>::Erase(Iterator& iter){
	if(iter.iPos < iter.iMaxNum){
		Remove(iter.iPos);
		iter.iMaxNum--;
		iter.iData = iData;
	}
}

template <typename T, typename _traits>
void TccVector<T, _traits>::EraseAndDestroy(Iterator& iter){
	if(iter.iPos < iter.iMaxNum){
		RemoveAndDestroy(iter.iPos);
		iter.iMaxNum--;
		iter.iData = iData;
	}
}

template <typename T, typename _traits>
terror TccVector<T, _traits>::Copy(const T* data, ti32 len){
	terror err = _TccErrNone;
	if(len == 0){
		Clear();
	}
	else{
		TccAssert((data != NULL && len > 0));
		iLen = 0;
		err = Resize(len);
		if(err == _TccErrNone){
			iLen = len;
			for (int i = 0; i < len; i++){
				iData[i] = data[i];
			}
		}
	}
	return err;
}


template <typename T, typename _traits>
terror TccVector<T, _traits>::Append(const T* data, ti32 len){
	terror err = _TccErrNone;
	if(len > 0){
		TccAssert(data != NULL);
		err = Resize(iLen + len);
		if(err == _TccErrNone){
			for (int i = 0; i < len; i++){
				iData[iLen++] = data[i];
			}
		}
	}
	return err;
}

template <typename T, typename _traits>
void TccVector<T, _traits>::Swap(ti32 a, ti32 b){
	TccCntrArrSwap(iData, a, b);
}

template <typename T, typename _traits>
void TccVector<T, _traits>::Sort(){
	TccQuickSort(iData, iLen, _traits::Compare);
}



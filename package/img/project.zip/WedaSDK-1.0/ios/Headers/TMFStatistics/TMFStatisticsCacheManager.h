//
//  TMFStatisticsCacheManager.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define TMFSCacheManager ([TMFStatisticsCacheManager defaultManager])

@interface TMFStatisticsCacheManager : NSObject

/**
 @brief 设备唯一ID
 */
@property (nonatomic, copy, nullable, readonly) NSString *VID;

+ (instancetype)defaultManager;
- (instancetype)init NS_UNAVAILABLE;

- (void)fetchVID:(void (^)(NSString * _Nullable VID, NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END

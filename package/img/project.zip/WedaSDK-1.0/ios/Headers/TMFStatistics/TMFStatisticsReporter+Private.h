//
//  TMFStatisticsReporter.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/10/28.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TMFStatisticsThreadPool.h"
#import "TMFStatisticsFields.h"

#import "TMFStatisticsUtilities.h"
#import "TMFStatisticsConfiguration.h"

#import "TMFSharkCenter.h"

#import "TMFStatisticsCacheManager.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, TMFStatisticsReporterEvent) {
    TMFStatisticsReporterEventSession       = 1,
    TMFStatisticsReporterEventPage          = 2,
    TMFStatisticsReporterEventCustom        = 3,
    TMFStatisticsReporterEventActive        = 4,
    TMFStatisticsReporterEventCustomID      = 5,
    TMFStatisticsReporterEventError         = 6,
};

#define SAF_INT_TO_STR(int_str) ([NSString stringWithFormat:@"%ld", (long)int_str])

#define SAF_STR_TO_STR(str) (str.length > 0 ? str : @"")

#define SAF_EVENT_TO_STR(et) (SAF_INT_TO_STR(et))

@protocol TMFStatisticsReporterProtocol <NSObject>

@required
- (void)addRecordWithDataFileds:(void (^)(NSMutableDictionary<NSNumber *, NSString *> *fds))record configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

@interface TMFStatisticsReporter () <TMFStatisticsReporterProtocol> {
@protected
    NSTimeInterval _reportThreshold;
    NSTimeInterval _reportInterval;
    
    BOOL _reportTimerSuspended;
    NSUInteger _unreportedCount;
    dispatch_time_t _unreportedTime;
    dispatch_source_t _reportTimer;
}

@property (nonatomic, strong) TMFStatisticsThreadPool *pool;

// Protocol
@property (nonatomic, weak) NSObject<TMFStatisticsReporterProtocol> *reporterProtocol;

@end

#pragma mark - Congiguration

@interface TMFStatisticsReporter ( /* Congiguration */ )
/**
 @brief 配置管理对象
 */
@property (nonatomic, strong, nullable) TMFStatisticsConfiguration *configuration;

@end

#define SAF_CONFIG_WITH_CONFIG(cf) (cf ? cf : self.configuration)

#pragma mark - Session Manager

@interface TMFStatisticsReporter ( /* Session Manager */ )

/**
 @brief 会话ID
 */
@property (nonatomic, assign) NSInteger sessionID;

/**
 @brief 会话时间
*/
@property (nonatomic, assign) NSInteger timestamp;

/**
 @brief 事件ID
*/
@property (nonatomic, assign) NSInteger eventIDX;

@end

#pragma mark - Custom User ID

@interface TMFStatisticsReporter ( /* Custom User ID */ )

/**
 @brief 自定义用户ID
 */
@property (nonatomic, copy, nullable) NSString *customUserID;

/**
 @brief ua
 */
@property (nonatomic, copy, nullable) NSString *userAgent;

@end

#pragma mark - Event Stack

@interface TMFStatisticsReporter ( /* Event Stack */ )

/**
 @brief 缓存堆栈
 */
@property (nonatomic, strong) NSMutableDictionary *cacheDict;

@property (nonatomic, strong) NSMutableArray *pageStack;

@end

#define SAF_EVENT_IDX ({ \
    self.eventIDX++; \
    (self.eventIDX); \
})

#define SAF_EVENT_TIMESTAMP ({ \
    NSInteger timestamp = [[NSDate date] timeIntervalSince1970] * 1000; \
    (timestamp); \
})

#define SAF_EVENT_INTERVAL(ts) (ts > 0 ? ts : 0)

#define SAF_EVENT_KVS(kvs) ({ \
    NSMutableString *string = [NSMutableString string]; \
    if ([kvs isKindOfClass:[NSDictionary class]]) { \
        NSInteger count = kvs.count; \
        int i = 0; \
        for (NSString *key in kvs) { \
            [string appendFormat:@"%@=%@", key, [kvs objectForKey:key]]; \
            if (++i < count) {  \
                [string appendString:@"&"]; \
            } \
        } \
    } \
    (string); \
})

NS_ASSUME_NONNULL_END

//
//  TMFStatisticsReporter+Page.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Page)

- (void)et2_PAGE_VIEW_EventWithHybridH5:(BOOL)hybridH5 page:(NSString *)page refPage:(nullable NSString *)rfPage duration:(NSInteger)duration labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

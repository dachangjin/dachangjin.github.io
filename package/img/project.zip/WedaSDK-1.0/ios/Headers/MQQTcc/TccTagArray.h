/**
* @file TccTagArray.h
* @version 1.0
* @author smartluo superguo
* @date 2009-5-13
*/
#ifndef __TCC_TAG_ARRAY_H_DEFINE__
#define __TCC_TAG_ARRAY_H_DEFINE__

#include "TccSys.h"
#include "TccBase.h"
#include "TccString.h"
#include "TccCrypt.h"
#include "TccTagType.h"
#include "TccTagId.h"
#if !defined(__TccSymbianKernel__)
#include "TccTime.h"
#endif

class TccTagArray;
class TccTagRowData;
class TccTagArrayFileReader;
class TccTagArrayFileWriter;
class TccTagRowDataBuffer;


class TccTagRowDataBuffer : public TccStr8{
public:
	tu32 iTag;
	TCCIMPORT TccTagRowDataBuffer();
	TCCIMPORT ~TccTagRowDataBuffer();
	TCCIMPORT void ClearAll();
};

class TccTagRowData{
public:
	tu32 iTag;			///< Tag��
	ti32 iLen;			///< ���ݴ�С
	const void* iData;	///<����
	
public:
	TCCIMPORT TccTagRowData();
	TCCIMPORT TccTagRowData(const TccTagRowData&);
	TCCIMPORT TccTagRowData(const TccTagRowDataBuffer&);
	TCCIMPORT ~TccTagRowData();
	TCCIMPORT void Clear();
	TCCIMPORT void Set(const void* aTagBuf);
	TCCIMPORT void Set(const TccTagRowDataBuffer&);
	inline tu16 GetType(){return (tu16)(GET_TAGID_TYPE(iTag));}
	inline tu16 GetId(){return (tu16)(GET_TAGID_ID(iTag));}
};


class TccTagData{

public:
	TCCIMPORT TccTagData();
	TCCIMPORT TccTagData(const TccTagRowData& aRowData);
	TCCIMPORT ~TccTagData();
	TCCIMPORT void Clear();
	TCCIMPORT void Set(const void* aBuf);
	TCCIMPORT void Set(tu32 aTag, ti32 aLen, const void* aData);

	TCCIMPORT void SetBinArr(_tbinary* aBinArr, ti32 aNum);

	inline tu16 GetType(){return (tu16)(GET_TAGID_TYPE(iTag));}
	inline tu16 GetId(){return (tu16)(GET_TAGID_ID(iTag));}

	tu32 iTag;
	union{
		ti8					i8;		/* case TGTP_I2 */
		ti16				i16;		/* case TGTP_I2 */
		ti32				i32;		/* case TGTP_LONG */
		_tti64				i64;		/* case TGTP_I64 */
		tu8					u8;
		tu16				u16;		/* alias for TGTP_LONG */
		tu32				u32;		/* alias for TGTP_LONG */
		float				r32;		/* case TGTP_R4 */
		double				r64;		/* case TGTP_DOUBLE */

		tbool				is;         /*TGTP_TBOOL*/
		
		_tstr8				str8;		/* case TGTP_TSTR8 */
		_tstr16				str16;		/* case TGTP_TSTR16 */

		_tbinary			bin;		/* case TGTP_BINARY */
		_ttime				t;			/* case TGTP_TIME*/

		_tm_ti16			mi16;		/* case TGTP_MV_I2 */
		_tm_ti32			mi32;		/* case TGTP_MV_LONG */
		_tm_ti64			mi64;		/* case TGTP_MV_I64 */
		_tm_tu16			mu16;		/* case TGTP_MV_U2 */
		_tm_tu32			mu32;		/* case TGTP_MV_LONG */
		_tm_float			mr32;		/* case TGTP_MV_R4 */
		_tm_doulbe			mr64;		/* case TGTP_MV_DOUBLE */
		_tm_binary			mbin;		/* case TGTP_MV_BINARY */
		_tm_str8			mstr8;		/* case TGTP_MV_STRING8 */
		_tm_str16			mstr16;		/* case TGTP_MV_UNICODE */
		
		TccTagArray*		tagarr;	/* case TGTP_MV_UNICODE */
	} iData;
};



class TccTagArrayC{
protected:
	ti32 iLen;
	tu8* iPtr;
public:

};


/**
* @brief 
* @param[in,out] 
* @exception 
* @test 
* @note 
* @attention 
* @return 
* @date 2009/05/14
* @remark
*/
class TccTagArray{

protected:
//	tu8* iPtr;
//	ti32 iLen;
//	ti32 iMaxLen;


public:

	TccStr8 iTagArr;


	TCCIMPORT TccTagArray();
	TCCIMPORT ~TccTagArray();


	/**
	* @class TccTagArray::Iterator 
	* @brief TccTagArray�ĵ�����
	* @attention 
	*/
	class Iterator{
		friend class TccTagTypeArray;
	protected:
		ti32 iSizeLeave; //ʣ�µĳ���,iProperty�����iData�ĺ�����ŵ�ʣ�µ�tag�ռ�ĳ���(��������ǰ��������ռ�ĳ���)
		const tu8* iData;	///<����
		TccTagData iProperty;
	public:

		inline Iterator(){iSizeLeave = 0;}
		inline Iterator(const void* aBuf, ti32 aLen){Set(aBuf, aLen);}
		inline Iterator(const Iterator& it){*this = it;}
		inline TccTagData& operator*(){return iProperty;}
		//TccTagData* operator&(){return &iProperty;}
		inline TccTagData* operator->(){return &iProperty;}

		inline TccPtrC8 AsStrA(){return TccPtrC8(iData + 8, (ti32)(*((tu32*)(iData + 4))));}
		inline TccPtrC16 AsStrW(){return TccPtrC16((const twchar*)iData + 8, (ti32)(*((tu32*)(iData + 4))) / sizeof(twchar));}

		inline const void* Ptr(){return (const void*)(iData + 8);}
		inline ti32 Length(){return (ti32)(*(tu32*)(iData + 4));}
		inline tu32 Tag(){return (*(tu32*)(iData));}

		inline tbool isEnd() const {
			return (tbool)(iSizeLeave < 8);
		}
		TCCIMPORT Iterator& operator=(const Iterator& it);

		TCCIMPORT void Set(const void* aBuf, ti32 aLen);

		TCCIMPORT Iterator& operator++(); //++xx

		TCCIMPORT Iterator operator++(int);
		
		TCCIMPORT tbool NextTo(tu32 aTag);
		
		inline tbool NextToSimilar(){return NextTo(iProperty.iTag);}
		
		TCCIMPORT tbool Find(tu32 aTagId);
	
		TCCIMPORT tbool Find(const void* aBuf, ti32 aLen, tu32 aTagId);
		
		inline tbool Find(const TccTagArray& aBuf, tu32 aTagId){return Find(aBuf.iTagArr.Ptr(), aBuf.iTagArr.Length(), aTagId);}
		inline tbool Find(const TccDesC8& aBuf, tu32 aTagId){return Find(aBuf.Ptr(), aBuf.Length(), aTagId);}
		
		inline void Set(const TccTagArray& aBuf){Set(aBuf.iTagArr.Ptr(), aBuf.iTagArr.Length());}
		inline void Set(const TccDesC8& aBuf){Set(aBuf.Ptr(), aBuf.Length());}
#if defined(__TccSymbian__)
		inline void Set(const TDesC8& aBuf){Set(aBuf.Ptr(), aBuf.Length());}
#endif

	};


	/**
	* @brief PushBackL д������(����Ѿ������Ǹ�tag,��ô�����ݻ�����ͬ��tag�����ݺ���)
	* @param[in] aTagId Tag��ID��
	* @param[in] aData Ҫд�������
	*/
	inline void PushBackL(tu32 aTagId, const TccDesC8& aData){
		TccAssert(TGTP_NULL == GET_TAGID_TYPE(aTagId) || TGTP_TSTR8 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, (tu8*)aData.Ptr(), aData.Length());
	}

	/** 
	* @brief PushBackL д������(����Ѿ������Ǹ�tag,��ô�����ݻ�����ͬ��tag�����ݺ���)
	* @param[in] aTagId Tag��ID��
	* @param[in] aValue Ҫд�������
	*/
	inline void PushBackL(tu32 aTagId, const TccDesC16& aValue){
		TccAssert(TGTP_NULL == GET_TAGID_TYPE(aTagId) || TGTP_TSTR16 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, (tu8*)aValue.Ptr(), aValue.Length() * 2);
	}

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
	inline void PushBackL(tu32 aTagId, const TDesC8& aData){
		TccAssert(TGTP_TSTR8 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, (tu8*)aData.Ptr(), aData.Length());
	}
	inline void PushBackL(tu32 aTagId, const TDesC16& aValue){
		TccAssert(TGTP_TSTR16 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, (tu8*)aValue.Ptr(), aValue.Length() * 2);
	}
#endif

	inline void PushBackL(tu32 aTagId, ti8 aData){
		TccAssert(TGTP_TI8 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, ti16 aData){
		TccAssert(TGTP_TI16 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, ti32 aData){
		TccAssert(TGTP_TI32 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, const ti64& aData){
		TccAssert(TGTP_TI64 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, tu8 aData){
		TccAssert(TGTP_TU8 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, tu16 aData){
		TccAssert(TGTP_TU16 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, tu32 aData){
		TccAssert(TGTP_TU32 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	
	inline void PushBackL(tu32 aTagId, float aData){
		TccAssert(TGTP_TR4 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}

	inline void PushBackL(tu32 aTagId, double aData){
		TccAssert(TGTP_TR8 == GET_TAGID_TYPE(aTagId));
		PushBackL(aTagId, &aData, sizeof(aData));
	}


	TCCIMPORT void PushBackL(tu32 aTagId, TccDesC16* aData[], ti32 aNum);
	
	//void PushBackL(tu32 aTagId, TccTccDesC16* aData, ti32 aNum);


	struct MultiValueStaff{
		ti32 iPos;
		ti32 iLen;
	};
	
	TCCIMPORT terror PushMultiValueTi32Begin(tu32 aTagId, ti32 aNum);
	TCCIMPORT void PushMultiValueTi32Update(ti32 aValue);
	TCCIMPORT void PushMultiValueTi32Update(const ti32* aValue, ti32 aNum);
	TCCIMPORT void PushMultiValueEnd();
	
	TCCIMPORT terror PushMultiValueTi32Begin(MultiValueStaff& aStaff, tu32 aTagId, ti32 aNum = 0);
	TCCIMPORT terror PushMultiValueTi32Update(MultiValueStaff& aStaff, ti32 aValue);
	TCCIMPORT terror PushMultiValueTi32Update(MultiValueStaff& aStaff, ti32* aValue, ti32 aNum);
	TCCIMPORT void PushMultiValueEnd(MultiValueStaff& aStaff);
	
	
	
	
	/** 
	* @brief PushBackL д������(����Ѿ������Ǹ�tag,��ô�����ݻ�����ͬ��tag�����ݺ���)
	* @param[in] aTagId Tag��ID��
	* @param[in] aValue Ҫд�������
	*/
#if !defined(__TccSymbianKernel__)
	inline void PushBackL(tu32 aTagId, const TccTime& aValue){
		TccAssert(TGTP_TIME == GET_TAGID_TYPE(aTagId));
		ti64 a;
		aValue.GetFileTime(a);
		PushBackL(aTagId, (tu8*)&a, sizeof(ti64));
	}
#endif
	
	inline void PushBackBoolL(tu32 aTagId, tbool aData){
		TccAssert(TGTP_TBOOL == GET_TAGID_TYPE(aTagId));
		ti8 aDataXX = (aData ? 1 : 0);
		PushBackL(aTagId, &aDataXX, sizeof(aDataXX));
	}


	inline void PushBackL(tu32 aTagId, const TccTagArray& aTagArray){
		PushBackL(aTagId, aTagArray.iTagArr.Ptr(), aTagArray.iTagArr.Length());
	}

//------------------------------------------------------------------

	TCCIMPORT void PushBackL(const TccTagData& aTagData);

	/**
	* @brief PushBackL д������(����Ѿ������Ǹ�tag,��ô�����ݻ�����ͬ��tag�����ݺ���)
	* @param[in] aProp - д�������
	*/
	inline void PushBackL(const TccTagRowData& aProp){
		PushBackL(aProp.iTag, aProp.iData, aProp.iLen);
	}

	/**
	* @brief PushBackL д������(����Ѿ������Ǹ�tag,��ô�����ݻ�����ͬ��tag�����ݺ���)
	* @param[in] aTagId Tag��ID��
	* @param[in] aData Ҫд�������
	* @param[in] aLen Ҫд������ݵĳ���
	*/
	TCCIMPORT void PushBackL(tu32 aTagId, const void* aData, ti32 aLen);
	TCCIMPORT void ReplaceL(tu32 aTagId, const void* aData, ti32 aLen);
	TCCIMPORT void Remove(tu32 aTagId);

	TCCIMPORT void RemoveByIndex(ti32 aIndex);

	/**
	* @brief Clear �����������
	*/
	TCCIMPORT void Clear();
	
	/**
	 * ��������ջ����
	 */
	TCCIMPORT void Close();

	TCCIMPORT void Zero();
	
	///����ֵ�����tagformat�����ж��ٸ����tag������
	TCCIMPORT ti32 Find(tu32 aTagId, Iterator& aIt) const;
	
	TCCIMPORT tbool At(ti32 aIndex, Iterator& aIt) const;
	
	
	/**
	* @brief Begin ��ȡ��һ��Tag���ݵ�λ��
	* @param[out] aIt ����һ��������ʵ��,�����޸�
	*/
	inline void Begin(Iterator& aIt) const {aIt.Set(iTagArr.Ptr(), iTagArr.Length());}


	/**
	* @brief Begin ��ȡ��һ��Tag���ݵ�λ��
	* @return ���ص�һ��Tag���ݵ�λ�õĵ�����,�����޸�
	*/
	inline Iterator Begin() const {return Iterator(iTagArr.Ptr(), iTagArr.Length());}

	/**
	* @brief End ��ȡ�յ�����
	* @param[out] aIt ����һ��������ʵ��,�����޸�
	*/
	inline void End(Iterator& aIt) const {aIt.Set(NULL, 0);}
	
	/**
	* @brief End ��ȡ��һ��Tag���ݵ�λ��
	* @return ����һ���յĵ�����,�����޸�
	*/
	inline Iterator End() const {return Iterator(NULL, 0);}


	/** 
	* @brief  ����chunks����Ŀ
	* @return numChunks����Ŀ
	*/
	TCCIMPORT ti32 NumberOfChunks() const;

	///�����Ƿ��Ѿ������Ǹ�TagId
	TCCIMPORT tbool IsHaveTagId(tu32 aTagId) const;

	//ѹ��
	TCCIMPORT void Compress();


	TCCIMPORT ti32 FindPath(tu32* aPath, ti32 aPathLen, Iterator& aIt) const;

	TCCIMPORT ti32 CountInternalizeLen(const void* aPtr, ti32 aLen) const;
	inline terror Internalize(const TccDesC8& aBuf){return Internalize(aBuf.Ptr(), aBuf.Length());}
	TCCIMPORT terror Internalize(const void* aPtr, ti32 aLen); //��,�ⲿ���ݽ������ڴ���ʽ��tagformat
	TCCIMPORT ti32 CountExternalizeLen() const;
	TCCIMPORT terror Externalize(TccStr8& aBuf) const; //��,д�ļ�ʱ����

	//����
	TCCIMPORT terror Clone(const TccTagArray& aTagArray);
	
	
protected:
	TCCIMPORT void DoExternalize(TccStr8& aBuf) const; //��,д�ļ�ʱ����


};




#endif //__TCC_TAG_ARRAY_H_DEFINE__



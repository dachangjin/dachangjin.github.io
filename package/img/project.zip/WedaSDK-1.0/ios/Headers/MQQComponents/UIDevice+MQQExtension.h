//
//  UIDevice+MQQExtension.h
//  Pods
//
//  Created by klaudz on 1/7/2019.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIDevice (MQQExtension)

- (NSString *)mqqIdentifier;

@end

NS_ASSUME_NONNULL_END

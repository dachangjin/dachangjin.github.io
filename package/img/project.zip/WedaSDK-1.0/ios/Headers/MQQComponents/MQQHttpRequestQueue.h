//
//  MQQHttpRequestQueue.h
//  MQQSecure
//
//  Created by Kloudz Liang on 13-12-13.
//  Copyright (c) 2013年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MQQHttpRequest.h"

extern NSInteger const MQQHttpRequestDefaultMaxConcurrentCount;

@interface MQQHttpRequestQueue : NSObject
@property(nonatomic,assign) NSInteger maxConcurrentRequestCount;
- (void)requestWillStart:(MQQHttpRequest *)request;
- (void)requestDidStop:(MQQHttpRequest *)request;
@end



@interface MQQHttpRequest ()
- (void)_startAsynchronous;
@end
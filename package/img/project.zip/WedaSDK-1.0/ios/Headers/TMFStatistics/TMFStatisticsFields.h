//
//  TMFStatisticsFields.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#ifndef TMFStatisticsFields_h
#define TMFStatisticsFields_h

#define filed_ky (1)        // 应用key
#define filed_et (2)        // 事件类型
#define filed_vid (3)       //
#define filed_guid (4)      //
#define filed_oaid (5)      //
#define filed_imei (6)      //
#define filed_si (7)        // 会话id
#define filed_idx (8)       // 会话内事件序号
#define filed_ts (9)        // 客户端时间戳
#define filed_cui (10)      // 自定义用户id
#define filed_hybridH5 (11) // 是否来源hybridH5
#define filed_pi (12)       // 页面路径
#define filed_rf (13)       // 上一级页面路径
#define filed_du (14)       // 时长
#define filed_lbl (15)      // 用户标签
#define filed_ei (16)       // 自定义事件id
#define filed_kv (17)       // 自定义属性
#define filed_tsv (18)      // tmf移动分析tmf sdk version
#define filed_pf (19)       // tmf移动分析sdk的平台
#define filed_apn (20)      // 包名
#define filed_av (21)       // APP版本
#define filed_ch (22)       // 渠道
#define filed_os (23)       // 平台
#define filed_ov (24)       // android SDK API level
#define filed_osn (25)      // 系统版本
#define filed_jb (26)       // 是否root或越狱
#define filed_ua (27)       // useAgent
#define filed_lg (28)       // 系统语言类型
#define filed_mf (29)       // 设备生产商
#define filed_md (30)       // 设备型号
#define filed_sr (31)       // 屏幕分辨率
#define filed_dpi (32)      // 屏幕dpi
#define filed_tz (33)       // 系统的时区
#define filed_ram (34)      // 内存可用/总量
#define filed_rom (35)      // sdcard可用/总量
#define filed_cpu (36)      // 核数/最小频率//最大频率/名称
#define filed_ipv4 (37)     //
#define filed_ipv6 (38)     //
#define filed_mac (39)      //
#define filed_tn (40)       // 设备网络类型
#define filed_wf (41)       // wifi信息
#define filed_geo (42)      // 位置信息
#define filed_e_ea (43)     // 错误属性
#define filed_e_pna (44)    // 进程名称
#define filed_e_pid (45)    // 进程id
#define filed_e_thn (46)    // 线程id
#define filed_e_na (47)     // 线程名称
#define filed_e_pr (48)     // 线程优先级
#define filed_e_fra (49)    // 堆栈信息
#define filed_e_md5 (50)    // 堆栈信息md5

#endif /* TMFStatisticsFields_h */

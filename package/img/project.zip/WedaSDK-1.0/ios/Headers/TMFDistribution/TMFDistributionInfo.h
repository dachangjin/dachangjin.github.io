//
//  TMFDistributionInfo.h
//  TMFDistribution
//
//  Created by bentonxiu on 2019/8/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 *  @brief  发布更新数据模型 用于更新数据传递
 */
@interface TMFDistributionInfo : NSObject <NSCoding, NSCopying>

@property (nonatomic, assign) BOOL updatesForcibly;         ///< 是否强制更新
@property (nonatomic, assign) NSInteger noticeTimeInterval; ///< 更新提示周期
@property (nonatomic, retain) NSURL *appStoreURL;           ///< 更新的 App Store 链接
@property (nonatomic, copy) NSString *versionString;        ///< 更新版本号
@property (nonatomic, copy) NSString *buildNumberString;    ///< 更新 Build 号
@property (nonatomic, copy, nullable) NSString *distributionTitle;   ///< 更新标题
@property (nonatomic, copy, nullable) NSString *featureDescription;  ///< 更新的功能描述

@end

NS_ASSUME_NONNULL_END

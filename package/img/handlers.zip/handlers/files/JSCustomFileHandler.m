//
//  WAJSCustomFilleHandler.m
//  WedaSDK_Example
//
//  Created by tommywwang on 2021/11/11.
//  Copyright © 2021 tommywwang. All rights reserved.
//

#import "JSCustomFileHandler.h"

@implementation JSCustomFileHandler

/// 支持的方法集合
- (NSArray<NSString *> *)supportMethods
{
    return @[@"readLocalFile"];
}

/// 处理事件
/// @param event 事件
- (void)handleEvent:(WAJSCustomEvent *)event
{
    if ([event.funcName isEqual:@"readLocalFile"]) {
        /// 获取js端参数
        NSString *filePath = event.args[@"path"];
        ///省略读取文件代码
        ///.........
        /// 本地读取文件
        NSString *fileData = @"我是根据filePath读取的内容";
        /// 执行回调
        if (event.callback) {
            event.callback(@{
                @"data": fileData
                           });
        }
    }
}

@end

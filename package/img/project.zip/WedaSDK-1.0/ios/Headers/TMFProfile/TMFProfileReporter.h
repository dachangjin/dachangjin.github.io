//
//  TMFProfileReporter.h
//  TMFDemo
//
//  Created by  bentonxiu on 2019/7/1.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFProfileDefines.h"

NS_ASSUME_NONNULL_BEGIN

@class TMFProfileItem;

/**
 *  Profile 上报中心 用于处理更新 + 上报
 */
@interface TMFProfileReporter : NSObject

+ (instancetype)defaultReporter;
- (void)initialize;

+ (void)clearCacheData;

/**
 *  上报全部 Profile 内容
 *  
 *  @note 此上报是增量上报 根据对比状态来上报需要更新的内容
 */
- (void)reportIfNeeded;

@end

@interface TMFProfileReporter (Common)

- (void)updateProfileWithID:(TMFProfileID)profileID boolValue:(BOOL)boolValue;
- (void)updateProfileWithID:(TMFProfileID)profileID dataValue:(nullable NSData *)dataValue;
- (void)updateProfileWithID:(TMFProfileID)profileID stringValue:(nullable NSString *)stringValue;
- (void)updateProfileWithID:(TMFProfileID)profileID integerValue:(NSInteger)integerValue;

@end

/**
 *  Profile 上报中心用户信息上报扩展 用于上报用户信息
 */
@interface TMFProfileReporter (UserInfo)

/**
 *  上报用户 user ID
 *
 *  @note  如果参数为空 则视为解绑
 *  @param customizedUserID 用户自定义 user ID
 */
- (void)updateCustomizedUserID:(nullable NSString *)customizedUserID;

/**
 *  上报用户远程推送 Token
 *
 *  @param deviceToken 用户远程推送 Token
 */
- (void)updateRemoteNotificationToken:(NSString *)deviceToken;

@end

/**
 *  Profile 上报中心自定义标签上报扩展 用于修改自定义标签
 */
@interface TMFProfileReporter (Tag)

/**
 *  实时上报回调
 *
 *  @param  error 本次上报错误信息 如果成功 则为 nil
 */
typedef void(^TMFProfileResponseHandler)(NSError * _Nullable error);

/**
 *  上报修改自定义标签
 *
 *  @note  `tagValue` 为空 则是删除当前标签
 *  @note  此接口是延迟上报 不会立刻回调 可以通过 `TMFProfileDidReportNotification` 捕获结果
 *  @note  如果选择此接口 则默认 SDK 自动管理上报重试流程
 *  @param tagKey   标签名
 *  @param tagValue 标签值
 */
- (void)updateCustomizedTagWithKey:(NSString *)tagKey value:(nullable NSString *)tagValue;

/**
 *  立刻上报自定义标签
 *
 *  @note  `tagValue` 为空 则是删除当前标签
 *  @note  由于此接口是立刻上报并回调 因此与 `-updateCustomizedTagWithKey:value:` 不通用 并不建议二者混用
 *  @note  如果选择此接口 则默认自行管理上报重试流程
 *  @param tagKey   标签名
 *  @param tagValue 标签值
 *  @param responseHandler  上报回调
 */
- (void)updateCustomizedTagWithKey:(NSString *)tagKey
                             value:(NSString *)tagValue
                   responseHandler:(TMFProfileResponseHandler)responseHandler;

@end

@interface TMFProfileReporter (Debug)

/**
 *  上报组件日志级别 release 模式下请设置 `TMFProfileLogNone`
 *
 *  @note   使用 [TMFProfile] 筛选日志
 */
@property (nonatomic, assign) TMFProfileLogLevel logLevels
    DEPRECATED_MSG_ATTRIBUTE("use +setLogLevels: instead");

/**
 *  设置数据同步组件日志级别
 *
 *  @note   日志级别 详见「TMFProfileLogLevel」
 */
@property (class, nonatomic, assign) TMFProfileLogLevel logLevels;

@end

NS_ASSUME_NONNULL_END


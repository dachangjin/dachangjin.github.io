//
//  JSEvent.h
//  weapps
//
//  Created by tommywwang on 2020/6/3.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class WAWebView;

@interface WAJSEvent : NSObject


/// 方法名
@property (nonatomic, copy) NSString *funcName;

/// 参数
@property (nonatomic, copy, nullable) NSDictionary *args;

/// 事件所发生所在webView
@property (nonatomic, strong) WAWebView *webView;


@end

NS_ASSUME_NONNULL_END

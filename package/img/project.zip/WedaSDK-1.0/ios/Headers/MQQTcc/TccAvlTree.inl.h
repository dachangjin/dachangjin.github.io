#ifndef __TCC_AVL_TREE_H_DEFINE__
#define __TCC_AVL_TREE_H_DEFINE__


#include "TccBase.h"
#include "TccContainerBase.inl.h"


template <typename T, typename _traits = TccTraits<T> >
class TccAvlTree {

protected:

	enum TNodeBalance{
		EAlvTreeBalanced,
		EAlvTreeLeftHigh,
		EAlvTreeRightHigh
	};
	
	class Node {
	public:
		Node* iLeftPtr;
		Node* iRightPtr;
		T iElement;
		TNodeBalance iBalance;

		Node(){
			iLeftPtr = NULL;
			iRightPtr = NULL;
			iBalance = EAlvTreeBalanced;
		}

		Node(const T& aElement) : iElement(aElement){
			iLeftPtr = NULL;
			iRightPtr = NULL;
			iBalance = EAlvTreeBalanced;
		}

		~Node(){}
	};

	void rotate_left(Node*& p){
		Node* temporary = p->iRightPtr;
		p->iRightPtr = temporary->iLeftPtr;
		temporary->iLeftPtr = p;
		p = temporary;
	}

	void rotate_right(Node*& p){
		Node* temporary = p->iLeftPtr;
		p->iLeftPtr = temporary->iRightPtr;
		temporary->iRightPtr = p;
		p = temporary;
	}

	Node* balance_left(Node* p){
		Node* left = p->iLeftPtr;
		switch (left->iBalance)
		{
		case EAlvTreeLeftHigh:
			p->iBalance = EAlvTreeBalanced;
			left->iBalance = EAlvTreeBalanced;
			rotate_right(p);
			break;
		case EAlvTreeRightHigh:
			{
				Node* subright = left->iRightPtr;
				switch (subright->iBalance)
				{
				case EAlvTreeBalanced:
					p->iBalance = EAlvTreeBalanced;
					left->iBalance = EAlvTreeBalanced;
					break;
				case EAlvTreeRightHigh:
					p->iBalance = EAlvTreeBalanced;
					left->iBalance = EAlvTreeLeftHigh;
					break;
				case EAlvTreeLeftHigh:
					p->iBalance = EAlvTreeRightHigh;
					left->iBalance = EAlvTreeBalanced;
					break;
				}
				subright->iBalance = EAlvTreeBalanced;
				rotate_left(left);
				p->iLeftPtr = left;
				rotate_right(p);
			}
			break;
		case EAlvTreeBalanced:
			p->iBalance = EAlvTreeLeftHigh;
			left->iBalance = EAlvTreeRightHigh;
			rotate_right(p);
			break;
		}
		return p;
	}

	Node* balance_right(Node* p){
		Node* right = p->iRightPtr;
		switch (right->iBalance)
		{
		case EAlvTreeRightHigh:
			p ->iBalance = EAlvTreeBalanced;
			right->iBalance = EAlvTreeBalanced;
			rotate_left(p);
			break;
		case EAlvTreeLeftHigh:
			{
				Node* subleft = right->iLeftPtr;
				switch (subleft->iBalance)
				{
				case EAlvTreeBalanced:
					p->iBalance = EAlvTreeBalanced;
					right->iBalance = EAlvTreeBalanced;
					break;

				case EAlvTreeLeftHigh:
					p->iBalance = EAlvTreeBalanced;
					right->iBalance = EAlvTreeRightHigh;
					break;

				case EAlvTreeRightHigh:
					p->iBalance = EAlvTreeLeftHigh;
					right->iBalance = EAlvTreeBalanced;
					break;
				}
				subleft->iBalance = EAlvTreeBalanced;
				rotate_right(right);
				p->iRightPtr = right;
				rotate_left(p);
			}
			break;
		case EAlvTreeBalanced:
			p ->iBalance = EAlvTreeRightHigh;
			right->iBalance = EAlvTreeLeftHigh;
			rotate_left(p);
			break;
		}
		return p;
	}

	tbool insert(Node*& p, Node* newp){

		if(p == NULL){
			p = newp;
			iSize++; //ά��size��ֵ
			return ttrue;
		}

		ti32 compare_result = _traits::Compare(newp->iElement, p->iElement); // Call comparator

		if (compare_result == 0){						// Element Exists
			_traits::DeleteHandle(p->iElement); //���Ǵ���,�ڴ�й©�͹��˹���
			p->iElement = newp->iElement;
			delete newp;
			return tfalse;
		}

		tbool taller = tfalse;

		// Current element greater than add element so go left in tree
		if (compare_result < 0){
			if (insert(p->iLeftPtr, newp)){					// Recursive call to Add.
				switch (p->iBalance)						// If taller adjust the balance factors
				{
				case EAlvTreeLeftHigh:							// This case requires rotations
					p = balance_left(p);
					taller = tfalse;					// taller false after rotations
					break;
				case EAlvTreeBalanced:							// EAlvTreeBalanced -> EAlvTreeLeftHigh - no rotations
					p->iBalance = EAlvTreeLeftHigh;
					taller = ttrue;					// taller is true in this case
					break;
				case EAlvTreeRightHigh:							// Right High -> EAlvTreeBalanced - no rotations
					p->iBalance = EAlvTreeBalanced;
					taller = tfalse;					// taller is false in this case
					break;
				}
			}
			else
				taller = tfalse;
		}
		else{											// Current element less than add element so go right in tree
			if (insert(p->iRightPtr, newp)){				// Recursive call to Add.
				switch(p->iBalance)						// If taller adjust the balance factors
				{
				case EAlvTreeLeftHigh:							// Left High -> EAlvTreeBalanced - no rotations
					p->iBalance = EAlvTreeBalanced;
					taller = tfalse;					// taller is false in this case
					break;
				case EAlvTreeBalanced:							// EAlvTreeBalanced -> EAlvTreeRightHigh - no rotations
					p->iBalance = EAlvTreeRightHigh;
					taller = ttrue;					// taller is true in this case
					break;
				case EAlvTreeRightHigh:							// This case requires rotations
					p = balance_right(p);
					taller = tfalse;					// taller false after rotations
					break;
				}
			}
			else
				taller = tfalse;
		}
		return taller;
	}

	template<class KEY>
	tbool erase(Node*& p, const KEY& key, T& data_result, tbool& isFind){
		if (NULL == p) return tfalse;

		tbool shorter = tfalse;

		// Looking for the node to be removed
		ti32 compare_result = _traits::Compare(key, p->iElement); // Call comparator

		if (compare_result == 0){ // Item is found

			// If left and right subtrees exist find previous
			// in order node and continue the recursion

			if (p->iLeftPtr != NULL && p->iRightPtr != NULL){

				Node* replace = p->iLeftPtr;
				while (replace->iRightPtr != NULL) replace = replace->iRightPtr;

				TccCntrSwap(p->iElement, replace->iElement);

				if (erase(p->iLeftPtr, key, data_result, isFind)){
					switch (p->iBalance)
					{
					case EAlvTreeLeftHigh:
						p->iBalance = EAlvTreeBalanced;
						shorter = ttrue;
						break;

					case EAlvTreeBalanced:
						p->iBalance = EAlvTreeRightHigh;
						shorter = tfalse;
						break;

					case EAlvTreeRightHigh:
						if (EAlvTreeBalanced == p->iRightPtr->iBalance)
							shorter = tfalse;
						else
							shorter = ttrue;
						p = balance_right(p);
						break;
					}
				}
				else{
					shorter = tfalse;
				}
			}
			else{									// Either left or right subtree is 0
				Node* to_delete = p;			// Pointer to delete memory

				if (p->iLeftPtr == NULL)
					p = p->iRightPtr;
				else 
					p = p->iLeftPtr;

				data_result = to_delete->iElement;
				isFind = ttrue;

				delete to_delete;
				to_delete = NULL;

				shorter = ttrue;

				iSize--; //ά��size��ֵ
			}
		}
		// Remove key is less than current so operate on the left subtree
		else if (compare_result < 0){
			if (erase(p->iLeftPtr, key, data_result, isFind)){
				switch (p->iBalance)
				{
				case EAlvTreeLeftHigh:
					p->iBalance = EAlvTreeBalanced;
					shorter = ttrue;
					break;
				case EAlvTreeBalanced:
					p->iBalance = EAlvTreeRightHigh;
					shorter = tfalse;
					break;
				case EAlvTreeRightHigh:
					if (EAlvTreeBalanced == p->iRightPtr->iBalance)
						shorter = tfalse;
					else
						shorter = ttrue;
					p = balance_right(p);
					break;
				}
			}
			else{
				shorter = tfalse;
			}
		}
		else{ // Remove key is greater than current so operate on the right subtree
			if (erase(p->iRightPtr, key, data_result, isFind)){
				switch (p->iBalance)
				{
				case EAlvTreeRightHigh:
					p->iBalance = EAlvTreeBalanced;
					shorter = ttrue;
					break;
				case EAlvTreeBalanced:
					p->iBalance = EAlvTreeLeftHigh;
					shorter = tfalse;
					break;
				case EAlvTreeLeftHigh:
					if (EAlvTreeBalanced == p->iLeftPtr->iBalance)
						shorter = tfalse;
					else
						shorter = ttrue;
					p = balance_left(p);
					break;
				}
			}
			else{
				shorter = tfalse;
			}
		}
		return shorter;
	}
/*
	void clear(Node* p){
		if (NULL != p){
			if (p->iLeftPtr != NULL) clear(p->iLeftPtr);
			if (p->iRightPtr != NULL) clear(p->iRightPtr);
			delete p;
			p = NULL;
		}
	}

	void destroy(Node* p){
		if (NULL != p){
			if (p->iLeftPtr != NULL) destroy(p->iLeftPtr);
			if (p->iRightPtr != NULL) destroy(p->iRightPtr);
			_traits::DeleteHandle(p->iElement);
			delete p;
			p = NULL;
		}
	}
*/
	template<class KEY>
	Node* find(const KEY& key) const {
		Node* search = iRoot;
		ti32 compare_result = 0;
		while(NULL != search){
			compare_result = _traits::Compare(key, search->iElement); // Call comparator
			if (compare_result < 0){
				search = search->iLeftPtr;
			}
			else if (compare_result > 0){
				search = search->iRightPtr;
			}
			else{
				break;
			}
		}
		return search;
	}

public:

	class Iterator{
	protected:
		Node* iNode[32];
		ti32 iDeep;
	public:
		friend class TccAvlTree;
		Iterator(Node* r){
			Set(r);
		}
		void Set(Node* r){
			iDeep = 0;
			while(r != NULL && iDeep < 32){
				iNode[iDeep++] = r;
				r = r->iLeftPtr;
			}
		}

		void SetOne(Node* r){
			iDeep = 0;
			iNode[iDeep++] = r;
		}
		
	public:
		Iterator(){iDeep = 0;}
		Iterator(const Iterator& it){*this = it;}

		Iterator& operator=(const Iterator& it){
			iDeep = it.iDeep;
			TccMemcpy(iNode, it.iNode, iDeep * sizeof(Node*));
			return *this;
		}

		T& operator*(){
			TccAssert(iDeep > 0);
			return (iNode[iDeep - 1])->iElement;
		}

		T* operator->(){
			TccAssert(iDeep > 0);
			return &((iNode[iDeep - 1])->iElement);
		}

		const T& operator*() const {
			TccAssert(iDeep > 0);
			return (iNode[iDeep - 1])->iElement;
		}

		const T* operator->() const {
			TccAssert(iDeep > 0);
			return &((iNode[iDeep - 1])->iElement);
		}

		void operator++(){ //++xx
			if(iDeep > 0){ //��û����
				Node* p = iNode[iDeep - 1]->iRightPtr; //��ȡ��ûö�ٵ��ҽڵ�
				iDeep--; //�ѵ�ǰ�Ѿ�ö�ٵĽڵ㵯��յ
				while (NULL != p){ //����һ���ڵ���ҽڵ��Լ��ýڵ��ȫ����ڵ�ѹ��յ
					iNode[iDeep++] = p;
					p = p->iLeftPtr;
				}
			}
		}

		tbool operator==(const Iterator& it){
			return (it.iDeep == iDeep && (0 == iDeep || 0 == TccMemcmp(iNode, it.iNode, iDeep * sizeof(Node*))));
		}

		void operator++(int){++(*this);}
		tbool operator!=(const Iterator& it){return !(*this == it);}
		//tbool operator!(){return (0 != iDeep);}
		tbool isEnd(){return (tbool)(0 == iDeep);}
	};

protected:
	TccAvlTree() {iRoot = NULL; iSize = 0;}
public:
	~TccAvlTree() {Clear();}
	
	Iterator Begin() const {return Iterator(iRoot);}
	Iterator End() const {return Iterator(NULL);}
	void Begin(Iterator& aIt) const {aIt.Set(iRoot);}
	void End(Iterator& aIt) const {aIt.Set(NULL);}

	tbool Empty() const { return (iRoot == NULL); }

	void Clear(){ ///<it will not call key and value's deleter fun.
		Node* aNode[32];
		ti32 aDeep = 0;
		Node* p = iRoot;
		while(NULL != p && aDeep < 32){
			aNode[aDeep++] = p;
			p = p->iLeftPtr;
		}
		while (aDeep > 0){
			aDeep--; //�ѵ�ǰ�Ѿ�ö�ٵĽڵ㵯��յ
			iRoot = aNode[aDeep];
			p = iRoot->iRightPtr; //��ȡ��ûö�ٵ��ҽڵ�
			while (NULL != p){ //����һ���ڵ���ҽڵ��Լ��ýڵ��ȫ����ڵ�ѹ��յ
				aNode[aDeep++] = p;
				p = p->iLeftPtr;
			}
			delete iRoot;
			iRoot = NULL;
		}
		iRoot = NULL;
		iSize = 0;
	}

	void Destroy(){
		Node* aNode[32];
		ti32 aDeep = 0;
		Node* p = iRoot;
		while(NULL != p && aDeep < 32){
			aNode[aDeep++] = p;
			p = p->iLeftPtr;
		}
		while (aDeep > 0){
			aDeep--; //�ѵ�ǰ�Ѿ�ö�ٵĽڵ㵯��յ
			iRoot = aNode[aDeep];
			p = iRoot->iRightPtr; //��ȡ��ûö�ٵ��ҽڵ�
			while (NULL != p){ //����һ���ڵ���ҽڵ��Լ��ýڵ��ȫ����ڵ�ѹ��յ
				aNode[aDeep++] = p;
				p = p->iLeftPtr;
			}
			_traits::DeleteHandle(iRoot->iElement);
			delete iRoot;
			iRoot = NULL;
		}
		iRoot = NULL;
		iSize = 0;
	}

	inline ti32 Size() const {return iSize;}

protected:
	Node* iRoot;
	ti32 iSize;
};

#endif //__TCC_AVL_TREE_H_DEFINE__



//
//  JSEvent.m
//  weapps
//
//  Created by tommywwang on 2020/6/2.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "JSAsyncEvent.h"

@implementation JSAsyncEvent

@end

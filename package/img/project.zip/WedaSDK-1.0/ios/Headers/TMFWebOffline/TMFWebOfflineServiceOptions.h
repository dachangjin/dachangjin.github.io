//
//  TMFWebOfflineServiceOptions.h
//  TMFWebOffline
//
//  Created by klaudz on 17/6/2019.
//

#import <Foundation/Foundation.h>
#import "TMFWebOfflineUtilities.h"

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 离线包更新可选设置项
 */
@interface TMFWebOfflineServiceOptions : NSObject

/**
 @brief 离线包更新可选设置项实例
 */
+ (instancetype)options;

/**
 @brief Mask，默认0
 */
@property (nonatomic, assign) NSInteger mask;

/**
 @brief 更新来源，默认 `TMFWebOfflineServiceOptionsSourceRequest`
 */
@property (nonatomic, assign) TMFWebOfflineServiceOptionsSource source;

/**
 @brief 本地缓存更新策略，默认 `TMFWebOfflineServiceOptionsCachePolicyDownloadAndUpdate`
 */
@property (nonatomic, assign) TMFWebOfflineServiceOptionsCachePolicy cachePolicy;

/**
 @brief 是否忽略更新频率，默认NO
 */
@property (nonatomic, assign) BOOL ignoresFrequency;

/**
 @brief 是否忽略调用延迟，默认YES
 */
@property (nonatomic, assign) BOOL ignoresDelay;

@end

NS_ASSUME_NONNULL_END

//
//  TMFStatisticsReporter.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/10/28.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TMFStatisticsConfiguration.h"
#import "TMFStatistics_ReportRecord.h"
#import "TMFStatistics_CSReportInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter : NSObject

+ (instancetype)defaultReporter;

- (void)insertWithReportRecord:(nullable TMFStatistics_ReportRecord *)reportRecord;

- (void)report;
- (void)reportWithCompletionHandler:(nullable void (^)(NSError * _Nullable error))completionHandler;

@end

NS_ASSUME_NONNULL_END

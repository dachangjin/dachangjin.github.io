//
//  TMFStatisticsReporter+Cache.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

#define SAF_PAGE_APP     @"__report_cache_SAF_PAGE_APP"

#define SAF_CONSUMING_PAGE(page_str)   ([NSString stringWithFormat:@"%@", page_str])

@interface TMFStatisticsReporterPage : NSObject

@property (nonatomic, copy, readonly) NSString *page;
@property (nonatomic, copy, nullable, readonly) NSString *refPage;

@property (nonatomic, assign, readonly) BOOL hybridH5;
@property (nonatomic, assign, readonly) NSInteger timestamp;

+ (instancetype)pageWithPage:(NSString *)page refPage:(nullable NSString *)refPage hybridH5:(BOOL)hybridH5;

- (NSInteger)duration;

- (void)update;

@end

@interface TMFStatisticsReporter (Cache)

- (void)cacheAlloc;

#pragma mark - Time Consuming

- (void)setConsumingTime:(NSInteger)timestamp forKey:(NSString *)key;
- (void)removeConsumingTimeForKey:(NSString *)key;
- (NSInteger)consumingTimeForKey:(NSString *)key;

#pragma mark - Page

- (void)setPage:(TMFStatisticsReporterPage *)page forKey:(NSString *)key;
- (void)removePageForKey:(NSString *)key;
- (TMFStatisticsReporterPage *)pageForKey:(NSString *)key;

- (void)pushPage:(NSString *)page;
- (void)popPage:(NSString *)page;
- (nullable NSString *)presentingPageOfPage:(NSString *)page;

- (BOOL)isTopPageOfPage:(NSString *)page;
- (BOOL)isPreviousPageOfPage:(NSString *)page;
- (BOOL)isBottomPageOfPage:(NSString *)page;
- (nullable NSString *)topPage;
- (nullable NSString *)bottomPage;

@end

NS_ASSUME_NONNULL_END

//
//  MQQHttpRequestDefines.h
//  MQQSecure
//
//  Created by klaudz on 23/8/2016.
//  Copyright © 2016 Tencent. All rights reserved.
//

#ifndef MQQHttpRequestDefines_h
#define MQQHttpRequestDefines_h

#define kMQQHttpRequestTimeoutSeconds 3.0f
#define kMQQHttpRequestNumberOfTimesToRetryOnTimeout 1
#define kMQQHttpRequestDownloadBufferSize (512 * 1024)  // 512K

#endif /* MQQHttpRequestDefines_h */

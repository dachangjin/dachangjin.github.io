#ifndef __TCC_SINGLETON_MGR_H_DEFINED__
#define __TCC_SINGLETON_MGR_H_DEFINED__

#include "TccBase.h"
#include "TccConfig.h"

#define __TccSingletonMgrMaxLength__	64

typedef tu32 TSingletonUid;
#define _TSingletonUidUser 0x80U

enum _TccSingletonMgrDefaultUid{
	_TSingletonUidLocalMessageMgr = 0x01U,
	//_TSingletonUidIap = 0x02U,
	_TSingletonUidNetMgr,
	_TSingletonUidNetConn,
};


class TccSingletonMgr{
private:
#if defined(__TccWindows__)
	TCCIMPORT static TccSingletonMgr* _GInstance;
#endif

	TccCleanUpItem iStack[__TccSingletonMgrMaxLength__];
	TSingletonUid iUid[__TccSingletonMgrMaxLength__];
	ti32 iPos;

	TCCIMPORT TccSingletonMgr();
	TCCIMPORT void add(TccPtrDeleteHandle aOperation, void* aPtr, TSingletonUid aUid);
	TCCIMPORT void destroy();
	TCCIMPORT void* find(TSingletonUid aUid);
public:

	TCCIMPORT ~TccSingletonMgr();
	TCCIMPORT static TccSingletonMgr* Static();
	TCCIMPORT static TccSingletonMgr* StaticL();

	TCCIMPORT static void* Static(TSingletonUid aId);

	template<typename T>
	static T* StaticT(TSingletonUid aId){
		return static_cast<T*>(Static(aId));
	}
#if 0
	template<class T>
	static TSingletonUid Add(T* aPtr){
		TccSingletonMgr* aMgr = Static();
		if(NULL == aMgr) return 0;
		TSingletonUid aUid = (TSingletonUid)(aMgr->iPos + 1 + _TSingletonUidUser);
		aMgr->add(TccCleanUpPtrTemplate<T>::DeleteHandle, aPtr, aUid);
		return aUid;
	}
#endif
	template<class T>
	static void AddL(T* aPtr, TSingletonUid aUid){
		StaticL()->add(TccCleanUpPtrTemplate<T>::DeleteHandle, (void*)aPtr, aUid);
	}

	template<class T>
	static terror Add(T* aPtr, TSingletonUid aUid){
		TccSingletonMgr* aMgr = Static();
		if(NULL == aMgr) return _TccErrNoMemory;
		Add(TccCleanUpPtrTemplate<T>::DeleteHandle, aPtr, aUid);
		return _TccErrNone;
	}

	TCCIMPORT static void* Remove(TSingletonUid aUid);
	TCCIMPORT static void RemoveAndDestroy(TSingletonUid aUid);
	TCCIMPORT static void Destroy();

};

#endif //__TCC_SINGLETON_MGR_H_DEFINED__


//
//  TMFStatisticsRecordOp.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/10/28.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TMFStatistics_ReportRecord.h"

NS_ASSUME_NONNULL_BEGIN

#define TMF_GetCurrentRecordTime() ({\
    NSInteger interval = [[NSDate date] timeIntervalSince1970]; \
    (interval); \
})

#pragma mark - Model

@interface TMFStatistics_ReportRecord (Record)

@property (nullable, nonatomic, copy, readonly) NSData *eventContext;

@property (nonatomic, assign) NSInteger recordID;
@property (nonatomic, assign) NSInteger timestamp;

@end

@interface TMFStatistics_ReportRecord (Format)

- (NSString *)formatDescription;

@end

#pragma mark - Recorder

@interface TMFStatisticsRecorder : NSObject

- (instancetype)initWithFilePath:(NSString *)filePath;

- (BOOL)insertRecord:(TMFStatistics_ReportRecord *)record;
- (nullable NSArray<TMFStatistics_ReportRecord *> *)getRecords;
- (BOOL)deleteRecords:(NSArray<TMFStatistics_ReportRecord *> *)records;

@end

NS_ASSUME_NONNULL_END

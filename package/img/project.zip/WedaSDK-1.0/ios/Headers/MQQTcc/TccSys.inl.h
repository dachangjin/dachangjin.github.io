#ifndef __TCC_SYS_INL_DEFINE__
#define __TCC_SYS_INL_DEFINE__
//__TccWinCE__
//__TccWin32__
//__TccWindows__
//__TccSymbian__
//__TccPosix__
//__TccBrew__
//__TccMac__
#if defined(ANDROID_NDK)
#define __TccAndroidNDK__
#elif defined(MEEGO_SDK)
#define __TccMeeGo__
#elif defined(__APPLE__)
#define __TccMac__
#elif defined(_LINUX_)
#define __TccPosix__
#elif defined(MMI_ON_WIN32) || defined(__MTK_TARGET__)
#define __TccMtk__
#if defined(MMI_ON_WIN32)
#define __TccMtkEmu__
#endif
#elif defined(__NOUNIX__)
#define __TccArena__
#if defined(WIN32)
#define __TccArenaEmu__
#endif
#elif defined(__SYMBIAN32__)
#include <qqpim_blddef.h>

#define __TccSymbian__
#if defined(__TCB_MODE__)
#define __TccSymbianTcbMode__
#endif
#if defined(__KERNEL_MODE__)
#define __TccSymbianKernel__
#if !defined(__TccSymbianTcbMode__)
#define __TccSymbianTcbMode__
#endif
#endif

#if defined(__S60_5X__) || defined(__S60_50__) || defined(__BLDV5__)
#ifndef __TccSymbian5th__
#define __TccSymbian5th__
#endif
#elif defined(EKA2)
#define __TccSymbian3rd__
#else
#define __TccSymbian2nd__
#endif

#if defined(EKA2)
#define __TccSymbianEka2__
#else
#define __TccSymbianEka1__
#endif

#if defined (__WINS__) || defined (__WINSCW__)
#define __TccSymbianEmu__
#if defined(EKA2)
#define __TccSymbianEka2Emu__
#else
#define __TccSymbianEka1Emu__
#endif
#endif
#ifdef __SERIES60__
#define __TccSeries60__
#elif defined(__UIQ__)
#define __TccUIQ__
#endif //__SERIES60__ , __UIQ__
#elif defined(_WIN32) //#if defined(_WIN32) && !defined(__SYMBIAN32__)
#define __TccWindows__
#if defined (WINAPI_FAMILY)
#if ((WINAPI_FAMILY & WINAPI_PARTITION_APP) == WINAPI_PARTITION_APP)
#define __TccWinMetroAPP__
#endif
#endif //WINAPI_FAMILY
#if defined(_WIN32_WCE) 
#define __TccWinCE__			_WIN32_WCE
#if (__TccWinCE__ >= 0x502)
#define __TccWinCE_WM6__		_WIN32_WCE
#elif (__TccWinCE__ == 0x501)
#define __TccWinCE_WM5__		_WIN32_WCE
#else  // 0x420
#define __TccWinCE_WM42__	_WIN32_WCE
#endif // __TccWinCE__
#if defined (WIN32_PLATFORM_PSPC)
#define __TccPocketPC__		_WIN32_WCE
#if (__TccPocketPC__ >= 0x502)
#define __TccPocketPC_WM6__
#elif (__TccPocketPC__ == 0x501)
#define __TccPocketPC_WM5__
#else  // 0x420
#define __TccPocketPC_WM42__
#endif // __TccPocketPC__
#elif defined (WIN32_PLATFORM_WFSP)
#define __TccSmartphone__	_WIN32_WCE
#if (__TccSmartphone__ >= 0x502)
#define __TccSmartphone_WM6__
#elif (__TccSmartphone__ == 0x501)
#define __TccSmartphone_WM5__
#else  // 0x420
#define __TccSmartphone_WM42__
#endif // __TccSmartphone__
#else // WinCE
#define __TccWinCEBase__		_WIN32_WCE
#if defined(_WinceM8)
#define __TccWinceM8__
#elif (__TccWinCEBase__ == 500) // or defined (WCE_PLATFORM_STANDARDSDK_500)
#define __TccWinCEBase_WM5__
#else // or defined (WCE_PLATFORM_STANDARDSDK)
#define __TccWinCEBase_WM42__
#endif //__TccWinCEBase__
#endif
#else //_WIN32_WCE
#define __TccWin32__
#if defined (_DEBUG)
#define __TccWin32_Debug__
#endif //_DEBUG
#endif //_WIN32_WCE
#endif //_WIN32


/************************************************************************/
/*                                                                      */
/************************************************************************/
#if defined(__TccAndroidNDK__) || defined(__TccMac__) || defined(__TccMeeGo__) || defined(__TccPosix__)
#define TCC_CAN_USE_POSIX
#elif defined(__TccSymbian__)
#define TCC_CAN_USE_SYMBIAN
#elif defined(__TccWindows__)
#define TCC_CAN_USE_WIN
#endif

#endif //__TCC_SYS_INL_DEFINE__


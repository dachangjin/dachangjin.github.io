//
//  MQQHttpRequest.h
//  MQQSecure
//
//  Created by Jimmy Ding on 9/12/13.
//  Modified by klaudz on 11/19/13.
//  Copyright (c) 2013 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MQQHttpRequestError.h"
#import "NSURLSessionConfiguration+MQQHttpRequest.h"

typedef NS_ENUM(NSInteger, MQQHttpRequestPriority) {
    //MQQHttpRequestPriorityLow     = -1,   // 低优先级
    MQQHttpRequestPriorityNormal    = 0,    // 正常优先级
    //MQQHttpRequestPriorityHigh    = 1,    // 高优先级
    MQQHttpRequestPrioritySuper     = 9,    // 超级优先级，不受maxConcurrentRequestCount限制，在队列中，直接开始(如RSA、GUID等极高优先级请求时使用)
    MQQHttpRequestPriorityExtreme   = 10,   // 无敌优先级，不受队列maxConcurrentRequestCount限制，不在队列中，直接开始(慎用，提供给WupRequest同步方法改异步实现时使用)
    
    MQQHttpRequestPriorityDefault = MQQHttpRequestPriorityNormal // 默认优先级
};

@interface MQQHttpRequest : NSObject <NSURLConnectionDelegate> {
    
    NSInteger _responseStatusCode;
    NSDictionary *_responseHeaders;
    unsigned long long _receivedDataLength;
    
    dispatch_block_t _completionBlock;
    dispatch_block_t _failedBlock;
}
// state
@property(nonatomic,assign,readonly) BOOL        isCompleted; // return YES if request completed successfully or failed.
@property(nonatomic,assign,readonly) BOOL        isCancelled; // return YES if request is cancelled.
// request
@property(nonatomic,assign) NSTimeInterval       timeOutSeconds;
@property(nonatomic,assign) NSInteger            numberOfTimesToRetryOnTimeout;
@property(nonatomic,retain) NSString            *requestMethod;
@property(nonatomic,retain) NSMutableData       *postBody;
@property(nonatomic,assign) MQQHttpRequestPriority priority;
@property(nonatomic,assign) BOOL                 allowsCellularAccess;
// response
@property(nonatomic,assign,readonly) unsigned long long receivedDataLength;
@property(nonatomic,retain) NSData              *responseData;
@property(nonatomic,retain) NSError             *error;
@property(nonatomic,assign,readonly) NSInteger   responseStatusCode;
@property(nonatomic,retain,readonly) NSDictionary *responseHeaders;
// download
@property(nonatomic,assign) BOOL                 allowResumeForFileDownloads;
@property(nonatomic,copy)   NSString            *downloadDestinationPath;
@property(nonatomic,copy)   NSString            *temporaryFileDownloadPath;
@property(nonatomic,assign,readonly) unsigned long long resumeOffsetForFileDownload;
//@property(nonatomic,assign,readonly) unsigned long long sizeForFileDownload; // 下载文件的总大小，在didReceiveResponseHeaders后才能取得
// delegate
@property(nonatomic,assign) id                   delegate;
@property(nonatomic,readonly) NSUInteger         ID; // 唯一码
@property(nonatomic,retain) NSDictionary        *userInfo;  // 用户数据，调用者赋值，可以用来辨认身份、数据传输
// call back
@property(assign) SEL                            didReceiveResponseHeadersSelector; // Sample:  - (void)httpRequestDidReceiveResponseHeaders:(MQQHttpRequest *)httpRequest;
@property(assign) SEL                            didReceiveDataSelector;            // Sample:  - (void)httpRequest:(MQQHttpRequest *)httpRequest didReceiveData:(NSData *)data;
@property(assign) SEL                            didFinishSelector;                 // Sample:  - (void)httpRequestDidFinish:(MQQHttpRequest *)httpRequest;
@property(assign) SEL                            didFailSelector;                   // Sample:  - (void)httpRequestDidFail:(MQQHttpRequest *)httpRequest;
@property(assign) SEL                            willPerformRedirectionSelector;    // Sample:  - (nullable NSURLRequest *)httpRequest:(MQQHttpRequest *)httpRequest willPerformRedirection:(NSURLResponse *)response newRequest:(NSURLRequest *)request;
// block
- (void)setCompletionBlock:(dispatch_block_t)block;
- (void)setFailedBlock:(dispatch_block_t)block;
// warning:
// 需要使用block时，声明MQQHttpRequest实例时需要添加__block，以免循环引用导致内存泄漏
/* e.g.
 __block MQQHttpRequest *request = [MQQHttpRequest requestWithURL:url];
 [request setCompletionBlock:^{
    // NSData *rspData = request.responseData;
    // ...
 }];
 */

// init
+ (id)requestWithURL:(NSURL *)connectURL;
- (id)initWithURL:(NSURL *)connectURL;
// async
- (void)startAsynchronous;
// sync
- (void)startSynchronous;
// cancel
- (void)clearDelegatesAndCancel;

// NSURLSession only
- (void)resume;
- (void)suspend;

- (void)addRequestHeader:(NSString *)header value:(NSString *)value;

@end

//
//  MQQURLSession+Private.h
//  MQQSecure
//
//  Created by klaudz on 8/12/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import "MQQURLSession.h"
#import "MQQHttpRequest+NSURLSession.h"
#import "MQQHttpRequestDefines.h"

@interface MQQURLSession ()

- (void)requestDidStop:(MQQHttpRequest *)request;

@end

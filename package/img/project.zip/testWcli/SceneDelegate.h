//
//  SceneDelegate.h
//  testWcli
//
//  Created by tommywwang on 2021/11/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


//
//  WAAnnotation.m
//  weapps
//
//  Created by tommywwang on 2020/7/1.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "WAAnnotation.h"

@implementation WAAnnotation

@end

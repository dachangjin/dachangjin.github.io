//
//  TMFSMDefines.h
//  Pods
//
//  Created by klaudz on 20/5/2019.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSInteger TMFSMStatus;

NS_ASSUME_NONNULL_END

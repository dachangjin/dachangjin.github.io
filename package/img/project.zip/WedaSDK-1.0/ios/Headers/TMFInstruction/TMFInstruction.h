//
//  TMFInstruction.h
//  AFNetworking
//
//  Created by charmxiao on 2019/6/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSInteger TMFInstructionID;

typedef NS_ENUM(NSInteger, TMFInstructionAction)
{
    TMFInstructionActionUpdate      = 0,    ///< 云指令有更新
    TMFInstructionActionRevoke      = 1,    ///< 云指令有撤销
};

@interface TMFInstruction : NSObject <NSCoding, NSCopying>

@property (nonatomic, assign) TMFInstructionID instructionID;           ///< 云指令id

@property (nonatomic, retain, nullable) NSArray<NSString *> *values;    ///< 下发云指令的值
@property (nonatomic, assign) TMFInstructionAction action;              ///< 云指令行为

@property (nonatomic, assign) long long taskID;                         ///< 任务ID
@property (nonatomic, assign) long long taskSeqNo;                      ///< 任务序号
@property (nonatomic, assign) NSInteger conchSeqNo;                     ///< 指令序号

@property (nonatomic, assign) NSInteger validEndTime;                   ///< 指令失效时间

@end

NS_ASSUME_NONNULL_END

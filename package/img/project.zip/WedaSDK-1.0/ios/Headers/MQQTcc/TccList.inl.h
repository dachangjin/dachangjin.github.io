
template <typename T, typename _traits>
TccList<T, _traits>::TccList(){ 
	iRootFront = NULL;
	iRootBack = NULL;
	iSize = 0;
}

template <typename T, typename _traits>
TccList<T, _traits>::~TccList(){
	Clear();
}

template <typename T, typename _traits>
inline typename TccList<T, _traits>::Iterator 
TccList<T, _traits>::Begin() const {
	return Iterator(iRootFront, iRootBack);
}

template <typename T, typename _traits>
inline typename TccList<T, _traits>::Iterator 
TccList<T, _traits>::End() const {
	return Iterator(NULL, iRootBack);
}

template <typename T, typename _traits>
inline void TccList<T, _traits>::Begin(Iterator& it) const {
	it.iCurr = iRootFront;
	it.iBack = iRootBack;
}

template <typename T, typename _traits>
inline void TccList<T, _traits>::End(Iterator& it) const {
	it.iCurr = NULL;
	it.iBack = iRootBack;
}

template <typename T, typename _traits>
typename TccList<T, _traits>::Iterator 
TccList<T, _traits>::FindIndex(ti32 nIndex){
	Node* p = NULL;
	if (nIndex < iSize && nIndex >= 0){
		p = iRootFront;
		while (nIndex--){
			p = p->iNext;
		}
	}
//	return Iterator(p);
	return Iterator(p, p->iNext);
}
template <typename T, typename _traits>
void TccList<T, _traits>::FindIndex(ti32 nIndex, Iterator& it){
	Node* p = NULL;
	if (nIndex < iSize && nIndex >= 0){
		p = iRootFront;
		while (nIndex--){
			p = p->iNext;
		}
	}
	it.iCurr = p;	
}
	
#if 0
template <typename T, typename _traits>
void TccList<T, _traits>::PushFrontL(const T& element){
	Node* p = new Node(element);
	_TccLeaveIfNull(p);

	if(iRootFront == NULL){
		iRootBack = p;
	}
	else{
		p->iNext = iRootFront;
		iRootFront->iPrev = p;
	}
	iRootFront = p;
	iSize++;
}

template <typename T, typename _traits>
terror TccList<T, _traits>::PushFront(const T& element){
	Node* p = new Node(element);
	if(p == NULL) return _TccErrNoMemory;
	if(iRootFront == NULL){
		iRootBack = p;
	}
	else{
		p->iNext = iRootFront;
		iRootFront->iPrev = p;
	}
	iRootFront = p;
	iSize++;
	return _TccErrNone;
}

template <typename T, typename _traits>
void TccList<T, _traits>::PushBackL(const T& element){
	Node* p = new Node(element);
	_TccLeaveIfNull(p);
	if(NULL == iRootBack){
		iRootFront = p;
	}
	else{
		p->iPrev = iRootBack;
		iRootBack->iNext = p;
	}
	iRootBack = p;
	iSize++;
}

template <typename T, typename _traits>
terror TccList<T, _traits>::PushBack(const T& element){
	Node* p = new Node(element);
	if(p == NULL) return _TccErrNoMemory;
	if(iRootBack == NULL){
		iRootFront = p;
	}
	else{
		p->iPrev = iRootBack;
		iRootBack->iNext = p;
	}
	iRootBack = p;
	iSize++;
	return _TccErrNone;
}
#endif

template <typename T, typename _traits>
void TccList<T, _traits>::TakeOffOneNode(Node*& aNode){
	if(aNode->iPrev != NULL){
		aNode->iPrev->iNext = aNode->iNext;
		//��ǰ�ڵ��ǰһ����next��ֵ�ص�ǰ�ڵ����һ��
	}
	else{//Ҫɾ�ĸոպ��ǵ�һ���ڵ�
		iRootFront = aNode->iNext;
	}
	if(aNode->iNext != NULL){
		aNode->iNext->iPrev = aNode->iPrev;
		//��ǰ�ڵ����һ����prev��ֵ�ص�ǰ�ڵ��ǰһ��
		//����ǰ�ڵ����׽ڵ�,��ô��һ�еĹ����Ѿ���������elseע���˵�һ��
	}
	else{//Ҫɾ�ĸոպ������һ���ڵ�
		iRootBack = aNode->iPrev;
	}
	iSize--;
}

template <typename T, typename _traits>
void TccList<T, _traits>::AddOneNode(Node* AtNode, Node* p){
	if(NULL == AtNode){ //�嵽β��
		if(NULL == iRootBack){
			iRootFront = p;
		}
		else{
			p->iPrev = iRootBack;
			iRootBack->iNext = p;
		}
		iRootBack = p;
	}
	else if(NULL == AtNode->iPrev){ //ͷ�ڵ㣬�����ֲ���ֻ��һ���ڵ����������ͷ�ڵ�Ҳ�ǿգ���ô�����Ǹ����Ҳ�������ˡ�
		AtNode->iPrev = p;
		p->iNext = AtNode;
		iRootFront = p;
	}
	else{
		AtNode->iPrev->iNext = p;
		p->iPrev = AtNode->iPrev;
		AtNode->iPrev = p;
		p->iNext = AtNode;
	}
	iSize++;
}

template <typename T, typename _traits>
terror TccList<T, _traits>::Insert(Iterator& it, const T& element){
	Node* p = new Node(element);
	if(p == NULL) return _TccErrNoMemory;
	AddOneNode(it.iCurr, p);
	return _TccErrNone;
}

template <typename T, typename _traits>
void TccList<T, _traits>::PushFrontL(const T& element){
	Node* p = new Node(element);
	_TccLeaveIfNull(p);
	AddOneNode(iRootFront, p);
}

template <typename T, typename _traits>
terror TccList<T, _traits>::PushFront(const T& element){
	Node* p = new Node(element);
	if(p == NULL) return _TccErrNoMemory;
	AddOneNode(iRootFront, p);
	return _TccErrNone;
}

template <typename T, typename _traits>
void TccList<T, _traits>::PushBackL(const T& element){
	Node* p = new Node(element);
	_TccLeaveIfNull(p);
	AddOneNode(NULL, p);
}

template <typename T, typename _traits>
terror TccList<T, _traits>::PushBack(const T& element){
	Node* p = new Node(element);
	if(p == NULL) return _TccErrNoMemory;
	AddOneNode(NULL, p);
	return _TccErrNone;
}

template <typename T, typename _traits>
void TccList<T, _traits>::PopFront(){
	if(NULL != iRootFront){
		Node* p = iRootFront;
		TakeOffOneNode(p);
		delete p;
	}
}
template <typename T, typename _traits>
void TccList<T, _traits>::PopBack(){
	if(NULL != iRootBack){
		Node* p = iRootBack;
		TakeOffOneNode(p);
		delete p;
	}
}
template <typename T, typename _traits>
void TccList<T, _traits>::PopFrontAndDestroy(){
	if(NULL != iRootFront){
		Node* p = iRootFront;
		TakeOffOneNode(p);
		_traits::DeleteHandle(p->iElement);
		delete p;
	}
}
template <typename T, typename _traits>
void TccList<T, _traits>::PopBackAndDestroy(){
	if(NULL != iRootBack){
		Node* p = iRootBack;
		TakeOffOneNode(p);
		_traits::DeleteHandle(p->iElement);
		delete p;
	}
}
template <typename T, typename _traits>
inline T& TccList<T, _traits>::Front(){
	TccAssert(NULL != iRootFront);
	return iRootFront->iElement;
}

template <typename T, typename _traits>
inline T& TccList<T, _traits>::Front()const{
	TccAssert(NULL != iRootFront);
	return iRootFront->iElement;
}


template <typename T, typename _traits>
inline T& TccList<T, _traits>::Back(){
	TccAssert(NULL != iRootBack);
	return iRootBack->iElement;
}

template <typename T, typename _traits>
void TccList<T, _traits>::Clear(){
	while(iRootFront != NULL){
		iRootBack = iRootFront->iNext;
		delete iRootFront;
		iRootFront = iRootBack;
	}
	iRootFront = NULL;
	iRootBack = NULL;
	iSize = 0;
}

template <typename T, typename _traits>
void TccList<T, _traits>::Destroy(){
	while(iRootFront != NULL){
		iRootBack = iRootFront->iNext;
		_traits::DeleteHandle(iRootFront->iElement);
		delete iRootFront;
		iRootFront = iRootBack;
	}
	iRootFront = NULL;
	iRootBack = NULL;
	iSize = 0;
}

template <typename T, typename _traits>
inline tbool TccList<T, _traits>::Empty() const{ 
	return (tbool)(NULL == iRootFront); 
}

template <typename T, typename _traits>
inline ti32 TccList<T, _traits>::Size() const{ 
	return iSize; 
}

template <typename T, typename _traits>
typename TccList<T, _traits>::Iterator 
TccList<T, _traits>::Find(const T& element){
	Node* p = iRootFront;
	while(p != NULL){
		if(0 == _traits::Compare(element, p->iElement)){
			break;
		}
		p = p->iNext;
	}
	return Iterator(p);
}

template <typename T, typename _traits>
void TccList<T, _traits>::Find(const T& element, Iterator& it){
	Node* p = iRootFront;
	while(p != NULL){
		if(0 == _traits::Compare(element, p->iElement)){
			break;
		}
		p = p->iNext;
	}
	it.iCurr = p;
}




//int insert(const _object& element);
template <typename T, typename _traits>
void TccList<T, _traits>::Erase(Iterator& it){
	if(NULL != it.iCurr){
		TakeOffOneNode(it.iCurr);
		delete it.iCurr;
		it.iCurr = NULL;
	}
}

template <typename T, typename _traits>
void TccList<T, _traits>::Erase(const T& element){
	Node* p = iRootFront;
	while(p != NULL){
		if(0 == _traits::Compare(element, p->iElement)){
			TakeOffOneNode(p);
			delete p;
			break;
		}
		p = p->iNext;
	}
}

template <typename T, typename _traits>
void TccList<T, _traits>::EraseAndDestroy(Iterator& it){
	if(NULL != it.iCurr){
		TakeOffOneNode(it.iCurr);
		_traits::DeleteHandle(it.iCurr->iElement);
		delete it.iCurr;
		it.iCurr = NULL;
	}
}

template <typename T, typename _traits>
void TccList<T, _traits>::EraseAndDestroy(const T& element){
	Node* p = iRootFront;
	while(p != NULL){
		if(0 == _traits::Compare(element, p->iElement)){
			TakeOffOneNode(p);
			_traits::DeleteHandle(p->iElement);
			delete p;
			break;
		}
		p = p->iNext;
	}
}




template <typename T, typename _traits>
void TccList<T, _traits>::Merge(TccList<T, _traits>& rhs){
	if(NULL != rhs.iRootFront && iRootFront != rhs.iRootFront){
		if(NULL == iRootFront){
			iRootFront = rhs.iRootFront;
			iRootBack = rhs.iRootBack;
			iSize = rhs.iSize;
		}
		else {
			Node* first1 = iRootFront;
			Node* first2 = rhs.iRootFront;
			//Node* p = NULL;

			//��յ�ǰlist,�����¹���
			iRootFront = NULL;
			iRootBack = NULL;
			iSize = 0;

			while (NULL != first1 && NULL != first2){
				if (_traits::Compare(first2->iElement, first1->iElement) < 0){
					AddOneNode(NULL, first2);
					first2 = first2->iNext;
				}
				else{
					AddOneNode(NULL, first1);
					first1 = first1->iNext;
				}
			}
			if (NULL != first2){ //��������һ����ΪNULL
				AddOneNode(NULL, first2);
			}
			else{
				AddOneNode(NULL, first1);
			}
		}
		rhs.iRootFront = NULL;
		rhs.iRootBack = NULL;
		rhs.iSize = 0;
	}
}

template <typename T, typename _traits>
void TccList<T, _traits>::Swap(TccList<T, _traits>& rhs){
	Node* tmp = iRootFront;
	iRootFront = rhs.iRootFront;
	rhs.iRootFront = tmp;

	tmp = iRootBack;
	iRootBack = rhs.iRootBack;
	rhs.iRootBack = tmp;

	ti32 t = iSize;
	iSize = rhs.iSize;
	rhs.iSize = t;
}

//merge sort
//use 26 List bins with 2^i nodes stored on each List.
//a carryList merge them up respectively.
template <typename T, typename _traits>
void TccList<T, _traits>::Sort(){
	//size < 2 ����Ҫ����
	if (2 <= iSize){
		const int BIN_SIZE = 25;
		TccList<T, _traits> carryList;
		TccList<T, _traits> binList[BIN_SIZE + 1];

		int maxBin = 0;

		while (!Empty()){
			TccAssert(carryList.Empty());
			//splice first node to carry
			carryList.iRootFront = iRootFront;
			iRootFront = iRootFront->iNext;
			if(NULL == iRootFront) iRootBack = NULL; //������,ǰ���������ó�null
			iSize--;
			carryList.iRootFront->iNext = NULL;
			carryList.iRootBack = carryList.iRootFront;
			carryList.iSize = 1;

			int bin;
			for (bin = 0; bin < maxBin && !binList[bin].Empty(); bin++){  
				// merge into ever larger bins
				binList[bin].Merge(carryList);
				binList[bin].Swap(carryList);

				TccAssert(!carryList.Empty());
				TccAssert(binList[bin].Empty());
			}

			if (bin == BIN_SIZE){
				binList[bin - 1].Merge(carryList);
			}
			else{
				binList[bin].Swap(carryList);
				if (bin == maxBin){
					maxBin++;
				}
			}
		}
		//merge up
		for (int bin = 1; bin < maxBin; bin++){
			binList[bin].Merge(binList[bin - 1]);
		}
		//replace from last bin
		Swap(binList[maxBin - 1]);
	}
}













//-----------------------------------------------------------------


//��ѭ����������һ���ڵ�������ǰ�Ľڵ�
template <typename T, typename _traits>
typename TccCycleList<T, _traits>::Node* TccCycleList<T, _traits>::TakeOffOneNode(Node*& aNode){
	Node* p = NULL;
	if (NULL != aNode) {
		if(aNode == aNode->iNext){ //��1���ڵ�����
			p = aNode;
			aNode = NULL;
		}
		else{
			p = aNode;
			aNode->iPrev->iNext = aNode->iNext;
			aNode->iNext->iPrev = aNode->iPrev;
			aNode = aNode->iNext;
		}
	}
	return p;
}

template <typename T, typename _traits>
TccCycleList<T, _traits>::TccCycleList() {
	iCurr = 0; //��ǰ�Ľڵ�
	iSize = 0;
}

template <typename T, typename _traits>
TccCycleList<T, _traits>::~TccCycleList() {
	Clear();
}

template <typename T, typename _traits>
inline ti32 TccCycleList<T, _traits>::Size() const {
	return iSize;
}

template <typename T, typename _traits>
inline tbool TccCycleList<T, _traits>::Empty() const {
	return (tbool)(NULL == iCurr);
}

template <typename T, typename _traits>
inline void TccCycleList<T, _traits>::Pre() {
	if (NULL != iCurr) {
		iCurr = iCurr->iPrev;
	}
}

template <typename T, typename _traits>
inline void TccCycleList<T, _traits>::Next() {
	if (NULL != iCurr) {
		iCurr = iCurr->iNext;
	}
}

template <typename T, typename _traits>
inline const T& TccCycleList<T, _traits>::GetCur() const {
	TccAssert(NULL != iCurr);
	return iCurr->iElement;
}

template <typename T, typename _traits>
inline T& TccCycleList<T, _traits>::GetCur(){
	TccAssert(NULL != iCurr);
	return iCurr->iElement;
}

template <typename T, typename _traits>
terror TccCycleList<T, _traits>::Push(const T& element) {
	terror err = _TccErrNone;
	Node* p = new Node(element);
	if(p == NULL){
		err = _TccErrNoMemory;
	}
	else {
		if(NULL == iCurr){
			iCurr = p;
			iCurr->iNext = iCurr;
			iCurr->iPrev = iCurr;
		}
		else{
			p->iNext = iCurr;
			p->iPrev = iCurr->iPrev;
			iCurr->iPrev->iNext = p;
			iCurr->iPrev = p;
			iCurr = p;
		}
		iSize++;
	}
	return err;
}

template <typename T, typename _traits>
void TccCycleList<T, _traits>::StepTo(ti32 step) {
	if (NULL != iCurr) {
		step = step % iSize;
		for (; step > 0; step--){
			iCurr = iCurr->iNext;
		}
	}
}

template <typename T, typename _traits>
tbool TccCycleList<T, _traits>::MoveTo(const T& element){
	tbool isFind = tfalse;
	if (NULL != iCurr) {
		Node* p = iCurr;
		do {
			if(0 == _traits::Compare(p->iElement, element)){
				iCurr = p;
				isFind = ttrue;
				break;
			}
			p = p->iNext;
		} while (p != iCurr);
	}
	return isFind;
}

//���ı䵱ǰcurr
template <typename T, typename _traits>
const T& TccCycleList<T, _traits>::Get(ti32 step) const {
	TccAssert(NULL != iCurr);
	Node* p = iCurr;
	step = step % iSize;
	for (; step > 0; step--){
		p = p->iNext;
	}
	return p->iElement;
}

template <typename T, typename _traits>
void TccCycleList<T, _traits>::EraseCur() {
	if (NULL != iCurr) {
		Node* p = TakeOffOneNode(iCurr);
		delete p;
		iSize--;
	}
}

template <typename T, typename _traits>
void TccCycleList<T, _traits>::EraseCurAndDestroy() {
	if (NULL != iCurr) {
		Node* p = TakeOffOneNode(iCurr);
		_traits::DeleteHandle(p->iElement);
		delete p;
		iSize--;
	}
}


template <typename T, typename _traits>
void TccCycleList<T, _traits>::Erase(const T& element) {
	if (NULL != iCurr) {
		Node* p = iCurr;
		do {
			if(0 == _traits::Compare(p->iElement, element)){
				if(p == iCurr){
					EraseCur();
				}
				else{ //��ô������2���ڵ��ˡ�
					//Node* q = p;
					p->iPrev->iNext = p->iNext;
					p->iNext->iPrev = p->iPrev;
					delete p;
					iSize--;
				}
				break;
			}
			p = p->iNext;
		} while (p != iCurr);
	}
}

template <typename T, typename _traits>
ti32 TccCycleList<T, _traits>::Find(const T& searchValue) const {
	ti32 index = -1;
	if (NULL != iCurr) {
		ti32 t = 0;
		Node* p = iCurr;
		do {
			if(0 == _traits::Compare(p->iElement, searchValue)){
				index = t;
				break;
			}
			t++;
			p = p->iNext;
		} while (p != iCurr);
	}
	return index;
}

template <typename T, typename _traits>
void TccCycleList<T, _traits>::Clear() {
	if(NULL != iCurr){
		Node* p = NULL;
		while (iCurr->iNext != iCurr){
			p = iCurr->iNext;
			iCurr->iNext = p->iNext;
			delete p;
		}
		delete iCurr;
		iCurr = NULL;
		iSize = 0;
	}
}

template <typename T, typename _traits>
void TccCycleList<T, _traits>::Destroy() {
	if(NULL != iCurr){
		Node* p = NULL;
		while (iCurr->iNext != iCurr){
			p = iCurr->iNext;
			iCurr->iNext = p->iNext;
			_traits::DeleteHandle(p->iElement);
			delete p;
		}
		_traits::DeleteHandle(iCurr->iElement);
		delete iCurr;
		iCurr = NULL;
		iSize = 0;
	}
}






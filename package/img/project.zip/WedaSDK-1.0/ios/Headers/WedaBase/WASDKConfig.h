//
//  WASDKConfig.h
//  wedaSDK
//
//  Created by tommywwang on 2021/6/16.
//

#import <Foundation/Foundation.h>
#import "TMFSharkCenterConfiguration.h"

NS_ASSUME_NONNULL_BEGIN

@interface WASDKConfig : NSObject

/// 微信开发平台申请的id，用于获取微信登录信息
@property (nonatomic, copy, nullable) NSString *wechatId;
/// 微信开发平台申请的key，用于获取微信登录信息
@property (nonatomic, copy, nullable) NSString *wechatKey;

/// 腾讯云人脸核身key，用于腾讯云人脸核身SDK
@property (nonatomic, copy, nullable) NSString *cloudFaceKey;

/// 腾讯云人脸核身Id，用于腾讯云人脸核身SDK
@property (nonatomic, copy, nullable) NSString *cloudFaceId;

/// 腾讯云人脸核身license，用于腾讯云人脸核身SDK
@property (nonatomic, copy, nullable) NSString *cloudFaceLicense;

/**
 * 腾讯云实时音视频SDKAppId，用于实时音视频聊天
 * 进入腾讯云云通信[控制台](https://console.cloud.tencent.com/avc) 创建应用，即可看到 SDKAppId，
 * 它是腾讯云用于区分客户的唯一标识。
 */
@property (nonatomic, assign) int TRTCSDKAppId;

/**
 * 腾讯云实时音视频secretKey，用于实时音视频聊天
 * 计算签名用的加密密钥，获取步骤如下：
 *
 * step1. 进入腾讯云云通信[控制台](https://console.cloud.tencent.com/avc) ，如果还没有应用就创建一个，
 * step2. 单击“应用配置”进入基础配置页面，并进一步找到“帐号体系集成”部分。
 * step3. 点击“查看密钥”按钮，就可以看到计算 UserSig 使用的加密的密钥了，请将其拷贝并复制到如下的变量中
 */
@property (nonatomic, copy, nullable) NSString *TRTCSDKSecretKey;

/// 腾讯云直播播放器url，用于视频直播/推流
@property (nonatomic, copy, nullable) NSString *livePlayerUrl;

/// 腾讯云直播播放器key，用于视频直播/推流
@property (nonatomic, copy, nullable) NSString *livePlayerKey;

/// 腾讯地图ApiKey
@property (nonatomic, copy, nullable) NSString *mapApiKey;

/// ocr 秘钥id
@property (nonatomic, copy, nullable) NSString *ocrSecretId;

/// ocr 秘钥
@property (nonatomic, copy, nullable) NSString *ocrSecretKey;

/// 最大后台运行小程序个数，默认5
@property (nonatomic, assign) NSUInteger maxBackgroundAppCount;

/// TMF 相关配置
@property (nonatomic, strong) TMFSharkCenterConfiguration *configuration;

/// 数据上报配置key
@property (nonatomic, copy) NSString *tmfStatisticsKey;

/// 离线包公钥
@property (nonatomic, copy) NSString *webOfflinePublicKey;

@end

NS_ASSUME_NONNULL_END

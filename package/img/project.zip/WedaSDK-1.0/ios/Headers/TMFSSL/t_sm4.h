/*
 * Copyright 2017 The OpenSSL Project Authors. All Rights Reserved.
 * Copyright 2017 Ribose Inc. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#ifndef __HEADER_SM4_H__
# define __HEADER_SM4_H__



#include "t_buf.h"


# define SM4_BLOCK_SIZE    16
# define SM4_KEY_SCHEDULE  32


#define SM4_USED_PKCS5


#ifdef __cplusplus
extern "C" {
#endif

typedef struct TMF_SM4_KEY_st {
    uint32_t rk[SM4_KEY_SCHEDULE];
} TMF_SM4_KEY;

t_err tmf_sm4_set_key(const uint8_t key[16], TMF_SM4_KEY *ks);
t_err tmf_sm4_set_key_Hex(const char* key, TMF_SM4_KEY *ks);

t_err tmf_sm4_encrypt_ecb(const TMF_SM4_KEY *ks,
	const uint8_t* input,
	int in_len,
	t_buf* outbuf);

t_err tmf_sm4_decrypt_ecb(const TMF_SM4_KEY *ks,
	const uint8_t *input,
	int in_len,
	t_buf* outbuf);

t_err tmf_sm4_encrypt_cbc(const TMF_SM4_KEY *ks,
	uint8_t iv[16],
	const uint8_t* input,
	int in_len,
	t_buf* outbuf);

t_err tmf_sm4_decrypt_cbc(const TMF_SM4_KEY *ks,
	uint8_t iv[16],
	const uint8_t* input,
	int in_len,
	t_buf* outbuf);


#ifdef  __cplusplus
}
#endif

#endif

//
//  Weapps+ext.m
//  WedaSDK_Example
//
//  Created by tommywwang on 2021/11/9.
//  Copyright © 2021 tommywwang. All rights reserved.
//

#import "Weapps+ext.h"
#import <objc/runtime.h>
#import "WAJSCustomTestHandler.h"


BOOL ExchangeImplementationsClass(Class _fromClass, SEL _originSelector, Class _toClass, SEL _newSelector) {
    if (!_fromClass || !_toClass) {
        return NO;
    }
    
    Method oriMethod = class_getInstanceMethod(_fromClass, _originSelector);
    Method newMethod = class_getInstanceMethod(_toClass, _newSelector);
    if (!newMethod) {
        return NO;
    }
    
    BOOL isAddedMethod = class_addMethod(_fromClass, _originSelector, method_getImplementation(newMethod), method_getTypeEncoding(newMethod));
    if (isAddedMethod) {
        IMP oriMethodIMP = method_getImplementation(oriMethod) ?: imp_implementationWithBlock(^(id selfObject) {});
        const char *oriMethodTypeEncoding = method_getTypeEncoding(oriMethod) ?: "v@:";
        class_replaceMethod(_toClass, _newSelector, oriMethodIMP, oriMethodTypeEncoding);
    } else {
        method_exchangeImplementations(oriMethod, newMethod);
    }
    return YES;
}


@implementation Weapps (ext)

+ (void)load
{
    ExchangeImplementationsClass([Weapps class], @selector(initWithConfig:), [Weapps class], @selector(ext_initWithConfig:));
}

- (void)ext_initWithConfig:(WASDKConfig *)config
{
    static BOOL addedExtension = NO;
    [self ext_initWithConfig:config];
    if (!addedExtension) {
        [self registerCustomHandler:[[WAJSCustomTestHandler alloc] init]];
        addedExtension = YES;
    }
}
@end

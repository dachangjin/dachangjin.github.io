//
//  TMFWebOfflineUtilities.h
//  Pods
//
//  Created by hauzhong on 2019/5/24.
//

#ifndef TMFWebOfflineUtilities_h
#define TMFWebOfflineUtilities_h

/**
 @brief 离线包更新来源
 
 @note 枚举值对齐 `TMFWebOffline_Tars_EReqSource`
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineServiceOptionsSource) {
    TMFWebOfflineServiceOptionsSourceRequest = 0,   ///< 主动拉取更新
    TMFWebOfflineServiceOptionsSourcePush = 1,      ///< 通过push进行更新
};

/**
 @brief 离线包预加载模式
 
 @note 枚举值对齐 `TMFWebOffline_Tars_EReqType`
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineServiceOptionsLaunchMode) {
    TMFWebOfflineServiceOptionsLaunchModeSingleness = 0,      ///< 预加载指定的BID
    TMFWebOfflineServiceOptionsLaunchModeAll = 1,             ///< 预加载全部的BID
};

/**
 @brief 检查到离线包更新时本地缓存的更新策略
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineServiceOptionsCachePolicy) {
    TMFWebOfflineServiceOptionsCachePolicyDownloadAndUpdate = 0,         ///< 检查到更新后，等下载最新离线包后覆盖本地缓存
    TMFWebOfflineServiceOptionsCachePolicyRemoveAndDownload = 1,         ///< 检查到更新后，先移除本地缓存，然后下载最新离线包后更新
};

/**
 @brief 离线包下载任务状态
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineDownloadTaskState) {
    TMFWebOfflineDownloadTaskStateIdle = 0,         ///< 闲置
    TMFWebOfflineDownloadTaskStateRunning = 1,      ///< 下载中
    TMFWebOfflineDownloadTaskStateSuspended = 2,    ///< 下载挂起
    TMFWebOfflineDownloadTaskStateCanceling = 3,    ///< 下载取消
    TMFWebOfflineDownloadTaskStateCompleted = 4,    ///< 已完成
};

/**
 @brief 离线包下载任务优先级
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineDownloadTaskPriority) {
    TMFWebOfflineDownloadTaskPriorityLow = 0,       ///< 优先级低
    TMFWebOfflineDownloadTaskPriorityMiddle = 1,    ///< 优先级中
    TMFWebOfflineDownloadTaskPriorityHigh = 2,      ///< 优先级高
};

/**
 @brief 日志级别
 */
typedef NS_ENUM(NSInteger, TMFWebOfflineLoggerLevel) {
    TMFWebOfflineLoggerLevelDebug = 0,         ///< 调试帮助日志
    TMFWebOfflineLoggerLevelInfo = 1,          ///< 运行过程关键日志
    TMFWebOfflineLoggerLevelWarn = 2,          ///< 存在潜在问题日志
    TMFWebOfflineLoggerLevelError = 3,         ///< 严重错误导致系统退出日志
};

/**
 @brief 用于输出SDK调试log的回调
 */
typedef void(*TMFWebOffline_Logger)(TMFWebOfflineLoggerLevel level, const char* log);

/**
 @brief 用于解析SDK调试log的级别描述
 */
NSString *TMFWebOfflineLoggerLevelDescription(TMFWebOfflineLoggerLevel level);



/**
 @brief 用于输出SDK统计事件的回调
 */
typedef void(*TMFWebOffline_Reporter)(NSString *event, NSDictionary *kvs);

/**
 @brief 离线包下载异常通知
 */
extern const NSString *TMFWebOfflineDownloadNoSpaceNotification;

#endif /* TMFWebOfflineUtilities_h */

//
//  TMFStatisticsReporter+Device.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Device)

- (NSDictionary<NSNumber *, NSString *> *)fds_COMMON:(nullable TMFStatisticsConfiguration *)configuration;
- (NSDictionary<NSNumber *, NSString *> *)fds_DEVICE:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END
    

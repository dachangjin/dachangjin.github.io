//
//  AppDelegate.h
//  testWcli
//
//  Created by tommywwang on 2021/11/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end


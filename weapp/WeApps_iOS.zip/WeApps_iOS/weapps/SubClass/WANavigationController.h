//
//  WANavigationController.h
//  weapps
//
//  Created by tommywwang on 2020/6/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QMUINavigationController.h"
NS_ASSUME_NONNULL_BEGIN

@interface WANavigationController : QMUINavigationController

@end

NS_ASSUME_NONNULL_END

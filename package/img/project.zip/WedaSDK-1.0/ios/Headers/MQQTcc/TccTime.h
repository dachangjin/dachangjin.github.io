#ifndef ___TCC_TIME_H_DEFINE___
#define ___TCC_TIME_H_DEFINE___

#include "TccSys.h"
#include "TccString.h"

#include "TccTagType.h"

#if defined(__TccMac__) || defined(__TccAndroidNDK__) || defined(__TccMeeGo__)
#include <sys/time.h>
#endif


//typedef __time32_t ttime32;
typedef tu32 ttime;
typedef ttime ttime32;

typedef struct ___TccTimeStruct{
	ti16 iYear;
	ti8 iMonth;
	ti8 iDay;
	ti8 iHour;
	ti8 iMinute;
	ti8 iSecond;
	ti8 iWeekDay; 	/* day of week (0-6, Sunday = 0) */
}TccTimeStruct;

TCCIMPORT ttime TccMktime(TccTimeStruct *tb);
TCCIMPORT void TccGmTime(ttime aT, TccTimeStruct* aTs);
TCCIMPORT ti32 TccTimeStructFromStr(TccTimeStruct* aSt, const ti8* aStr, ti32 aLen);
TCCIMPORT ti32 TccTimeStructToStr(TccTimeStruct* aSt, ti8* aStr, ti32 aSize, tbool isLongFormat);


class TccTime{
public:
#if defined(__TccSymbian__)
	TCCIMPORT static void TimeToStr(const TTime& atime, TDes& atimestr);
	TCCIMPORT static void UtcTimeToStr(const TTime& atime, TDes& atimestr, tbool aIsDate=tfalse);
	TCCIMPORT static TBool FormatTime(TTime& aTime, const TDesC& aTimeString, const TLocale& aLocale = TLocale());
	TCCIMPORT static TMonth formatint(TInt amonth);
	TCCIMPORT static TInt forMonth(TMonth aMonths);
	//static void ParseEndDate(TTime& atime, TDesC& atimesartstr, TDesC&atimeendstr);
	TCCIMPORT static TInt GetDaysOfMonth(TInt aYear, TInt aMonth); // month: since 0
#endif

public:

	TCCIMPORT TccTime();
	TCCIMPORT ~TccTime();
	
#if defined(__TccSymbian__)
	TTime iTime;
	TCCIMPORT TccTime(const TTime&);
	inline operator const TTime&() const {return iTime;}
#elif defined(__TccWindows__)
	FILETIME iTime; //The FILETIME structure is a 64-bit value representing the number of 100-nanosecond intervals since January 1, 1601 (UTC).
	TCCIMPORT TccTime(const FILETIME&);
	inline operator const FILETIME&() const {return iTime;}
#elif defined(__TccAndroidNDK__) || defined(__TccMac__) || defined(__TccMeeGo__)
	timeval iTime; 
	TCCIMPORT TccTime(const timeval&);
	inline operator const timeval&() const {return iTime;}
#else
	#error unknown system time api
#endif
	TCCIMPORT TccTime(const ti64& aFileTime);

	TCCIMPORT terror Set(ti32 aYear, ti32 aMonth, ti32 aDay, ti32 aHour, ti32 aMinute, ti32 aSecond);
	TCCIMPORT void GetTimeStruct(TccTimeStruct& aStruct) const ;

	TCCIMPORT void GetUtcTime(); ///��ȡϵͳʱ��(UTC)
	TCCIMPORT void GetLocalTime(); ///��ȡϵͳʱ��(��ǰʱ��)
		
	TCCIMPORT void ConvToUtcTime(); ///�ѵ�ǰֵת����UTCʱ��
	TCCIMPORT void ConvToLocalTime(); ///�ѵ�ǰֵת����Localʱ��
	
	///aStr��MaxLength������ڵ���14,����panic
	TCCIMPORT void ToNumStr(TccDes16& aStr);
	TCCIMPORT void FromNumStr(const TccDesC16& aStr);

//crtʱ��,1970�꿪ʼ
	TCCIMPORT static ttime CrtUtcTime();
	TCCIMPORT static ttime CrtLocalTime();
	TCCIMPORT ttime GetCrtTime() const;
	TCCIMPORT void SetCrtTime(ttime aCrtTime);

	//64-bit value representing the number of 100-nanosecond intervals since January 1, 1601 (UTC).
	TCCIMPORT void GetFileTime(ti64& aFileTime) const;
	TCCIMPORT void SetFileTime(const ti64& aFileTime);

	inline void AddDay(ti32 aDay){AddSecond(24 * 60 * 60 * aDay);}
	inline void AddHour(ti32 aHour){AddSecond(60 * 60 * aHour);}
	inline void AddMinute(ti32 aMinute){AddSecond(60 * aMinute);}
	TCCIMPORT void AddSecond(ti32 aSecond);

#if defined(__TccSymbianEka1__)
	void GetFileTime(tu32& aLow, tu32& aHigh) const;
	inline TccTime& operator=(const _tti64& aTime){SetFileTime(TInt64(aTime.u.iHigh, aTime.u.iLow));return *this;}
	inline operator _tti64()const{_tti64 aTime;GetFileTime(aTime.u.iLow, aTime.u.iHigh);return aTime;}
#else
	inline TccTime& operator=(const _tti64& aTime){SetFileTime(aTime.iQuadPart);return *this;}
	inline operator _tti64()const{_tti64 aTime;GetFileTime(aTime.iQuadPart);return aTime;}
#endif

	TCCIMPORT TccTime& operator=(const TccTime& aTime);
	TCCIMPORT tbool operator<(const TccTime &aTime) const;
	TCCIMPORT tbool operator<=(const TccTime &aTime) const;
	TCCIMPORT tbool operator>(const TccTime &aTime) const;
	TCCIMPORT tbool operator>=(const TccTime &aTime) const;
	TCCIMPORT tbool operator==(const TccTime &aTime) const;
	TCCIMPORT tbool operator!=(const TccTime &aTime) const;

};

#define TccGetUtcTime()								TccTime::CrtUtcTime()


#endif //___TCC_TIME_H_DEFINE___


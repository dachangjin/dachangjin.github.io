//
//  TMFStatisticsViewControllerProtocol.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class TMFStatisticsHandler;

@protocol TMFStatisticsViewControllerProtocol <NSObject>

/**
 @brief 当前View容器中的 UIView/WKWebView 实例
 */
@property (nonatomic, retain, readonly) __kindof UIView *tmf_view;

/**
 @brief 当前view容器中的统计处理器实例
 */
@property (nonatomic, retain) TMFStatisticsHandler *tmf_statisticsHandler;

@end

NS_ASSUME_NONNULL_END

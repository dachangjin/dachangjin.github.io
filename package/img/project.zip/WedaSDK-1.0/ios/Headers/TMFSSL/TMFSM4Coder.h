//
//  TMFSM4Coder.h
//  Pods
//
//  Created by klaudz on 20/5/2019.
//

#import <Foundation/Foundation.h>
#import "TMFSMDefines.h"

NS_ASSUME_NONNULL_BEGIN

#pragma mark - ECB

FOUNDATION_EXTERN
TMFSMStatus TMFSM4EncryptECB(NSData *dataIn,
                             NSData *key,
                             NSData * _Nullable * _Nullable dataOut);

FOUNDATION_EXTERN
TMFSMStatus TMFSM4DecryptECB(NSData *dataIn,
                             NSData *key,
                             NSData * _Nullable * _Nullable dataOut);

#pragma mark - CBC

FOUNDATION_EXTERN
TMFSMStatus TMFSM4EncryptCBC(NSData *dataIn,
                             NSData *key, NSData *ivx,
                             NSData * _Nullable * _Nullable dataOut);

FOUNDATION_EXTERN
TMFSMStatus TMFSM4DecryptCBC(NSData *dataIn,
                             NSData *key, NSData *ivx,
                             NSData * _Nullable * _Nullable dataOut);

NS_ASSUME_NONNULL_END

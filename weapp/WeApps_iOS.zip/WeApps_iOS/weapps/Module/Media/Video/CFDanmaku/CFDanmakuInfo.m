//
//  CFDanmakuInfo.m
//  HJDanmakuDemo
//
//  Created by 于 传峰 on 15/7/10.
//  Copyright (c) 2015年 olinone. All rights reserved.
//

#import "CFDanmakuInfo.h"

@implementation CFDanmakuInfo

@end

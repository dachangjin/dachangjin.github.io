#ifndef __TCC_WBXML_H_DEFINE__
#define __TCC_WBXML_H_DEFINE__

#include "TccSys.h"
#include "TccString.h"


#define _TccWbxmlTokenSwitchPage						0x00U
#define _TccWbxmlTokenEnd								0x01U
#define _TccWbxmlTokenEntity							0x02U
#define _TccWbxmlTokenStrI								0x03U
#define _TccWbxmlTokenLiteral							0x04U
#define _TccWbxmlTokenExtI0								0x40U
#define _TccWbxmlTokenExtI1								0x41U
#define _TccWbxmlTokenExtI2								0x42U
#define _TccWbxmlTokenPi								0x43U
#define _TccWbxmlTokenLiteralC							0x44U
#define _TccWbxmlTokenExtT0								0x80U
#define _TccWbxmlTokenExtT1								0x81U
#define _TccWbxmlTokenExtT2								0x82U
#define _TccWbxmlTokenStrT								0x83U
#define _TccWbxmlTokenLiteralA							0x84U
#define _TccWbxmlTokenExt0								0xC0U
#define _TccWbxmlTokenExt1								0xC1U
#define _TccWbxmlTokenExt2								0xC2U
#define _TccWbxmlTokenOpaque							0xC3U
#define _TccWbxmlTokenLiteralAC							0xC4U

/* WBXML Tokens Masks */
#define _TccWbxmlTokenMask								0x3FU
#define _TccWbxmlTokenMaskWithAttrs						0x80U
#define _TccWbxmlTokenMaskWithContent					0x40U
#define _TccWbxmlTokenMaskWithContentAttrs				0xC0U

/* WBXML Application Token types */
#define _TccWbxmlTokenTag								0	/**< Tag token */
#define _TccWbxmlTokenAttr								1	/**< Attribute token */

/*wbxml version define*/
#define _TccWbxmlVersion10								0x00U	/**< WBXML 1.0 Token */
#define _TccWbxmlVersion11								0x01U	/**< WBXML 1.1 Token */
#define _TccWbxmlVersion12								0x02U	/**< WBXML 1.2 Token */
#define _TccWbxmlVersion13								0x03U	/**< WBXML 1.3 Token */

/*wbxml charset define*/
#define _TccWbxmlCharSetUnknown							0x00U	/**< Unknown Charset */
#define _TccWbxmlCharSetUsAscii							0x03U	/**< US-ASCII */
#define _TccWbxmlCharSetISO_8859_1						0x04U	/**< ISO-8859-1 */
#define _TccWbxmlCharSetISO_8859_2						0x05U	/**< ISO-8859-2 */
#define _TccWbxmlCharSetISO_8859_3						0x06U	/**< ISO-8859-3 */
#define _TccWbxmlCharSetISO_8859_4						0x07U	/**< ISO-8859-4 */
#define _TccWbxmlCharSetISO_8859_5						0x08U	/**< ISO-8859-5 */
#define _TccWbxmlCharSetISO_8859_6						0x09U	/**< ISO-8859-6 */
#define _TccWbxmlCharSetISO_8859_7						0x0AU	/**< ISO-8859-7 */
#define _TccWbxmlCharSetISO_8859_8						0x0BU	/**< ISO-8859-8 */
#define _TccWbxmlCharSetISO_8859_9						0x0CU	/**< ISO-8859-9 */
#define _TccWbxmlCharSetShiftJis						0x11U	/**< Shift_JIS */
#define _TccWbxmlCharSetUtf8							0x6AU	/**< UTF-8 */
#define _TccWbxmlCharSetIso10646Ucs2					0x3E8U	/**< ISO-10646-UCS-2 */
#define _TccWbxmlCharSetUtf16							0x3F7U	/**< UTF-16 */
#define _TccWbxmlCharSetBig5							0x7EAU	/**< Big5 */


struct TccWxStr{
	tu8* iStr;
	ti32 iLen;
};

#define _TccWxStrCopy(a, b) {a.iStr = b.iStr; a.iLen = b.iLen;}
#define _TccWxStrClear(a) {a.iStr = NULL; a.iLen = 0;}


class TccWbxmlEncode : public TccStr8{
public:

	inline terror CheckSize(ti32 aLen) {
		return Resize(Length() + aLen);
	}
//	void AppendBase64(const tu8* aValue, ti32 len);
//	inline void AppendBase64(const void* aValue){AppendBase64((const tu8*)aValue, TccStrlen(aValue));}

	inline void AddByte(tu8 aByte){
		TccAssert(Length() < MaxLength());
		iPtr[StepLength()] = aByte;
	}

	inline void EncodeSwitchPage(tu8 aCodePage){
		TccAssert(Length() + 1 < MaxLength());
		iPtr[StepLength()] = _TccWbxmlTokenSwitchPage; 
		iPtr[StepLength()] = aCodePage;
	}

	inline void EncodeEnd(){
		TccAssert(Length() < MaxLength());
		iPtr[StepLength()] = _TccWbxmlTokenEnd;
	}

	TCCIMPORT void EncodeMbUint32(tu32 aValue);
	TCCIMPORT void EncodeOpaque(const void* aValue, ti32 len);
	TCCIMPORT void EncodeStrI(const tu8* aValue, ti32 len);
	TCCIMPORT void EncodeStrIDec(tu32 aValue);
	inline void EncodeStrI(const void* aValue){EncodeStrI((const tu8*)aValue, TccStrlen(aValue));}

	inline void EncodeTagOpaque(tu8 aTag, const TccDesC8& aValue){
		iPtr[StepLength()] = (aTag | _TccWbxmlTokenMaskWithContent);
		EncodeOpaque(aValue.Ptr(), aValue.Length());
		iPtr[StepLength()] = _TccWbxmlTokenEnd; 
	}

	TCCIMPORT void EncodeTagStrI(tu8 aTag, const tu8* aStr, ti32 aLen);
	inline void EncodeTagStrI(tu8 aTag, const tchar* aStr) {EncodeTagStrI(aTag, (const tu8*)aStr, TccStrlen(aStr));}
	inline void EncodeTagStrI(tu8 aTag, const TccWxStr& aValue) {EncodeTagStrI(aTag, (const tu8*)aValue.iStr, aValue.iLen);}
	inline void EncodeTagStrI(tu8 aTag, const TccDesC8& aValue) {EncodeTagStrI(aTag, (const tu8*)aValue.Ptr(), aValue.Length());}

	inline void EncodeTagStrIDec(tu8 aTag, tu32 aValue) {
		iPtr[StepLength()] = (aTag | _TccWbxmlTokenMaskWithContent);
		EncodeStrIDec(aValue);
		iPtr[StepLength()] = _TccWbxmlTokenEnd; 
	}
};

#if 0
#define add_attrs(_attrs, _codepage) {\
	if(_codepage != iCodePage){\
	iCodePage = _codepage;\
	_TccWbxmlEncodeAddByte(_TccWbxmlTokenSwitchPage);\
	_TccWbxmlEncodeAddByte(iCodePage);\
	}\
	_TccWbxmlEncodeAddByte(_attrs);\
}

#define add_attrs_stri(_attrs, _codepage, _value) {\
	add_attrs(_attrs, _codepage);\
	EncodeStringInlineL(_value, -1);\
}

#define add_attrs_base64stri(_attrs, _codepage, _value) {\
	add_attrs(_attrs, _codepage);\
	EncodeStringInlineBase64L(_value, -1);\
}

#define add_attrs_value(_attrs, _codepage, _value, _valcodepage) {\
	add_attrs(_attrs, _codepage);\
	if(_valcodepage != iCodePage){\
	iCodePage = _valcodepage;\
	_TccWbxmlEncodeAddByte(_TccWbxmlTokenSwitchPage);\
	_TccWbxmlEncodeAddByte(iCodePage);\
	}\
	_TccWbxmlEncodeAddByte(_value);\
}

#endif



#define _TccWbxmlParseTagStackLen 12
class TccWbxmlParser{

public:

	enum EWxParseTagMask{
		EWbxmlDecodeTag = 0, //һ������tag
		EWbxmlDecodeTagBegin, //tag��ʼ
		EWbxmlDecodeTagEnd //tag����
	};

	struct TccWxTag{
		tu16 iCodeTag;//��8λ��codepage,��8λ��tag
		TccWxStr iContent;
	};

	enum EParseStatus{
		EParseContinue = 0, //����
		EParseSuspend, //����
		EParseError,
		EParseEnd
	};

	tu8* iBuf; //parse data
	ti32 iBufLen; //buffer len
	ti32 iPos; //now parse pos

	tu8 iVersion;
	tu32 iPublicId;
	tu32 iPublicIdStrtbIndex;
	tu32 iCharset;

	TccWxStr iStringTbl;


	TccWxTag iTagStack[_TccWbxmlParseTagStackLen];
	ti16 iTagNum;
	tu8 iTagCodePage;

	TccErrCode iLastError;
	EParseStatus iParseStatus;

	TCCIMPORT TccWbxmlParser();
	TCCIMPORT virtual ~TccWbxmlParser();

	TCCIMPORT virtual terror Init(const void* aRecvBuf, ti32 aRecvBufLen);
	TCCIMPORT EParseStatus ParseNext();
	TCCIMPORT virtual void Clear();

protected:
	virtual EParseStatus StanzaHandle(EWxParseTagMask) = 0;

	TCCIMPORT terror ParseMbUint32(tu32 *result);
	TCCIMPORT terror ParseVersion();
	TCCIMPORT terror ParsePublicid();
	TCCIMPORT terror ParseCharset();
	TCCIMPORT terror ParseStrtbl();
	TCCIMPORT terror ParseStrI(TccWxStr* aRs);
	TCCIMPORT terror ParseStrT(TccWxStr* aRs);
	TCCIMPORT terror ParseOpaque(TccWxStr* aRs);
	TCCIMPORT terror ParseAttribute();

};

#endif //__TCC_WBXML_H_DEFINE__





//
//  MQQXxteaCoder.h
//  MQQSecure
//
//  Created by klaudz on 6/9/2017.
//  Copyright © 2017 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT
NSData * _Nullable MQQXxteaEncrypt(NSData *data, NSData *key);

FOUNDATION_EXPORT
NSData * _Nullable MQQXxteaDecrypt(NSData *data, NSData *key);

NS_ASSUME_NONNULL_END

//
//  TMFStatisticsManager.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/10/28.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

#import "TMFStatisticsConfiguration.h"
#import "TMFStatisticsUtilities.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsManager : NSObject

/**
 @brief 获取SDK版本号
*/
@property (nonatomic, class, copy, readonly) NSString *SDKVersion;

/**
 @brief 设置控制台日志开关
 */
@property (nonatomic, class, assign, getter=isLogEnabled) BOOL logEnabled;

/**
 @brief 上报配置管理对象
 */
@property (nonatomic, strong, nullable, readonly) TMFStatisticsConfiguration *configuration;

/**
 @brief 获取上报的管理实例
 */
+ (instancetype)defaultManager;
- (instancetype)init NS_UNAVAILABLE;

/**
 @brief 启动上报
 @param configuration 上报配置对象
*/
- (void)startWithConfiguration:(TMFStatisticsConfiguration *)configuration;

#pragma mark - Session

/**
 @brief 启动会话，一般无需手动调用。
*/
- (void)startNewSession;

/**
 @brief 停止会话，该接口操作会导致 `sessionID` 归零，影响会话的数据统计。
*/
- (void)stopSession;

#pragma mark - 页面统计事件

/**
 @brief 标记一次页面访问开始
 @param page 页面名，请保持唯一性
 @note 此接口需要与 `-trackEndPage:` 配对使用。多次开始以第一次开始时间为准。
*/
- (void)trackBeginPage:(NSString *)page;

/**
 @brief 标记一次页面访问开始
 @param page 页面名，请保持唯一性
 @param configuration 单次调用适用的上报配置，不带该参数，将使用 `-startWithConfiguration:` 中设置的全局配置
 @note 此接口需要与 `-trackEndPage:` 配对使用。多次开始以第一次开始时间为准。
*/
- (void)trackBeginPage:(NSString *)page configuration:(nullable TMFStatisticsConfiguration *)configuration;

/**
 @brief 标记一次页面访问结束
 @param page 页面名，对同一个页面的标记请保持与 `-trackBeginPage:` 的 page 一致
 @note 此接口需要与 `-trackBeginPage:` 配对使用。多次结束以第一次结束时间为准。
*/
- (void)trackEndPage:(NSString *)page;

/**
 @brief `-trackEndPage:` 多参数版本
 @param page 页面名
 @param labels 透传用户标签
 @note 此接口用法与 `-trackEndPage:` 一致
*/
- (void)trackEndPage:(NSString *)page labels:(nullable NSDictionary *)labels;

/**
 @brief `-trackEndPage:` 多参数版本
 @param page 页面名
 @param labels 透传用户标签
 @param configuration 单次调用适用的上报配置，不带该参数，将使用 `-startWithConfiguration:` 中设置的全局配置
 @note 此接口用法与 `-trackEndPage:` 一致
*/
- (void)trackEndPage:(NSString *)page labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

#pragma mark - 自定义统计事件

/**
 @brief 自定义统计上报
 @param eventID 事件ID
 @param kvs 自定义普通事件
*/
- (void)trackCustomKVEvent:(NSString *)eventID props:(nullable NSDictionary *)kvs;

/**
 @brief 自定义统计上报
 @param eventID 事件ID
 @param kvs 自定义普通事件
 @param labels 用户标签
*/
- (void)trackCustomKVEvent:(NSString *)eventID props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels;

/**
 @brief 自定义统计上报，可在该次上报中单次生效额外的配置，包括 `AppKey`，上报策略等。
 @param eventID 事件ID
 @param kvs 自定义普通事件
 @param labels 用户标签
 @param configuration 上报配置
*/
- (void)trackCustomKVEvent:(NSString *)eventID props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

/**
 @brief 自定义统计时长上报
 @param eventID 事件ID
 @param duration 统计时长
 @param kvs 自定义普通事件
*/
- (void)trackCustomKVTimeIntervalEvent:(NSString *)eventID duration:(NSInteger)duration props:(nullable NSDictionary *)kvs;

/**
 @brief 自定义统计时长上报
 @param eventID 事件ID
 @param duration 统计时长
 @param kvs 自定义普通事件
 @param labels 用户标签
*/
- (void)trackCustomKVTimeIntervalEvent:(NSString *)eventID duration:(NSInteger)duration props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels;

/**
 @brief 自定义统计时长上报，可在该次上报中单次生效额外的配置，包括 `AppKey`，上报策略等。
 @param eventID 事件ID
 @param duration 统计时长
 @param kvs 上报的 kv 参数
 @param labels 用户标签
 @param configuration 上报配置
*/
- (void)trackCustomKVTimeIntervalEvent:(NSString *)eventID duration:(NSInteger)duration props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

#pragma mark - App时长

/**
 @brief 标记 App 使用时长统计开始
 @note 建议在 App 进入前台  `-applicationDidBecomeActive:` 时候调用
*/
- (void)trackBeginActive;

/**
 @brief 标记 App 使用时长统计结束
 @note 建议在 App 离开前台  `-applicationDidEnterBackground:` 时候调用
*/
- (void)trackEndActive;

#pragma mark - 用户信息

/**
 @brief 自定义用户ID
 @param customUserID 用户ID
 @note 此接口设置的用户ID会被全局缓存使用，即时生效。
*/
- (void)setCustomUserID:(NSString *)customUserID;

/**
 @brief 自定义用户ID的多参数版本
 @param customUserID 用户ID
 @param labels 用户标签，kv 格式参数
 @note 此接口设置的用户ID会被全局缓存使用，即时生效。
*/
- (void)setCustomUserID:(NSString *)customUserID labels:(nullable NSDictionary *)labels;

/**
 @brief 自定义用户ID的多参数版本
 @param customUserID 用户ID
 @param labels 用户标签，kv 格式参数
 @param configuration 上报配置
 @note 此接口设置的用户ID会被全局缓存使用，即时生效。
*/
- (void)setCustomUserID:(NSString *)customUserID labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

/**
 @brief 设置上报的 ua
 @param userAgent WebView的 ua
 @note 此接口设置的 ua 会被全局缓存使用，即时生效。手动实现 `TMFStatisticsHandler` 后，可自动从 WebView 中获取，一般无需手动调用
*/
- (void)setUserAgent:(NSString *)userAgent;

@end

@interface TMFStatisticsManager (Error)

/**
 @brief 统计错误上报
 @param error 发生错误时候的 NSError
*/
- (void)trackError:(NSError *)error;

/**
 @brief 统计错误上报，可在该次上报中单次生效额外的配置，包括 `AppKey`，上报策略等。
 @param error 发生错误时候的 NSError
 @param configuration 上报配置
*/
- (void)trackError:(NSError *)error configuration:(nullable TMFStatisticsConfiguration *)configuration;

/**
 @brief 统计异常上报，包括异常的原因和堆栈
 @param exception 发生异常时候的 NSException
*/
- (void)trackException:(NSException *)exception;

/**
 @brief 统计异常上报，包括异常的原因和堆栈，可在该次上报中单次生效额外的配置，包括 `AppKey`，上报策略等。
 @param exception 发生异常时候的 NSException
 @param configuration 上报配置
*/
- (void)trackException:(NSException *)exception configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

extern NSString *TMFStatisticsManagerServerErrorDomain;

@interface TMFStatisticsManager ( /* Report */ )

@property (nonatomic, strong, nullable) NSError *lastError;

@end

@interface TMFStatisticsManager (Report)

/**
 @brief 触发本地缓存上报
 @note 可在适当的时机调用上报，提升统计的触达
*/
+ (void)reportIfNeeded;

@end

NS_ASSUME_NONNULL_END

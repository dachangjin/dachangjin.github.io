//
//  MQQHttpFormDataRequest.h
//  MQQSecure
//
//  Created by klaudz on 5/25/15.
//  Copyright (c) 2015 Tencent. All rights reserved.
//

#import "MQQHttpRequest.h"

@interface MQQHttpFormDataRequest : MQQHttpRequest

- (void)addData:(NSData *)data withFileName:(NSString *)fileName andContentType:(NSString *)contentType forKey:(NSString *)key;

@end

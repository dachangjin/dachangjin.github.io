//
//  WAViewController.h
//  WedaSDK
//
//  Created by tommywwang on 08/18/2021.
//  Copyright (c) 2021 tommywwang. All rights reserved.
//

@import UIKit;

@interface WAViewController : UIViewController

@end

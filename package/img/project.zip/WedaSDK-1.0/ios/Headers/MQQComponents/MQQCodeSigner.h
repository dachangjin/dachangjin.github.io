//
//  MQQCodeSigner.h
//  Pods
//
//  Created by klaudz on 3/6/2019.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN
NSString *const MQQCodeSignerRSASHA1ErrorDomain;

FOUNDATION_EXTERN
NSData * _Nullable MQQCodeSignerRSASHA1Sign(NSData *data, NSData *privateKey_p12, NSString *passphraseForPrivateKey, NSError * _Nullable * _Nullable error);

FOUNDATION_EXTERN
BOOL MQQCodeSignerRSASHA1Verify(NSData *data, NSData *publicKey_der, NSData *signature, NSError * _Nullable * _Nullable error);

NS_ASSUME_NONNULL_END

//
//  QBCustomProtocolWorker.h
//  WKVSUIDemo
//
//  Created by zuckchen on 30/12/2016.
//  Copyright © 2016 zuckchen. All rights reserved.
//

#import "TMFWKProtocolWorker.h"

@interface QBCustomProtocolWorker : TMFWKProtocolWorker

@end

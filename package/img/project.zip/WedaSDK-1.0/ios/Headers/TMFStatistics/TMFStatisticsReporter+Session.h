//
//  TMFStatisticsReporter+Session.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Session)

- (void)et1_SESSION_ENV_EventWithConfiguration:(nullable TMFStatisticsConfiguration *)configuration;

- (void)startNewSession;
- (void)stopSession;

- (void)checkSessionIfExpired;

@end

NS_ASSUME_NONNULL_END

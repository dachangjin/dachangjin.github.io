//
//  JSEvent.m
//  weapps
//
//  Created by tommywwang on 2020/6/3.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "JSEvent.h"

@implementation JSEvent

@end

//
//  TMFInstructionDefines.h
//  TMFInstruction
//
//  Created by bentonxiu on 2019/9/9.
//

#ifndef TMFInstructionDefines_h
#define TMFInstructionDefines_h

extern NSString *const TMFInstructionCenterDidUpdateNotification;   ///< 云指令发生更新通知
extern NSString *const TMFInstructionCenterUpdatedIDsKey;           ///< 当前云指令更新内容 NSIndexSet<NSInteger>

/**
 *  组件内部调试日志等级
 */
typedef NS_OPTIONS(NSUInteger, TMFInstructionLogLevel) {
    TMFInstructionLogLevelNone  = 0,        ///< 无日志
    TMFInstructionLogLevelInfo  = 1 << 0,   ///< 普通日志
    TMFInstructionLogLevelWarn  = 1 << 1,   ///< 警告日志
    TMFInstructionLogLevelError = 1 << 2,   ///< 错误日志
    
    TMFInstructionLogLevelAll   = 0xFF,     ///< 全部日志
};

#endif /* TMFInstructionDefines_h */

//
//  MQQTccCompressor+Cpp.h
//  MQQComponents
//
//  Created by klaudz on 29/10/2019.
//

#import "MQQTccCompressor.h"
#include <vector>

NS_ASSUME_NONNULL_BEGIN

@interface MQQTccCompressor (Cpp)

+ (BOOL)compressVector:(const std::vector<char> &)fromVector
              toVector:(std::vector<char> &)toVector
                 error:(NSError * _Nullable * _Nullable)error;

+ (BOOL)decompressVector:(const std::vector<char> &)fromVector
                toVector:(std::vector<char> &)toVector
                   error:(NSError * _Nullable * _Nullable)error;

@end

NS_ASSUME_NONNULL_END

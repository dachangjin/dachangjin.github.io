//
//  AppConfig.h
//  weapps
//
//  Created by tommywwang on 2020/6/15.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SDK_VERSION @"1.0.1"
#define H5_VERSION_KEY @"bundleVersion"

static NSString *const kWechatId = @"wxb9eaecc64dc63196";//脚本自动设置
static NSString *const kWechatUL = @"https://weapps.tencent.com/weapps/";//脚本自动设置
static NSString *const kWechatKey = @"7aed37ad6318588605ddb8537f93a88a";//脚本自动设置
static NSString *const kBuglyId = @"wa2133ewaeadd";//脚本自动设置
static NSString *const kBuglyKey = @"124dasdasdasdasd";//脚本自动设置
static NSString *const kCloudFaceId = @"asd2edsd";//脚本自动设置
static NSString *const kCloudFaceKey = @"44rfsawd21edasd";//脚本自动设置
static NSString *const kCloudLicense = @"123edsadasdasd";//脚本自动设置
static NSString *const kSplashSource = @"";//脚本自动设置
static NSString *const kSplashURL = @"https://www.tencent.com";//脚本自动设置
static const int kSplashTime = 1;//脚本5动设置
static NSString *const kSplashJumpURL = @"https://www.tencent.com/path";//脚本自动设置
static NSString *const kDebugURLPath = @"http://10.7.166.53/web/";
static const int TRTCSDK_APP_ID = 1400422492; //VoIP appId
static NSString *const TRTCSDK_SECRET_KEY = @"6e9939399e5df5399797f9206de845ac5cd1bb6e8b08544142520a43e7369ea4"; //VoIP key
static NSString *const kLivePlayerURL = @"http://license.vod2.myqcloud.com/license/v1/17b099d250538e3ad254420de8e983fa/TXLiveSDK.licence";  //直播licence的URL
static NSString *const kLivePlayerKey = @"65a493dd9e9f0e5f5d6306d8fa80fd4a";  //直播licence的key
static NSString *const kMapApiKey = @"6FSBZ-AT53D-M4O4S-PNK6D-YO2SH-FJB5Q";




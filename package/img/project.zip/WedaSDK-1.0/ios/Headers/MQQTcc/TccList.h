#ifndef __TCC_LIST_H_DEFINED__
#define __TCC_LIST_H_DEFINED__

#include "TccBase.h"
#include "TccContainerBase.inl.h"

template <typename T, typename _traits = TccTraits<T> >
class TccList{
protected:
	class Node {
	public:
		T iElement;
		Node* iNext;
		Node* iPrev;

		Node() : iNext(NULL), iPrev(NULL){}
		Node(const T& object) : iElement(object), iNext(NULL), iPrev(NULL){}
		~Node(){}
	};
	
	Node* iRootBack; //���Ľڵ�
	Node* iRootFront; //��ǰ�Ľڵ�
	ti32 iSize;


	//	inline T& ();
	//	inline T& Front();

	void TakeOffOneNode(Node*& aNode);
	//��p�ӵ�AtNode֮ǰ��
	void AddOneNode(Node* AtNode, Node* p);

public:
	class Iterator{
		friend class TccList;
	protected:
		Node* iCurr;
		Node* iBack;
		Iterator(Node* pCurr, Node* pBack) : iCurr(pCurr), iBack(pBack){}
	public:
		Iterator() : iCurr(NULL), iBack(NULL){}
		Iterator(const Iterator& it){*this = it;}

		Iterator& operator=(const Iterator& it){
			iCurr = it.iCurr;
			iBack = it.iBack;
			return *this;
		}
		T& operator*(){
			TccAssert(NULL != iCurr);
			return iCurr->iElement;
		}
		const T& operator*() const {
			TccAssert(NULL != iCurr);
			return iCurr->iElement;
		}
		T* operator->(){
			TccAssert(NULL != iCurr);
			return &(iCurr->iElement);
		}
		const T* operator->() const {
			TccAssert(NULL != iCurr);
			return &(iCurr->iElement);
		}

		Iterator& operator++(){ //++xx
			if(NULL != iCurr) iCurr = iCurr->iNext;
			return *this;
		}
		Iterator operator++(int){ //xx++,�Ǳ�׼����������
			Iterator it =*this;
			++(*this);
			return it;
		}
		Iterator& operator--(){ //--xx
			if(NULL == iCurr){
				iCurr = iBack;
			}
			else if(NULL != iCurr->iPrev){
				iCurr = iCurr->iPrev;
			}
			return *this;
		}
		Iterator operator--(int){ //xx++,�Ǳ�׼����������
			Iterator it = (*this);
			--(*this);
			return it;
		}
		tbool operator!=(const Iterator& it){return (tbool)(iCurr != it.iCurr);}
		tbool operator==(const Iterator& it){return (tbool)(iCurr == it.iCurr);}
		tbool isEnd(){return (tbool)(NULL == iCurr);}
	};

	TccList();
	~TccList();

	inline Iterator Begin() const;
	inline Iterator End() const;
	inline void Begin(Iterator& it) const;
	inline void End(Iterator& it) const;


	void Erase(Iterator& it);

	terror Insert(Iterator& it, const T& element);

	void PushFrontL(const T& element);
	terror PushFront(const T& element);
	void PopFront();
	void PopFrontAndDestroy();


	void PushBackL(const T& element);
	terror PushBack(const T& element);
	void PopBack();
	void PopBackAndDestroy();

	inline T& Back();
	inline T& Front();

	inline T& Front()const;


	void Clear();
	void Destroy();

	inline tbool Empty() const;
	inline ti32 Size() const;

	void EraseAndDestroy(Iterator& it);
	void EraseAndDestroy(const T& element);
	void Erase(const T& element);
	Iterator Find(const T& element);
	void Find(const T& element, Iterator& it);

	Iterator FindIndex(ti32 nIndex);
	void FindIndex(ti32 nIndex, Iterator& it);

	void Sort();

	void Merge(TccList<T, _traits>& rhs);
	void Swap(TccList<T, _traits>& rhs);

};


template<typename T, typename _traits = TccTraits<T> >
class TccCycleList{
protected:
	class Node {
	public:
		T iElement;
		Node* iNext;
		Node* iPrev;

		Node() : iNext(NULL), iPrev(NULL){}
		Node(const T& object) : iElement(object), iNext(NULL), iPrev(NULL){}
		~Node(){}
	};

	Node* iCurr; //��ǰ�Ľڵ�
	ti32 iSize;

protected:
	//��ѭ����������һ���ڵ�������ǰ�Ľڵ�
	Node* TakeOffOneNode(Node*& aNode);

public:
	TccCycleList();
	~TccCycleList();
	terror Push(const T& newElement);


	inline void Pre();
	inline void Next();
	inline const T& GetCur() const;
	inline T& GetCur();

	tbool MoveTo(const T& newElement);
	void StepTo(ti32 step);
	const T& Get(ti32 step) const;
	void EraseCur();
	void EraseCurAndDestroy();
	void Erase(const T& newElement);
	ti32 Find(const T& searchValue) const;

	void Clear();
	void Destroy();

	inline tbool Empty() const;
	inline ti32 Size() const;
};


#include "TccList.inl.h"

#endif //__TCC_LIST_H_DEFINED__





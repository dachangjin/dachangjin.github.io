//
//  JSCustomEvent.h
//  weapps
//
//  Created by tommywwang on 2021/6/8.
//  Copyright © 2021 tencent. All rights reserved.
//

#import "WAJSEvent.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^CompleteBlock)(NSDictionary *_Nullable result);


@interface WAJSCustomEvent : WAJSEvent

/// 成功回调
@property (nonatomic, copy, readonly) CompleteBlock callback;

/// callback name
@property (nonatomic, copy, readonly) NSString *callbackName;


- (id)initWithFuncName:(NSString *)funcName
                  args:(NSDictionary *)args
               webView:(WAWebView *)webView
        callbackString:(NSString *)callbackString;
@end

NS_ASSUME_NONNULL_END

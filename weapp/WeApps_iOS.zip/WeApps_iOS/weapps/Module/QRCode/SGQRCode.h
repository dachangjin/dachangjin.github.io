//
//  SGQRCode.h
//  Version 3.0.0
//  https://github.com/kingsic/SGQRCode
//
//  Created by kingsic on 2016/8/16.
//  Copyright © 2016年 kingsic. All rights reserved.
//
#import "SGQRCodeObtainConfigure.h"
#import "SGQRCodeObtain.h"
#import "SGQRCodeScanView.h"

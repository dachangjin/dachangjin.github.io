//
//  TMFWebOfflinePackageInfo.h
//  TMFWebOffline
//
//  Created by hauzhong on 2019/9/8.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 离线包更新类型
 */
typedef NS_ENUM(NSInteger, TMFWebOfflinePackageUpdateType) {
    TMFWebOfflinePackageUpdateTypeNone = 0,           ///< 离线包无更新
    TMFWebOfflinePackageUpdateTypeNormal = 1,         ///< 离线包整包更新
    TMFWebOfflinePackageUpdateTypeIncrement = 2,      ///< 离线包增量更新
};

@interface TMFWebOfflinePackageInfo : NSObject <NSCopying, NSCoding>

/**
 @brief 离线包业务BID
 */
@property (nonatomic, copy) NSString *BID;

/**
 @brief 离线包版本
 */
@property (nonatomic, assign) long version;

/**
 @brief 离线包本地已安装的版本号，未安装时版本号为0
 
 @note 可用类 `TMFWebOfflineService` 中的方法 `+localVersionForBID:` 进行判断
 */
@property (nonatomic, assign) long localVersion;

/**
 @brief 离线包是否过期。YES过期，NO则未过期
 */
@property (nonatomic, assign) BOOL expired;

/**
 @brief 离线包更新类型。
 */
@property (nonatomic, assign) TMFWebOfflinePackageUpdateType updateType;

/**
 @brief 离线包文件下载URL
 @note 整包URL。在 `updateType == TMFWebOfflinePackageUpdateTypeNormal` 时有效
 */
@property (nonatomic, copy) NSString *URL;

/**
 @brief 离线包MD5
 @note 整包MD5。在 `updateType == TMFWebOfflinePackageUpdateTypeNormal` 时有效
 */
@property (nonatomic, copy) NSString *MD5;

/**
 @brief 离线包 patch URL
 @note 增量包URL。在 `updateType == TMFWebOfflinePackageUpdateTypeIncrement` 时有效
 */
@property (nonatomic, copy, nullable) NSString *patchURL;

/**
 @brief 离线包 patch MD5
 @note 增量包MD5。在 `updateType == TMFWebOfflinePackageUpdateTypeIncrement` 时有效
 */
@property (nonatomic, copy, nullable) NSString *patchMD5;

/**
 @brief 设置离线包加密秘钥

 @param encryptKey 加密秘钥
 */
- (void)setEncryptKey:(NSString *)encryptKey;

@end

NS_ASSUME_NONNULL_END


#ifndef __TCC_STRINGEX_H_DEFINE__
#define __TCC_STRINGEX_H_DEFINE__

#include "TccBase.h"

#define _TCCLIT8(v, x) const static TccLitC8<sizeof(x)> v = {sizeof(x) - 1, x}
#define _TCCLIT16(v, x) const static TccLitC16<sizeof(L##x)/sizeof(twchar)> v = {sizeof(L##x) / sizeof(twchar) - 1, L##x}


#if !defined(__TccSymbian__)
#define _TccStrForceZeroTerminate //�������symbianƽ̨,��ʹ��0��βһ����Ч
#endif

//����Ա�֤256M��

#define _TccStrMaskLength 0xfffffffU
#define _TccStrShiftType 28
enum TccStrType { //���֧��16��
	ETccStrLitC, //���һ������0��β
	ETccStrPtrC,
	ETccStrPtr,
	ETccStrBuf, //���һ������0��β
#if defined(_TccStrForceZeroTerminate)
	ETccStrPtrCAlloc, //ptrc���͵��Զ�Ϊ0��β�������Զ������ڴ���.
	ETccStrAlloc, //TccStr���͵��Զ��������ڴ���
#endif
};

#if !defined(_TccStrForceZeroTerminate)
enum TccStrTypeEx {
	ETccStrPtrConst = 0, //ָ�벻�ܱ��ı�
	ETccStrPtrChangeable, //ָ����Ըı�,�������ڻ�û�ı�,����Ҫdel
	ETccStrPtrNeedDelete //ָ��ɸı�,������Ҫdel���ڵĵ�ַָ��Ŀռ���ܸı�
};
#endif

struct STccLitC8 {tint iLength;tu8 buf[1];};
struct STccPtrC8 {tint iLength;const tu8* iPtr;};
struct STccPtr8 {tint iLength;tint iMaxLen;tu8* iPtr;};
struct STccBuf8 {tint iLength;tint iMaxLen;tu8 buf[1];};

struct STccLitC16 {tint iLength;twchar buf[1];};
struct STccPtrC16 {tint iLength;const twchar* iPtr;};
struct STccPtr16 {tint iLength;tint iMaxLen;twchar* iPtr;};
struct STccBuf16 {tint iLength;tint iMaxLen;twchar buf[1];};




#ifdef __TccSymbian__
typedef char* TccVaList;
#define TccVaStart(ap,pn) (ap=(TccVaList)&pn+((sizeof(pn)+sizeof(int)-1)&~(sizeof(int)-1)),(void)0)
#define TccVaEnd(ap) (ap=0,(void)0)
#define TccVaArg(ap,type) (ap+=((sizeof(type)+sizeof(int)-1)&~(sizeof(int)-1)),(*(type *)(ap-((sizeof(type)+sizeof(int)-1)&~(sizeof(int)-1)))))
/*
#define TccVaList							VA_LIST
#define TccVaStart(arglist, aFmt)			VA_START(arglist, aFmt)
#define TccVaEnd(arglist)					VA_END(arglist)
#define TccVaArg(arglist, type)				VA_ARG(arglist, type)

typedef TInt8 *VA_LIST[1];
#define VA_START(ap,pn) ((ap)[0]=(TInt8 *)&pn+((sizeof(pn)+sizeof(TInt)-1)&~(sizeof(TInt)-1)),(void)0)
#define VA_END(ap) ((ap)[0]=0,(void)0)
#define VA_ARG(ap,type) ((ap)[0]+=((sizeof(type)+sizeof(TInt)-1)&~(sizeof(TInt)-1)),(*(type *)((ap)[0]-((sizeof(type)+sizeof(TInt)-1)&~(sizeof(TInt)-1)))))
*/
#else
#include <ctype.h>
#include <stdarg.h>
#define TccVaList							va_list
#define TccVaStart(arglist, aFmt)			va_start(arglist, aFmt)
#define TccVaEnd(arglist)					va_end(arglist)				
#define TccVaArg(arglist, type)				va_arg(arglist, type)
#endif


#ifdef __TccSymbian__
class _tstr16;
class _tstr8;
#endif


TCCIMPORT ti32 TccCStrincmp (const tchar* aConstStr, const tu8* aStr, ti32 aLen);

TCCIMPORT int TccSnprintf(tchar* string, ti32 count, const tchar* format, ... );
TCCIMPORT int TccSwnprintf(twchar*string, ti32 count, const twchar* format, ... );
TCCIMPORT int TccSnprintfCountLen(const tchar* format, ... );
TCCIMPORT int TccSwnprintfCountLen(const twchar* format, ... );

TCCIMPORT ti32 TccVfprintfA(tu8* dst, ti32 dstlen, const tu8* format, ti32 srclen, TccVaList argptr);
TCCIMPORT ti32 TccVfprintfW(twchar* dst, ti32 dstlen, const twchar* format, ti32 srclen, TccVaList argptr);
TCCIMPORT ti32 TccVfprintfCountLenA(const tu8* format, ti32 srclen, TccVaList argptr);
TCCIMPORT ti32 TccVfprintfCountLenW(const twchar* format, ti32 srclen, TccVaList argptr);


TCCIMPORT int TccSwcanf(const twchar* source, const twchar *format, ... );
TCCIMPORT int TccSscanf(const char* source, const char* format, ... );
TCCIMPORT ti32 TccVScanfW(const twchar* source, ti32 sourcelen, const twchar *format, ti32 formatlen, TccVaList arglist);
TCCIMPORT ti32 TccVScanfA(const tu8* source, ti32 sourcelen, const tu8 *format, ti32 formatlen, TccVaList arglist);

inline int TccSwcanfWithLen(const twchar* source, ti32 alen, const twchar *format, ...) {
	ti32 xx = TccWcslen(format);
	TccVaList arglist;
	TccVaStart(arglist, format);
	ti32 retval = TccVScanfW(source, alen, format, xx, arglist);
	TccVaEnd(arglist);
	return retval;
}




class TccDesC8;
class TccDesC16;
class TccPtrC8;
class TccPtrC16;

class TccDesC8
{	
public:

#if defined(__TccSymbian__) && !defined(_TccStrForceZeroTerminate)
	//typedef TRefByValue<const TDesC8> __TRefDesC8;	
	//inline const TDesC8* operator&() const;
	inline operator const TDesC8&() const;
	inline const TDesC8& operator()() const;
#if !defined(__TccSymbianKernel__)
	inline operator const __TRefDesC8() const;
#endif
	inline const TccDesC8& operator=(const TDesC8& aStr);
	inline const TDesC8* TDesPtr() const;
#endif

	inline tbool operator<(const TccDesC8 &aDes) const;
	inline tbool operator<=(const TccDesC8 &aDes) const;
	inline tbool operator>(const TccDesC8 &aDes) const;
	inline tbool operator>=(const TccDesC8 &aDes) const;
	inline tbool operator==(const TccDesC8 &aDes) const;
	inline tbool operator!=(const TccDesC8 &aDes) const;

	inline tbool Empty() const;

	TCCIMPORT const tu8& At(ti32 anIndex) const;
	TCCIMPORT const tu8& operator[](ti32 anIndex) const;

	inline ti32 Length() const;
	TCCIMPORT const tu8* Ptr() const;

#if defined(_TccStrForceZeroTerminate)
	TCCIMPORT void ZeroTerminate();
	TCCIMPORT const tu8* PtrZ() const;
#endif
	TCCIMPORT tbool IsNullTerminate() const;

	TCCIMPORT static ti32 Compare(const tu8* aStr1, ti32 aLen1, const tu8* aStr2, ti32 aLen2);
	TCCIMPORT static ti32 CompareF(const tu8* aStr1, ti32 aLen1, const tu8* aStr2, ti32 aLen2);

	TCCIMPORT ti32 Compare(const tu8* aStr, ti32 aLen) const;
	inline ti32 Compare(const tchar* aStr) const;
	inline ti32 Compare(const TccDesC8 &aDes) const;

	TCCIMPORT ti32 Compare(ti32 aPos, const tu8* aStr, ti32 aLen) const;
	inline ti32 Compare(ti32 aPos, const tchar* aStr) const;
	inline ti32 Compare(ti32 aPos, const TccDesC8 &aDes) const;

	TCCIMPORT ti32 CompareN(const tu8* aStr, ti32 aLen, ti32 aMaxCount) const;
	inline ti32 CompareN(const tchar* aStr, ti32 aMaxCount) const;
	inline ti32 CompareN(const TccDesC8 &aDes, ti32 aMaxCount) const;

	TCCIMPORT ti32 CompareN(ti32 aPos, const tu8* aStr, ti32 aLen, ti32 aMaxCount) const;
	inline ti32 CompareN(ti32 aPos, const tchar* aStr, ti32 aMaxCount) const;
	inline ti32 CompareN(ti32 aPos, const TccDesC8 &aDes, ti32 aMaxCount) const;

	TCCIMPORT ti32 CompareF(const tu8* aStr, ti32 aLen) const;
	inline ti32 CompareF(const tchar* aStr) const;
	inline ti32 CompareF(const TccDesC8 &aDes) const;

	TCCIMPORT ti32 CompareF(ti32 aPos, const tu8* aStr, ti32 aLen) const;
	inline ti32 CompareF(ti32 aPos, const tchar* aStr) const;
	inline ti32 CompareF(ti32 aPos, const TccDesC8 &aDes) const;

	TCCIMPORT ti32 CompareNF(const tu8* aStr, ti32 aLen, ti32 aMaxCount) const; //wcsnicmp
	inline ti32 CompareNF(const tchar* aStr, ti32 aMaxCount) const; //wcsnicmp
	inline ti32 CompareNF(const TccDesC8 &aDes, ti32 aMaxCount) const; //wcsnicmp

	TCCIMPORT tbool IsEndWith(const tu8* aStr, ti32 aLen) const;
	inline tbool IsEndWith(const tchar* aStr) const;
	inline tbool IsEndWith(const TccDesC8 &aDes) const;

	// find character starting at left, -1 if not found
	TCCIMPORT ti32 Find(const tu8& aChar, ti32 aPos = 0) const;

	TCCIMPORT ti32 Find(const tu8* aStr, ti32 aLen, ti32 aPos = 0) const;
	inline ti32 Find(const tchar* aStr, ti32 aPos = 0) const;
	inline ti32 Find(const TccDesC8 &aDes, ti32 aPos = 0) const;
	
	TCCIMPORT ti32 FindF(const tu8* aStr, ti32 aLen, ti32 aPos = 0) const;
	inline ti32 FindF(const tchar* aStr, ti32 aPos = 0) const;
	inline ti32 FindF(const TccDesC8 &aDes, ti32 aPos = 0) const;

	//malloc���ɳ���
#if !defined(__TccSymbianKernel__)
	TCCIMPORT tchar* Malloc() const;
#endif

	TCCIMPORT TccPtrC8 SubStr(ti32 pos = 0, ti32 len = -1) const;
	//void SubStrL(TccStr8& aSubStr, ti32 pos = 0, ti32 len = -1) const;
	TCCIMPORT TccPtrC8 Left(ti32 aLength) const;
	TCCIMPORT TccPtrC8 Right(ti32 aLength) const;


	inline ti32 ScanList(const void* aFmt, ti32 aLength, TccVaList aArgPtr)const;
	inline ti32 ScanList(const TccDesC8& aFmt, TccVaList aArgPtr)const;
#if defined(__TccSymbian__)
	TCCIMPORT ti32 Scan(TRefByValue<const TDesC8> aFmt, ...)const;
#endif
	TCCIMPORT ti32 Scan(TRefByValue<const TccDesC8> aFmt, ...)const;
	TCCIMPORT ti32 Scan(const tchar* aFmt, ...)const;


	inline ti32 ScanListP(ti32 aPos, const void* aFmt, ti32 aLength, TccVaList aArgPtr) const;
	inline ti32 ScanListP(ti32 aPos, const TccDesC8& aFmt, TccVaList aArgPtr) const;
#if defined(__TccSymbian__)
	TCCIMPORT ti32 ScanP(ti32 aPos, TRefByValue<const TDesC8> aFmt, ...) const;
#endif
	TCCIMPORT ti32 ScanP(ti32 aPos, TRefByValue<const TccDesC8> aFmt, ...) const ;
	TCCIMPORT ti32 ScanP(ti32 aPos, const tchar* aFmt, ...)const;


	TCCIMPORT ~TccDesC8();

protected:
	TCCIMPORT TccDesC8(const TccDesC8&);
	inline TccDesC8();
	inline TccDesC8(tint aType, tint aLength);
	inline tint Type() const;
#if defined(_TccStrForceZeroTerminate)
	inline void DoSetLength(tint aType, tint aLength) const;
#endif
	inline void DoSetLength(ti32 aLength);
	TCCIMPORT void MemoryClear();
	inline ti32 StepLength();

	TCCIMPORT const tu8* ForcePtrZ() const;

private:
	mutable tu32 iLength;
};

class TccDes8 : public TccDesC8{

public:

	TCCIMPORT tu8& At(ti32 anIndex);
	TCCIMPORT tu8& operator[](ti32 anIndex);

	inline void Zero();
	inline ti32 MaxLength() const;
	inline void SetLength(ti32 aLength);

#if !defined(_TccStrForceZeroTerminate)
	TCCIMPORT void ZeroTerminate();
	TCCIMPORT const tu8* PtrZ();
#endif
	inline tu8* WPtr();

	TCCIMPORT void CopyA(const void* aStr, ti32 aLen);
	inline void CopyA(const TccDesC8& aStr);
	inline void CopyA(const tchar *aStr);

	TCCIMPORT void AppendA(const void* aStr, ti32 aLen);
	inline void AppendA(const TccDesC8& aStr);
	inline void AppendA(const tchar* aStr);

	TCCIMPORT void InsertA(ti32 aPos, const void* aStr, ti32 aLen);
	inline void InsertA(ti32 aPos, const TccDesC8& aStr);
	inline void InsertA(ti32 aPos, const tchar* aStr);

	TCCIMPORT void ReplaceA(ti32 aPos, ti32 aLen, const void* aStr, ti32 aStrLen);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const TccDesC8& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const tchar* aStr);
	TCCIMPORT void ReplaceA(ti32 aPos, ti32 aValue);

	
#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
	inline void CopyA(const TDesC8& aStr);
	inline void AppendA(const TDesC8& aStr);
	inline void InsertA(ti32 aPos, const TDesC8& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const TDesC8& aStr);
	inline void CopyA(const _tstr8& aStr);
	inline void AppendA(const _tstr8& aStr);
	inline void InsertA(ti32 aPos, const _tstr8& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const _tstr8& aStr);
#endif

	
	inline void FormatListA(const void* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline void FormatListA(const TccDesC8& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
	TCCIMPORT void FormatA(TRefByValue<const TDesC8> aFmt, ...);
#endif
	TCCIMPORT void FormatA(TRefByValue<const TccDesC8> aFmt, ...);
	TCCIMPORT void FormatA(const tchar* aFmt, ...);

	TCCIMPORT void AppendFormatListA(const void* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline void AppendFormatListA(const TccDesC8& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
	TCCIMPORT void AppendFormatA(TRefByValue<const TDesC8> aFmt, ...);
#endif
	TCCIMPORT void AppendFormatA(TRefByValue<const TccDesC8> aFmt, ...);
	TCCIMPORT void AppendFormatA(const tchar* aFmt, ...);

	TCCIMPORT void Erase(ti32 aPos, ti32 aLen);
	TCCIMPORT void Fill(tchar aChar);
	TCCIMPORT void FillA(tchar aChar, ti32 aLen);
	TCCIMPORT void FillZero();
	TCCIMPORT void FillZeroA(ti32 aLen);
	TCCIMPORT void AppendFillA(tchar aChar, ti32 aLen);

	TCCIMPORT void TrimLeft();
	TCCIMPORT void TrimRight();
	inline void Trim();
	TCCIMPORT void TrimAll();

	TCCIMPORT void LowerCase();
	TCCIMPORT void UpperCase();

	TCCIMPORT void AppendCharA(tu8 aChar);

	//�Զ���4�ֽڶ���,���len�޸�,�Զ���0.
	TCCIMPORT void AppendAlign32A();
	//�Զ���2�ֽڶ���,���len�޸�,�Զ���0.
	TCCIMPORT void AppendAlign16A();



	TCCIMPORT void ToUtf8A(const twchar* aStr, ti32 aStrLen);
	inline void ToUtf8A(const TccDesC16& aStr);
	inline void ToUtf8A(const twchar* aStr);

	TCCIMPORT void AppendToUtf8A(const twchar* aStr, ti32 aStrLen);
	inline void AppendToUtf8A(const TccDesC16& aStr);
	inline void AppendToUtf8A(const twchar* aStr);

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
	inline void ToUtf8A(const TDesC16& aStr);
	inline void AppendToUtf8A(const TDesC16& aStr);
	inline void ToUtf8A(const _tstr16& aStr);
	inline void AppendToUtf8A(const _tstr16& aStr);
#endif

#if !defined(__TccSymbianTcbMode__)
	TCCIMPORT void ToGbkA(const twchar* aStr, ti32 aStrLen);
	inline void ToGbkA(const TccDesC16& aStr);
	inline void ToGbkA(const twchar* aStr);

	TCCIMPORT void AppendToGbkA(const twchar* aStr, ti32 aStrLen);
	inline void AppendToGbkA(const TccDesC16& aStr);
	inline void AppendToGbkA(const twchar* aStr);

#if defined(__TccSymbian__)
	inline void ToGbkA(const TDesC16& aStr);
	inline void AppendToGbkA(const TDesC16& aStr);
	inline void ToGbkA(const _tstr16& aStr);
	inline void AppendToGbkA(const _tstr16& aStr);
#endif
#endif
	
	TCCIMPORT terror XXTeaEncryptA(const void* aKey, ti32 aKeyLen);
	inline terror XXTeaEncryptA(const TccDesC8& aKey);
	inline terror XXTeaEncryptA(const tchar* aKey);

	TCCIMPORT terror XXTeaDecrypt(const void* aKey, ti32 aKeyLen);
	inline terror XXTeaDecrypt(const TccDesC8& aKey);
	inline terror XXTeaDecrypt(const tchar* aKey);

	TCCIMPORT terror DecodeBase64A(const void* aStr, ti32 aLen);
	inline terror DecodeBase64A(const TccDesC8& aStr);
	inline terror DecodeBase64A(const tchar* aStr);

	TCCIMPORT terror EncodeBase64A(const void* aStr, ti32 aLen);
	inline terror EncodeBase64A(const TccDesC8& aStr);
	inline terror EncodeBase64A(const tchar* aStr);

	TCCIMPORT terror AppendDecodeBase64A(const void* aStr, ti32 aLen);
	inline terror AppendDecodeBase64A(const TccDesC8& aStr);
	inline terror AppendDecodeBase64A(const tchar* aStr);

	TCCIMPORT terror AppendEncodeBase64A(const void* aStr, ti32 aLen);
	inline terror AppendEncodeBase64A(const TccDesC8& aStr);
	inline terror AppendEncodeBase64A(const tchar* aStr);

	TCCIMPORT terror AppendEncodeBase64A(ti32 aMaxlinelen, const void* aStr, ti32 aLen);
	inline terror AppendEncodeBase64A(ti32 aMaxlinelen, const TccDesC8& aStr);
	inline terror AppendEncodeBase64A(ti32 aMaxlinelen, const tchar* aStr);


public:
/*
	void Num(TInt64 aVal);
	void Num(TUint64 aVal, TRadix aRadix);
	void NumFixedWidth(TUint aVal,TRadix aRadix,TInt aWidth);
	void AppendNum(TInt64 aVal);
	void AppendNum(TUint64 aVal, TRadix aRadix);
	void AppendNumFixedWidth(TUint aVal,TRadix aRadix,TInt aWidth);
	void Swap(TDes8 &aDes);
	void Fold();
	void Collate();
	void Capitalize();
	void Repeat(const TUint8 *aBuf,TInt aLength);
	void Repeat(const TDesC8 &aDes);
	void Justify(const TDesC8 &aDes,TInt aWidth,TAlign anAlignment,TChar aFill);
	void NumFixedWidthUC(TUint aVal,TRadix aRadix,TInt aWidth);
	void NumUC(TUint64 aVal, TRadix aRadix=EDecimal);
	TInt Num(TReal aVal,const TRealFormat &aFormat) __SOFTFP;
	void AppendNumFixedWidthUC(TUint aVal,TRadix aRadix,TInt aWidth);
	TInt AppendNum(TReal aVal,const TRealFormat &aFormat) __SOFTFP;
	void AppendNumUC(TUint64 aVal,TRadix aRadix=EDecimal);
	void AppendJustify(const TDesC8 &Des,TInt aWidth,TAlign anAlignment,TChar aFill);
	void AppendJustify(const TDesC8 &Des,TInt aLength,TInt aWidth,TAlign anAlignment,TChar aFill);
	void AppendJustify(const TUint8 *aString,TInt aWidth,TAlign anAlignment,TChar aFill);
	void AppendJustify(const TUint8 *aString,TInt aLength,TInt aWidth,TAlign anAlignment,TChar aFill);
*/
	//~TccDes8();

	//TccDes8& operator=(const TccDesC8&);
	inline TccDes8& operator=(const tchar *aString);
	inline TccDes8& operator=(const TccDesC8 &aDes);
	inline TccDes8& operator=(const TccDes8 &aDes);


protected:
	TCCIMPORT TccDes8(const TccDes8&);
	TCCIMPORT ~TccDes8();

	inline TccDes8();
	inline void DoSetMaxLen(ti32 aMaxLen);

#if defined(_TccStrForceZeroTerminate)
	inline TccDes8(tint aType, tint aLength, tint aMaxLength);
#else
	inline TccDes8(tint aType, tint aLength, tint aExType, tint aMaxLength);
	inline tint ExType() const;
	inline void DoSetMaxLen(tint aExType, ti32 aMaxLen);
#endif

	TCCIMPORT terror CopyEx(const void* aStr, ti32 aLen);
private:
	tu32 iMaxLen;
};

inline void TccDes8::ReplaceA(ti32 aPos, ti32 aValue){
	TccAssert(aPos >= 0 && aPos + 4 <= Length());
	TccMemcpy(WPtr() + aPos, &aValue, sizeof(ti32));
}


//----------------------------------------------------
class TccPtrC8 : public TccDesC8{
public:
	TCCIMPORT TccPtrC8();
	TCCIMPORT TccPtrC8(const TccDesC8& aStr);
	TCCIMPORT TccPtrC8(const tchar* aStr);
	TCCIMPORT TccPtrC8(const void* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	TCCIMPORT TccPtrC8(const TDesC8& aStr);
#endif
	
	TCCIMPORT ~TccPtrC8();

	TCCIMPORT TccPtrC8& operator=(const TccPtrC8 &aDes);

	inline void Set(const TccDesC8& aPtr);
	inline void Set(const tchar* aStr);
	inline void Set(const void* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	inline void Set(const TDesC8& aStr);
	inline void Set(const _tstr8& aStr);
#endif

protected:
	const tu8* iPtr;
};

template<ti32 S>
class TccBuf8 : public TccDes8{

protected:
	tu8 iBuf[_TccAlign32(S + 1)];

public:
	TccBuf8();
	TccBuf8(const TccDesC8& aStr);
	TccBuf8(const tchar* aStr);
	TccBuf8(const void* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	TccBuf8(const TDesC8& aStr);
	TccBuf8(const _tstr8& aStr);
#endif
	~TccBuf8();

	inline TccBuf8<S>& operator=(const tchar* aString);
	inline TccBuf8<S>& operator=(const TccDesC8& aDes);
	inline TccBuf8<S>& operator=(const TccBuf8<S>& aBuf);

};

class TccPtr8 : public TccDes8{
protected:
	TCCIMPORT TccPtr8(const TccPtr8&);
public:
	TCCIMPORT TccPtr8();
	TCCIMPORT TccPtr8(tu8* aStr, ti32 aLen, ti32 aMaxLength);
	TCCIMPORT ~TccPtr8();

	TCCIMPORT void Set(tu8* aStr, ti32 aLen, ti32 aMaxLength);
	TCCIMPORT static void Swap(TccPtr8& stra, TccPtr8& strb);


	inline TccPtr8& operator=(const tchar *aString);
	inline TccPtr8& operator=(const TccDesC8& aDes);
	inline TccPtr8& operator=(const TccPtr8& aPtr);

protected:
	tu8* iPtr;
};


class TccStr8 : public TccDes8{
private:
	TCCIMPORT TccStr8(const TccDesC8&);

public:
	TCCIMPORT TccStr8();
	TCCIMPORT ~TccStr8();

	inline TccStr8& operator=(const tchar *aString);
	inline TccStr8& operator=(const TccDesC8& aDes);
	inline TccStr8& operator=(const TccStr8& aPtr);

	inline const tu8& operator[](ti32 anIndex) const;
	inline tu8& operator[](ti32 anIndex);
	
	TCCIMPORT terror Resize(ti32 aMaxLength);
	TCCIMPORT void Clear();

	TCCIMPORT static void Swap(TccStr8& stra, TccStr8& strb);

	TCCIMPORT terror Copy(const void* aStr, ti32 aLen);
	inline terror Copy(const TccDesC8& aStr);
	inline terror Copy(const tchar *aStr);

	TCCIMPORT terror Append(const void* aStr, ti32 aLen);
	inline terror Append(const TccDesC8& aStr);
	inline terror Append(const tchar* aStr);

	TCCIMPORT terror Insert(ti32 aPos, const void* aStr, ti32 aLen);
	inline terror Insert(ti32 aPos, const TccDesC8& aStr);
	inline terror Insert(ti32 aPos, const tchar* aStr);

	TCCIMPORT terror Replace(ti32 aPos, ti32 aLen, const void* aStr, ti32 aStrLen);
	inline terror Replace(ti32 aPos, ti32 aLen, const TccDesC8& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const tchar* aStr);

#if defined(__TccSymbian__)
	inline terror Copy(const TDesC8& aStr);
	inline terror Append(const TDesC8& aStr);
	inline terror Insert(ti32 aPos, const TDesC8& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const TDesC8& aStr);
	inline terror Copy(const _tstr8& aStr);
	inline terror Append(const _tstr8& aStr);
	inline terror Insert(ti32 aPos, const _tstr8& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const _tstr8& aStr);
#endif

	inline terror FormatList(const void* aFmt, ti32 aLength, TccVaList aArgPtr);
	inline terror FormatList(const TccDesC8& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT terror Format(TRefByValue<const TDesC8> aFmt, ...);
#endif
	TCCIMPORT terror Format(TRefByValue<const TccDesC8> aFmt, ...);
	TCCIMPORT terror Format(const tchar* aFmt, ...);

	TCCIMPORT terror AppendFormatList(const void* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline terror AppendFormatList(const TccDesC8& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT terror AppendFormat(TRefByValue<const TDesC8> aFmt, ...);
#endif
	TCCIMPORT terror AppendFormat(TRefByValue<const TccDesC8> aFmt, ...);
	TCCIMPORT terror AppendFormat(const tchar* aFmt, ...);

	TCCIMPORT void AppendNum(ti64 aVal, ti32 aRadix = 10);
	TCCIMPORT terror AppendChar(tu8 aChar);


	TCCIMPORT terror ToUtf8(const twchar* aStr, ti32 aStrLen);
	inline terror ToUtf8(const TccDesC16& aStr);
	inline terror ToUtf8(const twchar* aStr);

	TCCIMPORT terror AppendToUtf8(const twchar* aStr, ti32 aStrLen);
	inline terror AppendToUtf8(const TccDesC16& aStr);
	inline terror AppendToUtf8(const twchar* aStr);

#if defined(__TccSymbian__)
	inline terror ToUtf8(const TDesC16& aStr);
	inline terror AppendToUtf8(const TDesC16& aStr);
	inline terror ToUtf8(const _tstr16& aStr);
	inline terror AppendToUtf8(const _tstr16& aStr);
#endif

	
#if !defined(__TccSymbianTcbMode__)
	TCCIMPORT terror ToGbk(const twchar* aStr, ti32 aStrLen);
	inline terror ToGbk(const TccDesC16& aStr);
	inline terror ToGbk(const twchar* aStr);

	TCCIMPORT terror AppendToGbk(const twchar* aStr, ti32 aStrLen);
	inline terror AppendToGbk(const TccDesC16& aStr);
	inline terror AppendToGbk(const twchar* aStr);
#if defined(__TccSymbian__)
	inline terror ToGbk(const TDesC16& aStr);
	inline terror AppendToGbk(const TDesC16& aStr);
	inline terror ToGbk(const _tstr16& aStr);
	inline terror AppendToGbk(const _tstr16& aStr);
#endif
#endif

	TCCIMPORT terror AppendDecodeBase64(const void* aStr, ti32 aLen);
	inline terror AppendDecodeBase64(const TccDesC8& aStr);
	inline terror AppendDecodeBase64(const tchar* aStr);

	TCCIMPORT terror AppendEncodeBase64(const void* aStr, ti32 aLen);
	inline terror AppendEncodeBase64(const TccDesC8& aStr);
	inline terror AppendEncodeBase64(const tchar* aStr);

	TCCIMPORT terror AppendEncodeBase64(ti32 aMaxlinelen, const void* aStr, ti32 aLen);
	inline terror AppendEncodeBase64(ti32 aMaxlinelen, const TccDesC8& aStr);
	inline terror AppendEncodeBase64(ti32 aMaxlinelen, const tchar* aStr);


	TCCIMPORT terror AppendEncodeQuotedPrintable(const void* aStr, ti32 aLen);
	inline terror AppendEncodeQuotedPrintable(const TccDesC8& aStr);
	inline terror AppendEncodeQuotedPrintable(const tchar* aStr);


	TCCIMPORT terror AppendDecodeQuotedPrintable(const void* aStr, ti32 aLen);
	inline terror AppendDecodeQuotedPrintable(const TccDesC8& aStr);
	inline terror AppendDecodeQuotedPrintable(const tchar* aStr);


//void AppendUIntBigEndian(tu32 aValue);

protected:
	tu8* iPtr;
};

typedef TRefByValue<const TccDesC8> __TRefStrC8;

template <int S>
class TccLitC8
{
public:
	enum {BufferSize = S - 1};

	inline const TccDesC8* operator&() const;
	inline operator const TccDesC8&() const;
	inline const TccDesC8& operator()() const;
	inline operator const __TRefStrC8() const;

#if defined(__TccSymbian__)
	//inline const TDesC8* operator&() const;
	inline operator const TDesC8&() const;
	//inline const TDesC8& operator()() const;
	inline operator const __TRefDesC8() const;
#endif

public:
	int iLength;
	tu8 iBuf[_TccAlign32(S)];
};

//---------------------------------------------------------------------------------------------

class TccDesC16
{	
public:

#if defined(__TccSymbian__) && !defined(_TccStrForceZeroTerminate)
	//TccBStrC8(const TDesC8& aStr);
	//typedef TRefByValue<const TDesC8> __TRefDesC8;
	//inline const TDesC16* operator&() const;
	inline operator const TDesC16&() const;
	inline const TDesC16& operator()() const;
#if !defined(__TccSymbianKernel__)
	inline operator const __TRefDesC16() const;
#endif
	inline const TccDesC16& operator=(const TDesC16& aStr);
	inline const TDesC16* TDesPtr() const;
#endif

	inline tbool operator<(const TccDesC16 &aDes) const;
	inline tbool operator<=(const TccDesC16 &aDes) const;
	inline tbool operator>(const TccDesC16 &aDes) const;
	inline tbool operator>=(const TccDesC16 &aDes) const;
	inline tbool operator==(const TccDesC16 &aDes) const;
	inline tbool operator!=(const TccDesC16 &aDes) const;

	inline tbool Empty() const;
	inline ti32 Length() const;
	TCCIMPORT const twchar* Ptr() const;
#if defined(_TccStrForceZeroTerminate)
	TCCIMPORT void ZeroTerminate();
	TCCIMPORT const twchar* PtrZ() const;	
#endif
	TCCIMPORT tbool IsNullTerminate() const;

	TCCIMPORT const twchar& At(ti32 anIndex) const;
	TCCIMPORT const twchar& operator[](ti32 anIndex) const;
	
	TCCIMPORT static ti32 Compare(const twchar* aStr1, ti32 aLen1, const twchar* aStr2, ti32 aLen2);
	TCCIMPORT static ti32 CompareF(const twchar* aStr1, ti32 aLen1, const twchar* aStr2, ti32 aLen2);

	TCCIMPORT ti32 Compare(const twchar* aStr, ti32 aLen) const;
	inline ti32 Compare(const twchar* aStr) const;
	inline ti32 Compare(const TccDesC16 &aDes) const;

	TCCIMPORT ti32 Compare(ti32 aPos, const twchar* aStr, ti32 aLen) const;
	inline ti32 Compare(ti32 aPos, const twchar* aStr) const;
	inline ti32 Compare(ti32 aPos, const TccDesC16 &aDes) const;

	TCCIMPORT ti32 CompareN(const twchar* aStr, ti32 aLen, ti32 aMaxCount) const;
	inline ti32 CompareN(const twchar* aStr, ti32 aMaxCount) const;
	inline ti32 CompareN(const TccDesC16 &aDes, ti32 aMaxCount) const;

	TCCIMPORT ti32 CompareN(ti32 aPos, const twchar* aStr, ti32 aLen, ti32 aMaxCount) const;
	inline ti32 CompareN(ti32 aPos, const twchar* aStr, ti32 aMaxCount) const;
	inline ti32 CompareN(ti32 aPos, const TccDesC16 &aDes, ti32 aMaxCount) const;

	TCCIMPORT ti32 CompareF(const twchar* aStr, ti32 aLen) const;
	inline ti32 CompareF(const twchar* aStr) const;
	inline ti32 CompareF(const TccDesC16 &aDes) const;

	TCCIMPORT ti32 CompareF(ti32 aPos, const twchar* aStr, ti32 aLen) const;
	inline ti32 CompareF(ti32 aPos, const twchar* aStr) const;
	inline ti32 CompareF(ti32 aPos, const TccDesC16 &aDes) const;

	TCCIMPORT ti32 CompareNF(const twchar* aStr, ti32 aLen, ti32 aMaxCount) const; //wcsnicmp
	inline ti32 CompareNF(const twchar* aStr, ti32 aMaxCount) const; //wcsnicmp
	inline ti32 CompareNF(const TccDesC16 &aDes, ti32 aMaxCount) const; //wcsnicmp

	TCCIMPORT tbool IsEndWith(const twchar* aStr, ti32 aLen) const;
	inline tbool IsEndWith(const twchar* aStr) const;
	inline tbool IsEndWith(const TccDesC16 &aDes) const;
	
	// find character starting at left, -1 if not found
	TCCIMPORT ti32 Find(const twchar& aChar, ti32 aPos = 0) const;

	TCCIMPORT ti32 Find(const twchar* aStr, ti32 aLen, ti32 aPos = 0) const;
	inline ti32 Find(const twchar* aStr, ti32 aPos = 0) const;
	inline ti32 Find(const TccDesC16 &aDes, ti32 aPos = 0) const;

	TCCIMPORT ti32 FindF(const twchar* aStr, ti32 aLen, ti32 aPos = 0) const;
	inline ti32 FindF(const twchar* aStr, ti32 aPos = 0) const;
	inline ti32 FindF(const TccDesC16 &aDes, ti32 aPos = 0) const;

	//malloc���ɳ���
#if !defined(__TccSymbianKernel__)
	TCCIMPORT twchar* Malloc() const;
#endif

	TCCIMPORT TccPtrC16 SubStr(ti32 pos = 0, ti32 len = -1) const;
	//void SubStrL(TccStr8& aSubStr, ti32 pos = 0, ti32 len = -1) const;
	TCCIMPORT TccPtrC16 Left(ti32 aLength) const;
	TCCIMPORT TccPtrC16 Right(ti32 aLength) const;


	inline ti32 ScanList(const twchar* aFmt, ti32 aLength, TccVaList aArgPtr)const;
	inline ti32 ScanList(const TccDesC16& aFmt, TccVaList aArgPtr)const;
#if defined(__TccSymbian__)
	TCCIMPORT ti32 Scan(TRefByValue<const TDesC16> aFmt, ...)const;
#endif
	TCCIMPORT ti32 Scan(TRefByValue<const TccDesC16> aFmt, ...)const;
	TCCIMPORT ti32 Scan(const twchar* aFmt, ...)const;

	inline ti32 ScanListP(ti32 aPos, const twchar* aFmt, ti32 aLength, TccVaList aArgPtr)const;
	inline ti32 ScanListP(ti32 aPos, const TccDesC16& aFmt, TccVaList aArgPtr)const;
#if defined(__TccSymbian__)
	TCCIMPORT ti32 ScanP(ti32 aPos, TRefByValue<const TDesC16> aFmt, ...)const;
#endif
	TCCIMPORT ti32 ScanP(ti32 aPos, TRefByValue<const TccDesC16> aFmt, ...)const;
	TCCIMPORT ti32 ScanP(ti32 aPos, const twchar* aFmt, ...)const;


	TCCIMPORT ~TccDesC16();

protected:
	TCCIMPORT TccDesC16(const TccDesC16&);
	inline TccDesC16();
	inline TccDesC16(tint aType, tint aLength);
	inline tint Type() const;
#if defined(_TccStrForceZeroTerminate)
	inline void DoSetLength(tint aType, tint aLength) const;
#endif
	inline void DoSetLength(ti32 aLength);
	TCCIMPORT void MemoryClear();

	TCCIMPORT const twchar* ForcePtrZ() const;

private:
	mutable tu32 iLength;
};

class TccDes16 : public TccDesC16{

public:

	TCCIMPORT twchar& At(ti32 anIndex);
	TCCIMPORT twchar& operator[](ti32 anIndex);

	inline void Zero();
	inline ti32 MaxLength() const;
	inline void SetLength(ti32 aLength);

#if !defined(_TccStrForceZeroTerminate)
	TCCIMPORT void ZeroTerminate();
	TCCIMPORT const twchar* PtrZ();
#endif
	inline twchar* WPtr();

	TCCIMPORT void CopyA(const twchar* aStr, ti32 aLen);
	inline void CopyA(const TccDesC16& aStr);
	inline void CopyA(const twchar* aStr);

	TCCIMPORT void AppendA(const twchar* aStr, ti32 aLen);
	inline void AppendA(const TccDesC16& aStr);
	inline void AppendA(const twchar* aStr);

	TCCIMPORT void InsertA(ti32 aPos, const twchar* aStr, ti32 aLen);
	inline void InsertA(ti32 aPos, const TccDesC16& aStr);
	inline void InsertA(ti32 aPos, const twchar* aStr);

	TCCIMPORT void ReplaceA(ti32 aPos, ti32 aLen, const twchar* aStr, ti32 aStrLen);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const TccDesC16& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const twchar* aStr);

#if defined(__TccSymbian__)
	inline void CopyA(const TDesC16& aStr);
	inline void AppendA(const TDesC16& aStr);
	inline void InsertA(ti32 aPos, const TDesC16& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const TDesC16& aStr);
	inline void CopyA(const _tstr16& aStr);
	inline void AppendA(const _tstr16& aStr);
	inline void InsertA(ti32 aPos, const _tstr16& aStr);
	inline void ReplaceA(ti32 aPos, ti32 aLen, const _tstr16& aStr);
#endif

	
	inline void FormatListA(const twchar* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline void FormatListA(const TccDesC16& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT void FormatA(TRefByValue<const TDesC16> aFmt, ...);
#endif
	TCCIMPORT void FormatA(TRefByValue<const TccDesC16> aFmt, ...);
	TCCIMPORT void FormatA(const twchar* aFmt, ...);

	TCCIMPORT void AppendFormatListA(const twchar* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline void AppendFormatListA(const TccDesC16& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT void AppendFormatA(TRefByValue<const TDesC16> aFmt, ...);
#endif
	TCCIMPORT void AppendFormatA(TRefByValue<const TccDesC16> aFmt, ...);
	TCCIMPORT void AppendFormatA(const twchar* aFmt, ...);

	TCCIMPORT void Erase(ti32 aPos, ti32 aLen);
	TCCIMPORT void Fill(twchar aChar);
	TCCIMPORT void FillA(twchar aChar, ti32 aLen);
	TCCIMPORT void FillZero();
	TCCIMPORT void FillZeroA(ti32 aLen);
	TCCIMPORT void AppendFillA(twchar aChar, ti32 aLen);

	TCCIMPORT void TrimLeft();
	TCCIMPORT void TrimRight();
	inline void Trim();
	TCCIMPORT void TrimAll();

	TCCIMPORT void LowerCase();
	TCCIMPORT void UpperCase();

	TCCIMPORT void AppendCharA(twchar aChar);


	TCCIMPORT void FromUtf8A(const void* aStr, ti32 aStrLen);
	inline void FromUtf8A(const TccDesC8& aStr);
	inline void FromUtf8A(const tchar* aStr);

	TCCIMPORT void AppendFromUtf8A(const void* aStr, ti32 aStrLen);
	inline void AppendFromUtf8A(const TccDesC8& aStr);
	inline void AppendFromUtf8A(const tchar* aStr);

#if defined(__TccSymbian__)
	inline void FromUtf8A(const TDesC8& aStr);
	inline void AppendFromUtf8A(const TDesC8& aStr);
	inline void FromUtf8A(const _tstr8& aStr);
	inline void AppendFromUtf8A(const _tstr8& aStr);
#endif
	
#if !defined(__TccSymbianTcbMode__)
	TCCIMPORT void FromGbkA(const void* aStr, ti32 aStrLen);
	inline void FromGbkA(const TccDesC8& aStr);
	inline void FromGbkA(const tchar* aStr);

	TCCIMPORT void AppendFromGbkA(const void* aStr, ti32 aStrLen);
	inline void AppendFromGbkA(const TccDesC8& aStr);
	inline void AppendFromGbkA(const tchar* aStr);
	
#if defined(__TccSymbian__)
	inline void FromGbkA(const TDesC8& aStr);
	inline void AppendFromGbkA(const TDesC8& aStr);
	inline void FromGbkA(const _tstr8& aStr);
	inline void AppendFromGbkA(const _tstr8& aStr);
#endif

#endif
	
public:


	inline TccDes16& operator=(const twchar *aString);
	inline TccDes16& operator=(const TccDesC16 &aDes);
	inline TccDes16& operator=(const TccDes16 &aDes);


protected:
	TCCIMPORT ~TccDes16();
	TCCIMPORT TccDes16(const TccDes16&);
	inline TccDes16();
	inline void DoSetMaxLen(ti32 aMaxLen);

#if defined(_TccStrForceZeroTerminate)
	inline TccDes16(tint aType, tint aLength, tint aMaxLength);
#else
	inline TccDes16(tint aType, tint aLength, tint aExType, tint aMaxLength);
	inline tint ExType() const;
	inline void DoSetMaxLen(tint aExType, ti32 aMaxLen);
#endif

	TCCIMPORT terror CopyEx(const twchar* aStr, ti32 aLen);

private:

	tu32 iMaxLen;
};


//----------------------------------------------------
class TccPtrC16 : public TccDesC16{
public:
	TCCIMPORT TccPtrC16();
	TCCIMPORT TccPtrC16(const TccDesC16& aStr);
	TCCIMPORT TccPtrC16(const twchar* aStr);
	TCCIMPORT TccPtrC16(const twchar* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	TCCIMPORT TccPtrC16(const TDesC16& aStr);
#endif

	TCCIMPORT ~TccPtrC16();

	TCCIMPORT TccPtrC16& operator=(const TccPtrC16 &aDes);

	inline void Set(const TccDesC16& aPtr);
	inline void Set(const twchar* aStr);
	inline void Set(const twchar* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	inline void Set(const TDesC16& aStr);
	inline void Set(const _tstr16& aStr);
#endif

protected:
	const twchar* iPtr;
};

template<ti32 S>
class TccBuf16 : public TccDes16{

protected:
	twchar iBuf[_TccAlign16(S + 1)];

public:
	TccBuf16();
	TccBuf16(const TccDesC16& aStr);
	TccBuf16(const twchar* aStr);
	TccBuf16(const twchar* aStr, ti32 aLen);
#if defined(__TccSymbian__)
	TccBuf16(const TDesC16& aStr);
	TccBuf16(const _tstr16& aStr);
#endif
	~TccBuf16();

	inline TccBuf16<S>& operator=(const twchar* aString);
	inline TccBuf16<S>& operator=(const TccDesC16& aDes);
	inline TccBuf16<S>& operator=(const TccBuf16<S>& aBuf);
};


class TccPtr16 : public TccDes16{
public:
	TCCIMPORT TccPtr16();
	TCCIMPORT TccPtr16(twchar* aStr, ti32 aLen, ti32 aMaxLength);
	TCCIMPORT ~TccPtr16();

	TCCIMPORT void Set(twchar* aStr, ti32 aLen, ti32 aMaxLength);
	TCCIMPORT static void Swap(TccPtr16& stra, TccPtr16& strb);

	inline TccPtr16& operator=(const twchar *aString);
	inline TccPtr16& operator=(const TccDesC16& aDes);
	inline TccPtr16& operator=(const TccPtr16& aPtr);

protected:
	TccPtr16(const TccPtr16&);
	twchar* iPtr;
};


class TccStr16 : public TccDes16{
private:
	TCCIMPORT TccStr16(const TccDesC16&);
#if !defined(__TccWin32__) && !defined(__TccPosix__) && !defined(__TccAndroidNDK__) && !defined(__TccMeeGo__)
	TCCIMPORT TccStr16(const TccStr16&);
#endif
public:
	TCCIMPORT TccStr16();
	TCCIMPORT ~TccStr16();

#if defined(__TccWin32__) || defined(__TccPosix__) || defined(__TccAndroidNDK__) || defined(__TccMeeGo__)
	TCCIMPORT TccStr16(const TccStr16&);
#endif

	inline TccStr16& operator=(const twchar *aString);
	inline TccStr16& operator=(const TccDesC16& aDes);
	inline TccStr16& operator=(const TccStr16& aPtr);

	inline const twchar& operator[](ti32 anIndex) const;
	inline twchar& operator[](ti32 anIndex);
		
	TCCIMPORT terror Resize(ti32 aMaxLength);
	TCCIMPORT void Clear();

	TCCIMPORT static void Swap(TccStr16& stra, TccStr16& strb);

	TCCIMPORT terror Copy(const twchar* aStr, ti32 aLen);
	inline terror Copy(const TccDesC16& aStr);
	inline terror Copy(const twchar *aStr);

	TCCIMPORT terror Append(const twchar* aStr, ti32 aLen);
	inline terror Append(const TccDesC16& aStr);
	inline terror Append(const twchar* aStr);

	TCCIMPORT terror Insert(ti32 aPos, const twchar* aStr, ti32 aLen);
	inline terror Insert(ti32 aPos, const TccDesC16& aStr);
	inline terror Insert(ti32 aPos, const twchar* aStr);

	TCCIMPORT terror Replace(ti32 aPos, ti32 aLen, const twchar* aStr, ti32 aStrLen);
	inline terror Replace(ti32 aPos, ti32 aLen, const TccDesC16& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const twchar* aStr);

#if defined(__TccSymbian__)
	inline terror Copy(const TDesC16& aStr);
	inline terror Append(const TDesC16& aStr);
	inline terror Insert(ti32 aPos, const TDesC16& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const TDesC16& aStr);
	inline terror Copy(const _tstr16& aStr);
	inline terror Append(const _tstr16& aStr);
	inline terror Insert(ti32 aPos, const _tstr16& aStr);
	inline terror Replace(ti32 aPos, ti32 aLen, const _tstr16& aStr);
#endif

	inline terror FormatList(const twchar* aFmt, ti32 aLength, TccVaList aArgPtr);
	inline terror FormatList(const TccDesC16& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT terror Format(TRefByValue<const TDesC16> aFmt, ...);
#endif
	TCCIMPORT terror Format(TRefByValue<const TccDesC16> aFmt, ...);
	TCCIMPORT terror Format(const twchar* aFmt, ...);

	TCCIMPORT terror AppendFormatList(const twchar* aFmt, ti32 aLen, TccVaList aArgPtr);
	inline terror AppendFormatList(const TccDesC16& aFmt, TccVaList aArgPtr);
#if defined(__TccSymbian__)
	TCCIMPORT terror AppendFormat(TRefByValue<const TDesC16> aFmt, ...);
#endif
	TCCIMPORT terror AppendFormat(TRefByValue<const TccDesC16> aFmt, ...);
	TCCIMPORT terror AppendFormat(const twchar* aFmt, ...);

	TCCIMPORT void AppendNum(ti64 aVal, ti32 aRadix = 10);
	TCCIMPORT terror AppendChar(twchar aChar);


	TCCIMPORT terror FromUtf8(const void* aStr, ti32 aStrLen);
	inline terror FromUtf8(const TccDesC8& aStr);
	inline terror FromUtf8(const tchar* aStr);

	TCCIMPORT terror AppendFromUtf8(const void* aStr, ti32 aStrLen);
	inline terror AppendFromUtf8(const TccDesC8& aStr);
	inline terror AppendFromUtf8(const tchar* aStr);

#if defined(__TccSymbian__)
	inline terror FromUtf8(const TDesC8& aStr);
	inline terror AppendFromUtf8(const TDesC8& aStr);
	inline terror FromUtf8(const _tstr8& aStr);
	inline terror AppendFromUtf8(const _tstr8& aStr);
#endif
	
	
	
#if !defined(__TccSymbianTcbMode__)
	TCCIMPORT terror FromGbk(const void* aStr, ti32 aStrLen);
	inline terror FromGbk(const TccDesC8& aStr);
	inline terror FromGbk(const tchar* aStr);

	TCCIMPORT terror AppendFromGbk(const void* aStr, ti32 aStrLen);
	inline terror AppendFromGbk(const TccDesC8& aStr);
	inline terror AppendFromGbk(const tchar* aStr);

#if defined(__TccSymbian__)
	inline terror FromGbk(const TDesC8& aStr);
	inline terror AppendFromGbk(const TDesC8& aStr);
	inline terror FromGbk(const _tstr8& aStr);
	inline terror AppendFromGbk(const _tstr8& aStr);
#endif

#endif

protected:
	twchar* iPtr;
};


#if defined(__TccSymbian__)
#include <e32def.h>
#if defined(__GCC32__)
typedef wchar_t __TccText;
#elif defined(__VC32__)
typedef TUint16 __TccText;
#elif defined(__CW32__)
typedef TUint16 __TccText;
#elif defined(ANDROID_NDK)
typedef wchar_t __TccText;
#elif defined(__TText_defined)
typedef __TText __TccText;
#else
#error	no typedef for __TccText
#endif
#else
typedef twchar __TccText;
#endif
typedef TRefByValue<const TccDesC16> __TRefStrC16;

template <int S>
class TccLitC16
{
public:
	enum {BufferSize = S - 1};

	inline const TccDesC16* operator&() const;
	inline operator const TccDesC16&() const;
	inline const TccDesC16& operator()() const;
	inline operator const __TRefStrC16() const;

#if defined(__TccSymbian__)
	//inline const TDesC16* operator&() const;
	inline operator const TDesC16&() const;
	//inline const TDesC16& operator()() const;
#if	!defined(__TccSymbianKernel__)
	inline operator const __TRefDesC16() const;
#endif
#endif
public:
	int iLength;
	__TccText iBuf[_TccAlign16(S)];
};








typedef TccStr8 TccBuffer;
typedef TccStr16 TccString;


/*
typedef TccDesC16 TccDesC;
typedef TccDes16 TccDes;
typedef TccPtrC16 TccPtrC;
typedef TccPtr16 TccPtr;
typedef TccStr16 TccStr;
*/


//--------------------------------------------------------------------------
#if 0
// �ᵽJniStringConvertor.h
#ifdef __TccAndroidNDK__
#include <jni.h>

jstring TccStr8ToJString(JNIEnv* env, const TccDesC8& aStr8);
jstring TccStr16ToJString(JNIEnv* env, const TccDesC16& aStr16);
terror TccStr8FromJString(JNIEnv* env, const jstring& src, TccStr8& aDst);
terror TccStr16FromJString(JNIEnv* env, const jstring& src, TccStr16& aDst);
terror CharStringFromJString(JNIEnv*env, const jstring jstr, char *charArray, int maxLen);

#endif
#endif

_TCCLIT8(KTccNullString8, "");
_TCCLIT16(KTccNullString16, "");



#ifdef __TccSymbian__
#include "TccTagType.h"
#endif

#if defined(__TccUnicodeImplement__)
#undef __TccUnicodeImplement__
#endif
#include "TccString.inl.h"
#define __TccUnicodeImplement__
#include "TccString.inl.h"
#undef __TccUnicodeImplement__

template<typename T>
T* TccTrimSpace(T* str){
	if(str == NULL) return NULL;
	int i = 0, j = 0;
	while(TccIsspace(str[i]) && str[i] != '\0') i++;
	if(i > 0) 
		while((str[j] = str[i++]) != '\0') j++;
	else
		j = TccStrlen(str);
	j--;
	if(j < 0) return str;

	while(TccIsspace(str[j]) && j >= 0)
		str[j--] = '\0';
	return str;
}

#ifdef __TccMac__
TccShutUp(KTccNullString8);
TccShutUp(KTccNullString16);

#if defined (__OBJC__)
#import <Foundation/Foundation.h>
@interface NSString (Tcc)
+ (NSString*) fromTccStr8 : (const TccDesC8&) str8;
+ (NSString*) fromTccStr16 : (const TccDesC16&) str16;
- (TccPtrC8) toTccStr8;
- (BOOL) getTccStr8 : (TccStr8&) str8;
- (BOOL) getTccStr16 : (TccStr16&) str16;
@end

@interface NSData (Tcc)
+ (NSData*) FromTccStr8 : (const TccDesC8&) str8;
- (TccPtrC8) toTccStr8;
- (BOOL) getTccStr8 : (TccStr8&) str8;
@end

#endif
#endif //__TccMac__





#endif //__TCC_STRING_H_DEFINE__



//
//  URLHandler.m
//  weapps
//
//  Created by tommywwang on 2020/6/22.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "URLHandler.h"

@implementation URLHandler

- (NSURL *)URLByPath:(NSString *)path
{
    return nil;
}

- (BOOL)handleRequest:(NSURLRequest *)request
{
    return NO;
}

@end

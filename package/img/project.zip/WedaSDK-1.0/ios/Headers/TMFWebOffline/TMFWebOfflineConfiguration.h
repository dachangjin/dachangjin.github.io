//
//  TMFWebOfflineConfiguration.h
//  TMFWebOffline
//
//  Created by hauzhong on 2019/9/5.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFWebOfflineUtilities.h"

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 离线包收到更新通知后的处理策略
 @note 配置了推送处理策略后，离线包的检查更新将由SDK处理，`TMFWebOfflineServiceShouldUpdateNotification` 通知将不再广播!!!
 */
typedef NS_ENUM(NSInteger, TMFWebOfflinePushHandlePolicy) {
    TMFWebOfflinePushHandlePolicyNone = 0,              ///< 收到推送后不更新，表示SDK不处理推送，同时将推送广播
    TMFWebOfflinePushHandlePolicyWiFiOnly = 1,          ///< 收到推送后仅在WiFi下更新
    TMFWebOfflinePushHandlePolicyWiFiAndCellular = 2,   ///< 收到推送后任意网络下更新
};

/**
 @brief 离线包个性化配置策略
 */
@interface TMFWebOfflineConfiguration : NSObject <NSCopying>

/**
 @brief 获取默认配置的实例对象
 
 @return 配置实例对象
 */
+ (TMFWebOfflineConfiguration *)configuration;

/**
 @brief 收到更新通知的处理策略，默认是 `TMFWebOfflinePushHandlePolicyNone`
 */
@property (nonatomic, assign) TMFWebOfflinePushHandlePolicy pushHandlePolicy;

/**
 @brief 下载请求的缓存策略，默认 `NSURLRequestUseProtocolCachePolicy`
 */
@property (nonatomic, assign) NSURLRequestCachePolicy requestCachePolicy;

/**
 @brief 下载请求的超时时间，默认30s
 */
@property (nonatomic, assign) NSTimeInterval timeoutIntervalForRequest;

/**
 @brief 是否允许通过蜂窝网络进行文件下载，默认允许(YES)
 @note 如果不需要SDK自行处理网络变化，建议保持默认设置
 */
@property (nonatomic, assign) BOOL allowsCellularAccess;

@end

NS_ASSUME_NONNULL_END

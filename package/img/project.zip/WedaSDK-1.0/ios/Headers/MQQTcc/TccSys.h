/**
* @brief TccSys tcc��������Ķ���,����ƽ̨���Զ�ʶ����,�����������Ͷ���,����CRT����������/����
* @author smartluo@tencent.com
* @date 2009-03-12
* @version 0.1
*/

#ifndef __TCC_SYS_H_DEFINE__
#define __TCC_SYS_H_DEFINE__

#include "TccConfig.h"
#include "TccSys.inl.h"

#if defined(__TccWindows__)
#pragma warning(disable:4996)
#pragma warning(disable:4127)
#pragma warning(disable:4201)
#pragma warning(disable:4819)
#endif

#if defined(__TccSymbian__)
#if !defined(__TccSymbianKernel__)
#include <e32std.h>
#include <e32math.h>
#else
#include <nkern.h>
#include <kernel.h>
#include <kern_priv.h>
#include <e32cmn.h>
#include <u32std.h>
#endif
#endif

#if defined(EKA2) || defined(__TccWindows__) || defined(__TccAndroidNDK__)
#define __TccHasU64Type__
#endif

/*
------------------------------------------------
Data Type	LP32	ILP32	ILP64	LLP64	LP64
char		8		8		8		8		8
short		16		16		16		16		16
int			16		32		64		32		32
long		32		32		64		32		64
long long							64 	 
pointer		32		32		64		64		64
------------------------------------------------
* Standard programming model for current (Intel family) PC processors is ILP32.
* One issue with long in C was that there are both code bases that expect pointer and long to have the same size, while there are also large code bases that expect int and long to be the same size. The compatibility model LLP64 was designed to preserve long and int compatibility by introducing a new type to remain compatible with pointer (long long)
* LLP64 is the only data model that defines a size for the long long type.
* LP32 is used as model for the win-16 APIs of Windows 3.1.
* Most Unix versions use LP64, primarily to conserve memory space compared to ILP64, including: 64-bit Linux, FreeBSD, NetBSD, and OpenBSD.
* Win64 uses the LLP64 model (also known as P64). This model conserves type compatibility between long and int, but loses type compatibility between long and pointer types. Any cast between a pointer and an existing type requires modification.
* ILP64 is the easiest model to work with, because it retains compatibility with the ubiquitous ILP32 model, except specific assumptions that the core types are 32-bit. However this model requires significant memory, and both code and data size significantly increase.
*/
//----------------------------------------------------------------

//__TccSystemLP32__
//__TccSystemILP64__
#if defined(_WIN64) || defined (__LP64__) || defined (__64BIT__) || defined (_LP64) || (__WORDSIZE == 64)
	#define __TccSystem64Bits__ //64
	#if defined(_WIN64)
		#define __TccSystemLLP64__
	#else
		#define __TccSystemLP64__
	#endif
#else
	#define __TccSystemILP32__
#endif



//----------------------------------------------------------------
//int ������λ
#define __TccSystemIntegalMaxBits__		64


//----------------------------------------------------------------
//�Ƿ�֧�ָ�����,��������ص�option
#if !defined(__TccBrew__) && !defined(__TccSymbianKernel__)
#define __TccSystemSupportFloat__
#endif


//----------------------------------------------------------------
//��Сͷʶ��
// BB_BIG_ENDIAN
// BB_LITTLE_ENDIAN 
#define __TccSystemLittleEndian__
//#define __TccSystemBigEndian__


//----------------------------------------------------------------
//wchar_t����
//windows/androidϵ��utf16
//symbianϵ��ucs2
//linux,mac�Ļ���GCC����ucs4��
//mtk��ǿ��ucs2,���ֽ�,������������,�������滹��Сͷ
//arena�ͱȽ��鷳,���0x80��ͷ,���������������Ĵ�ͷ��ucs2,������acsii...

#define __TccCrtFunHaveNotWcsAdv__

#if !defined(__TccWindows__) && !defined(__TccSymbian__)
#if !defined(__FIXWCHART__)
#if defined(__TccMac__)
//һ���ǵ���xcode�������µı����,__SIZEOF_WCHAR_T__��xcode����Ч...��...
#error Set OTHER_CFLAGS = "-fshort-wchar -D__FIXWCHART__" and OTHER_CPLUSPLUSFLAGS = "-fshort-wchar -D__FIXWCHART__"
#else
#error used "-fshort-wchar" option
#endif
#endif
#endif

#if defined(__TccBrew__)
#error todo...
#endif

#if defined(__TccPosix__)
#define __TccSystemUTF32__
#elif defined(__TccMtk__)
#define __TccSystemAbnormalUcs2__
#else
#define __TccSystemUTF16__
#define __TccSystemUCS2__
#endif

//----------------------------------------------------------------

#if !defined(__TccBrew__)
#if !defined(__TccSymbianTcbMode__) && !defined(__TccSymbianKernel__)
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#endif
#ifdef __TccAndroidNDK__
#include <wchar.h>
#include <stdint.h>
#endif
#else
#include "AEEStdLib.h" //brew
#endif

#if defined(__TccPosix__) || defined(__TccWindows__) || defined(__TccAndroidNDK__)
#include <wchar.h>
#endif


/*
typedef void TAny;
typedef signed char TInt8;
typedef unsigned char TUint8;
typedef short int TInt16;
typedef unsigned short int TUint16;
typedef long int TInt32;
typedef unsigned long int TUint32;
typedef signed int TInt;
typedef unsigned int TUint;
typedef float TReal32;
typedef double TReal64;
typedef double TReal;
typedef unsigned char TText8;
typedef unsigned short int TText16;
typedef int TBool;
*/

/*
_MSC_VER
1200 == VC++ 6.0
1201 == EVC  4.2
1300 == VC++ 7.0
1310 == VC++ 7.1
1400 == VC++ 8.0
1500 == VC++ 9.0
*/

#if defined(__TccWindows__) && defined(_MSC_VER)//_MSC_VER < 1400
typedef __int8					ti8;
typedef __int16					ti16;
typedef __int32					ti32;
typedef __int64					ti64;

typedef unsigned __int8			tu8;
typedef unsigned __int16		tu16;
typedef unsigned __int32		tu32;
typedef unsigned __int64		tu64;

typedef float					tfloat;
typedef double					tdouble;

#include <BaseTsd.h>
//typedef UINT_PTR /*LONG_PTR*/	TccPtr;
#if defined (_WIN64)
typedef UINT_PTR				TccPtrT;
#else
typedef UINT_PTR				TccPtrT;
#endif

#elif defined(__TccSymbian__)
typedef TInt8					ti8;
typedef TInt16					ti16;
typedef TInt/*TInt32*/			ti32;
typedef TInt64					ti64;

typedef TUint8					tu8;
typedef TUint16					tu16;
typedef TUint32					tu32;
#ifdef EKA2
typedef TUint64					tu64;
#endif

typedef TReal32					tfloat;
typedef TReal64					tdouble;

typedef void*					TccPtr;
typedef tu32					TccPtrT;

#elif defined (__TccAndroidNDK__)

typedef int8_t					ti8;
typedef int16_t					ti16;
typedef int32_t					ti32;
typedef int64_t					ti64;

typedef uint8_t					tu8;
typedef uint16_t				tu16;
typedef uint32_t				tu32;
typedef uint64_t				tu64;

typedef float					tfloat;
typedef double					tdouble;

typedef void*					TccPtr;
typedef uintptr_t				TccPtrT;

#elif defined (__TccMeeGo__)
#include <qtcore\qglobal.h>
typedef qint8					ti8;
typedef qint16					ti16;
typedef qint32					ti32;
typedef qint64					ti64;
typedef quint8					tu8;
typedef quint16					tu16;
typedef quint32					tu32;
typedef quint64					tu64;
typedef float					tfloat;
typedef double					tdouble;
typedef void*					TccPtr;
typedef size_t  				TccPtrT;
#else

typedef signed char				ti8;
typedef short					ti16;
typedef int						ti32;
typedef long long				ti64;
typedef unsigned char			tu8;
typedef unsigned short int		tu16;
typedef unsigned int			tu32;

typedef float					tfloat;
typedef double					tdouble;

typedef void*					TccPtr;
typedef size_t					TccPtrT;

#endif

typedef int						tint;

//-----------------------------------------------------
#if defined(__TccSymbian__)
typedef TBool					tbool;
#define ttrue					ETrue
#define tfalse					EFalse
#else
typedef bool					tbool;
#define ttrue					true
#define tfalse					false
#endif

//-----------------------------------------------------
typedef tu8						tbyte;


#if defined(__TccSymbian__)
//#include <sys\unistd.h>
#ifndef __wchar_t_defined
#ifndef __GCCXML__
typedef unsigned short int wchar_t;
#endif
#endif
#endif

typedef wchar_t					twchar;
//typedef unsigned short int twchar;
typedef char					tchar;

#define _TW(x)					(twchar*)(L ## x)
#define _TA(x)					(tu8*)x


//------------------------------------------------------------------


#ifndef NULL
#define NULL					0
#endif //NULL

//------------------------------------------------------------------
//λ����
#define _TccAlignDown(x, a)	((x)&(~((a)-1)))
#define _TccAlign(x, a)		(((x)+(a)-1)&(~((a)-1)))
#define _TccAlign32(x)		(((x)+3)&(~(3)))
#define _TccAlign16(x)		(((x)+1)&(~(1)))

/*
#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))
#define _ALIGN_DOWN(x,a) ((x)&(~((a)-1)))
*/

#ifdef __TCC_ENABLE_BUILD_DL__

#if defined(__TccWindows__)
#define TCCIMPORT	__declspec(dllimport)
#define TCCEXPORT	__declspec(dllexport)
#elif defined(__TccBrew__)
#define TCCIMPORT
#define TCCEXPORT
#elif defined(__TccMtk__)
#define TCCIMPORT
#define TCCEXPORT
#elif defined(__TccAndroidNDK__)
#define TCCIMPORT
#define TCCEXPORT
#elif __TccMeeGo__
#define TCCIMPORT
#define TCCEXPORT
#elif defined(__TccSymbian__)
#define TCCIMPORT IMPORT_C
#define TCCEXPORT EXPORT_C
#else
#define TCCIMPORT
#define TCCEXPORT
#endif

#else	// __TCC_ENABLE_BUILD_DL__ is not defined
#define TCCIMPORT
#define TCCEXPORT
#endif


//------------------------------------------------------------------
#ifdef  __cplusplus
extern "C" {
#endif

//----------------------------------------------------------------
//malloc
#if defined(__TccBrew__)
#define TccMalloc(_Size)							MALLOC(_Size)
#define TccFree(_Memory)							FREE(_Memory)
#define TccRealloc(_Memory, _NewSize)				REALLOC(_Memory, _NewSize)
#define TccMemset(_Dst, _Val, _Size)				MEMSET((void *)_Dst, _Val, _Size)
#define TccMemcpy(_Dst, _Src, _Size)				MEMCPY(_Dst, _Src, _Size)
#define TccMemcmp(_Buf1, _Buf2, _Size)				MEMCMP(_Buf1, _Buf2, _Size)
	
#elif (__TccMtk__)
extern void* TccMalloc(ti32 _Size);
extern void TccFree(void* _Memory);
extern void TccMemset(void* _Dst, ti32 _Val, ti32 _Size);
extern void TccMemcpy(void* _Dst, const void* _Src, ti32 _Size);
extern ti32 TccMemcmp(CONST void* _Buf1, const void* _Buf2, ti32 _Size);
#define __StApi_HasNotRealloc__

#elif defined(__TccWin32_Debug__)
#include <crtdbg.h>
#define _CRTDBG_MAP_ALLOC
#define TccMalloc(_Size)							_malloc_dbg(_Size, _NORMAL_BLOCK, __FILE__, __LINE__)
#define TccFree(_Memory)							_free_dbg(_Memory, _NORMAL_BLOCK)
#define TccRealloc(_Memory, _NewSize)				_realloc_dbg(_Memory, _NewSize, _NORMAL_BLOCK, __FILE__, __LINE__)
#define TccMemset(_Dst, _Val, _Size)				memset(_Dst, _Val, _Size)
#define TccMemcpy(_Dst, _Src, _Size)				memcpy(_Dst, _Src, _Size)
#define TccMemmove(_Dst, _Src, _MaxCount)			memmove(_Dst, _Src, _MaxCount)
#define TccMemcmp(_Buf1, _Buf2, _Size)				memcmp(_Buf1, _Buf2, _Size)
#define DEBUG_CLIENTBLOCK   						new( _CLIENT_BLOCK, __FILE__, __LINE__)

#elif defined(__TccSymbian__)
#if !defined(__TccSymbianKernel__)
#ifdef __TCCDEBUG__
#define DEBUG_CHECK_MEMORY() User::Check()
#else // !__TCCDEBUG__
#define DEBUG_CHECK_MEMORY()
#endif
inline void* TccMalloc(ti32 _Size)	{	return User::Alloc(_Size);	}
inline void  TccFree(void* _Memory)	{ 	User::Free(_Memory); }
inline void* TccRealloc(void* _Memory, ti32 _NewSize) { return User::ReAlloc(_Memory, _NewSize); }
//inline void* TccMemset(void* _Dst, ti32 _Val, ti32 _Size) 		{ Mem::Fill(_Dst, _Size, TChar(_Val) ); DEBUG_CHECK_MEMORY(); return _Dst; }
//inline void* TccMemcpy(void* _Dst, const void* _Src, ti32 _Size){ Mem::Copy(_Dst, _Src, (TInt)_Size);   DEBUG_CHECK_MEMORY(); return _Dst; }
//inline void* TccMemmove(void* _Dst, const void* _Src, ti32 _Size){ memmove(_Dst, _Src, (TInt)_Size);   DEBUG_CHECK_MEMORY(); return _Dst; }	// NOTE: note Mem:Move
inline ti32  TccMemcmp(const void* _Buf1, const void* _Buf2, ti32 _Size)	{	return Mem::Compare((const TUint8 *)_Buf1, _Size, (const TUint8 *)_Buf2, _Size);	}

inline void* TccMemset(void* _Dst, ti32 _Val, ti32 _Size) { return memset(_Dst, _Val, _Size); }
inline void* TccMemcpy(void* _Dst, const void* _Src, ti32 _Size){ return memcpy(_Dst, _Src, _Size);}
inline void* TccMemmove(void* _Dst, const void* _Src, ti32 _Size){ return memmove(_Dst, _Src, _Size);}	// NOTE: note Mem:Move

#endif
#else // Unknown OS
#define TccMalloc(_Size)							malloc(_Size)
#define TccFree(_Memory)							free(_Memory)
#define TccRealloc(_Memory, _NewSize)				realloc(_Memory, _NewSize)
#define TccMemset(_Dst, _Val, _Size)				memset(_Dst, _Val, _Size)
#define TccMemcpy(_Dst, _Src, _Size)				memcpy(_Dst, _Src, _Size)
#define TccMemmove(_Dst, _Src, _MaxCount)			memmove(_Dst, _Src, _MaxCount)
#define TccMemcmp(_Buf1, _Buf2, _Size)				memcmp(_Buf1, _Buf2, _Size)

#endif


//----------------------------------------------------------------
//�ļ�ϵͳ
/*
SEEK_CUR //Current position of file pointer 
SEEK_END //End of file 
SEEK_SET //Beginning of file 
*/
#if 0
typedef FILE* tcc_file;
#define TccFopen(_Filename, _Mode)					fopen((const char*) _Filename, _Mode);
#define TccFread(_Dst, _EleSize, _Count, _File)		(ti32)fread((void *)_Dst, _EleSize, _Count, _File)
#define TccFwrite(_Src, _EleSize, _Count, _File)	(ti32)fwrite((void *)_Src, _EleSize, _Count, _File)
#define TccFseek(_File, _Offset, _Origin)			fseek(_File, _Offset, _Origin)
#define TccFtell(_File)								ftell(_File)
#define TccFclose									fclose
#if defined(__TccWindows__)
#define TccFwopen(_Filename, _Mode)					_wfopen((const wchar_t*) _Filename, _Mode)
#define TccFwRename(oldname, newname)				_wrename((const wchar_t*)(oldname), (const wchar_t*)(newname))
#define TccFwRemove(path)							_wremove((const wchar_t*)(path))
#else
#define TccFwopen(_Filename, _Mode)					wfopen((const wchar_t*) _Filename, _Mode)
#define TccFwRename(oldname, newname)				wrename((const wchar_t*)(oldname), (const wchar_t*)(newname))
#define TccFwRemove(path)							wunlink((const wchar_t*)(path))
#endif
#endif

//-------------------------------------------------------
/*
#if defined(__TccSymbian__)
inline ti32 TccStrlen(const void* _Str)						{	return TPtrC8((const TUint8*)_Str).Length(); }	
#else
#define TccStrlen(_Str)							(ti32)strlen((const char*)_Str)
#endif
#define TccStrcpy(_Dest, _Source)				strcpy((char*)_Dest, (const char*)_Source)
#define TccStrncpy(_Dest, _Source, _Count)		strncpy((char*)_Dest, (const char*)_Source, _Count)
#define TccStrcat(_Dest, _Source)				strcat((char *)_Dest, (const char *)_Source)
#define TccStrcmp(_Str1, _Str2)					strcmp((const char *)_Str1, (const char *)_Str2)
#define TccStrncmp(_Str1, _Str2, _MaxCount)		strncmp((const char *)_Str1, (const char *)_Str2, _MaxCount)
#define TccStrstr(_Str, _SubStr)				strstr((const char *) _Str, (const char *) _SubStr)
#if defined(__TccWindows__)
#define TccStricmp(_Str1, _Str2)				_stricmp((const char *)_Str1, (const char *)_Str2)
#define TccStrnicmp(_Str1, _Str2, _MaxCount)	_strnicmp((const char *)_Str1, (const char *)_Str2, _MaxCount)
//#define TccStrdup(_Src)							_strdup((const char*)_Src)
#else
#define TccStricmp(_Str1, _Str2)				strcasecmp((const char *)_Str1, (const char *)_Str2)
#define TccStrnicmp(_Str1, _Str2, _MaxCount)	strncasecmp((const char *)_Str1, (const char *)_Str2, _MaxCount)
//#define TccStrdup(_Src)							strdup((const char*)_Src)
#endif
*/


TCCIMPORT ti32 _TccStrlen(const char* _Str);
TCCIMPORT ti32 _TccStrcmp(const char* _Str1, const char* _Str2);
TCCIMPORT char* _TccStrcpy(char* _Dest, const char* _Source);
TCCIMPORT char* _TccStrncpy(char* _Dest, const char* _Source, int aLen);
TCCIMPORT ti32 _TccStrncmp(const char* _Str1, const char* _Str2, ti32 _MaxCount);
TCCIMPORT ti32 _TccStricmp(const char* _Str1, const char* _Str2);
TCCIMPORT ti32 _TccStrnicmp(const char* _Str1, const char* _Str2, ti32 _MaxCount);
TCCIMPORT const char* _TccStrstr(const char* _Str, const char* _SubStr);


#define TccStrlen(_Str)							_TccStrlen((const char*)_Str)
#define TccStrcmp(_Str1, _Str2)					_TccStrcmp((const char *)_Str1, (const char *)_Str2)
#define TccStrcpy(_Dest, _Source)				_TccStrcpy((char*)_Dest, (const char*)_Source)
#define TccStrncpy(_Dest, _Source, _Count)		_TccStrncpy((char*)_Dest, (const char*)_Source, _Count)
#define TccStrncmp(_Str1, _Str2, _MaxCount)		_TccStrncmp((const char *)_Str1, (const char *)_Str2, _MaxCount)
#define TccStrstr(_Str, _SubStr)				_TccStrstr((const char *) _Str, (const char *) _SubStr)
#define TccStricmp(_Str1, _Str2)				_TccStricmp((const char *)_Str1, (const char *)_Str2)
#define TccStrnicmp(_Str1, _Str2, _MaxCount)	_TccStrnicmp((const char *)_Str1, (const char *)_Str2, _MaxCount)

//-------------------------------------------------------

TCCIMPORT ti32 TccWcslen(const twchar* _Str);
TCCIMPORT twchar* TccWcscpy(twchar* _Dest, const twchar* _Source);
TCCIMPORT twchar* TccWcscat(twchar* _Dest, const twchar* _Source);
//twchar* TccWcsdup(const twchar* _Source);
TCCIMPORT ti32 TccWcscmp(const twchar* _Str1, const twchar* _Str2);
TCCIMPORT ti32 TccWcsncmp(const twchar* _Str1, const twchar* _Str2, ti32 _MaxCount);
TCCIMPORT ti32 TccWcsicmp(const twchar* _Str1, const twchar* _Str2);
TCCIMPORT ti32 TccWcsnicmp(const twchar* _Str1, const twchar* _Str2, ti32 _MaxCount);
TCCIMPORT const twchar* TccWcsstr(const twchar* _Str, const twchar* _SubStr);


//-------------------------------------------------------------------
//isspace((int)_C)
//09 0a 0b 0c 0d 20 "\t\n\r\f\v "
#if defined(__TccSymbian__)
inline tbool TccIsspace(ti32 _c){ return ((0x09 <= _c && _c <= 0x0d) || _c == 0x20 || _c == 0x2029);}
#else
inline tbool TccIsspace(ti32 _c){ return ((0x09 <= _c && _c <= 0x0d) || _c == 0x20);}
#endif
inline tbool TccIsdigit(ti32 _c){ return (0x30 <= _c && _c <= 0x39);}
inline tbool TccIsalpha(ti32 _c){ return (('a' <= _c && _c <= 'z') || ('A' <= _c && _c <= 'Z'));}
inline tbool TccIshex(ti32 _c){ return ((0x30 <= _c && _c <= 0x39) || ('a' <= _c && _c <= 'f') || ('A' <= _c && _c <= 'F'));}
#define TccIsxdigit(chr)   TccIshex(chr)

inline int TccHexChartoUi(ti32 c){return (TccIsdigit(c) ? (c - '0') : ((c) & ~('a' - 'A')) - 'A' + 10);}


//-------------------------------------------------------
//math
/* Definitions of useful mathematical constants*/

#if !defined(__TccSymbianKernel__)
#define _TccMathE					2.71828182845904523536	// e
#define _TccMathPi					3.14159265358979323846	// pi
#define _TccMathLog2E				1.44269504088896340736	// log2(e)
#define _TccMathLgE					0.434294481903251827651	// log10(e)
#define _TccMathLn2					0.693147180559945309417	// ln(2)
#define _TccMathLn10				2.30258509299404568402	// ln(10)

#define _TccMathPi_2				1.57079632679489661923	// pi/2
#define _TccMathPi_4				0.785398163397448309616	// pi/4
#define _TccMath1_PI				0.318309886183790671538	// 1/pi
#define _TccMath2_PI				0.636619772367581343076	// 2/pi
#define _TccMath2_SQRTPI			1.12837916709551257390	// 2/sqrt(pi)
#define _TccMathSQRT2				1.41421356237309504880	// sqrt(2)
#define _TccMathSQRT1_2				0.707106781186547524401	// 1/sqrt(2)

#define TccMathAtan(lf)				atan((double)lf)
#define TccMathCos(lf)				cos((double)lf)
#define TccMathSin(lf)				sin((double)lf)
#define TccMathTan(lf)				tan((double)lf)
#define TccMathTanh(lf)				tanh((double)lf)
#define TccMathFrexp(lf, p)			frexp((double)lf, (int*)p)
#define TccMathCeil(lf)				ceil((double)lf)
#define TccMathFabs(lf)				fabs((double)lf)
#define TccMathFloor(lf)			floor((double)lf)

#if defined(__TccSymbian__)
inline double TccMathModf(double lf, double* plf){
	TReal aTrg;
	if (Math::Mod(aTrg, lf, *plf) != KErrNone){
		TRealX aTrgX;
		aTrgX.SetNaN();
		aTrg = aTrgX;
	}
	return aTrg;
}
#else
#define TccMathModf(lf, plf)		modf((double)lf, (double*)plf)
#endif
#endif


inline ti32 TccRand(ti32& aRandSeed){
	return (((aRandSeed = aRandSeed * 214013L + 2531011L) >> 16) & 0x7fff);
}

inline tu32 TccAtoUi(const tu8* str, ti32 len, tu8 radix){
	ti32 i;
	tu32 t = 0;
	tu32 re = 0;
	for(i = 0; i < len; i++){
		t = TccHexChartoUi(str[i]);
		if(t >= radix || t < 0) break;
		re = radix * re + t;
	}
	return re;
}

inline tu32 _TccStdXToA(unsigned long v, char *string, ti32 r, ti32 is_neg)
{
	tu32 len = 0;
//	char *start = string;
	char buf[33],*p;

	p = buf;

	do {
		*p++ = "0123456789abcdef"[(v % r) & 0xf];
	} while (v /= r);

	if (is_neg) {
		*p++ = '-';
	}

	do {
		*string++ = *--p;
		len++;
	} while (buf != p);

	*string = '\0';

	return len;
}

// ���س���
inline tu32 TccItoA( ti32 v, char* str, ti32 r )
{
	tu32 len = 0;

	if ((r == 10) && (v < 0)) {
		len = _TccStdXToA((unsigned long)(-v), str, r, 1);
	} else {
		len = _TccStdXToA((unsigned long)(v), str, r, 0);
	}

	return len;
}

inline tu32 TccMeasureIntLen( ti32 v, ti32 r )
{
	char bytes[33] = {0};

	return TccItoA(v, bytes, r);
}


//-----------------------------------------------
//debug fun
#if defined(__TccWin32_Debug__)
#define TccAssert(_e)							_ASSERT(_e)
#elif defined(__TccSymbian__) 
#if defined(_DEBUG) && !defined(__TccSymbianKernel__)
//#define TccAssert(_e)							__ASSERT_DEBUG(_e, User::Panic(_L("ASSERT"), 0))

#define __TCC_ASSERT_FILE__(s) _LIT(KPanicFileName,s)
#define __TCC_ASSERT_PANIC__(l) User::Panic(KPanicFileName().Right(12),l)
//#define TccAssert(x) { __TCC_ASSERT_FILE__(__FILE__); __ASSERT_ALWAYS(x, __TCC_ASSERT_PANIC__(__LINE__) ); }
#define TccAssert(x) { __TCC_ASSERT_FILE__(__FILE__); __ASSERT_DEBUG(x, __TCC_ASSERT_PANIC__(__LINE__) ); }
#else
#define TccAssert(x)
#endif


#elif defined(__TccPosix__)
#include <assert.h>
#define TccAssert(_e)							assert(_e)
#else
#define TccAssert(_e)							{}
#endif

#ifdef __TccMac__
#define TccShutUp(variable)				\
inline void shutup_##variable(void) {	\
	(void)variable;						\
}
#else
#define TccShutUp(variable) //NOTHING
#endif
	
	
#ifdef  __cplusplus
}
#endif


#endif //__TCC_SYS_H_DEFINE__


//
//  MQQHttpRequest+Private.h
//  MQQSecure
//
//  Created by klaudz on 25/7/2016.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import "MQQHttpRequest.h"
#import "MQQHttpRequestDefines.h"
#import "MQQHttpRequestQueue.h"
#import "MQQURLSession+Private.h"

#import "MQQDispatch.h"

@interface MQQHttpRequest () {
    BOOL _isCompleted;
    BOOL _isCancelled;
    NSLock *_stateLock; // for locking the varibles of states
    
    NSInteger _retryCount;
    BOOL _addedRetryCount; // 是否已经因为特殊原因而增加重试机会
    unsigned long long _resumeOffsetForFileDownload;
}

+ (MQQHttpRequestQueue *)defaultRequestQueue;

@property(nonatomic,assign) NSUInteger           ID;
// connection
@property(nonatomic,retain) NSURL               *url;
@property(nonatomic,retain) NSMutableData       *tempData;
@property(nonatomic,retain) NSMutableURLRequest *request;
// Dictionary for custom HTTP request headers
@property(nonatomic,retain) NSMutableDictionary *requestHeaders;
// file handle for downloading
@property(nonatomic,readonly) BOOL               isDownloadRequest;
@property(nonatomic,retain) NSFileHandle        *downloadFileHandle;

- (void)requestWillStart;
- (void)requestDidStart;
- (void)requestDidFinish;
- (void)requestDidFailWithError:(NSError *)error shouldRetry:(BOOL)shouldRetry;
- (void)requestDidStop; // Finished + Failed + Cancelled
- (NSURLRequest *)requestWillPerformRedirection:(NSURLResponse *)response newRequest:(NSURLRequest *)request;

- (void)notifyDelegate:(BOOL)finished; // 回调函数，通知delegate/blocks

@end


@interface MQQHttpRequest (/* NSURLConnection */)

@property(nonatomic,retain) NSURLConnection     *urlConnection;

@end


@interface MQQHttpRequest (/* NSURLSession */)

@property(nonatomic,assign) MQQURLSession *session;
@property(nonatomic,retain) NSURLSession *urlSession;
@property(nonatomic,retain) NSURLSessionTask *sessionTask;

@end

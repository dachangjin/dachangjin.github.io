#ifndef __TCC_VECTOR_H_DEFINE__
#define __TCC_VECTOR_H_DEFINE__

#include "TccBase.h"
#include "TccContainerBase.inl.h"

template<typename T>
void TccQuickSort(T * base, ti32 num, ti32(*comp)(const T&, const T&));
template<typename T, typename _Context>
void TccQuickSortEx(T * base, ti32 num, const _Context& context, ti32(*comp)(const _Context&, const T&, const T&));

template<typename KeyT, typename T>
ti32 TccBinarySearch(const KeyT& key, const T* base, ti32 num, ti32(*comp)(const KeyT&, const T&));
template<typename KeyT, typename T, typename _Context>
ti32 TccBinarySearchEx(const KeyT& key, const T* base, ti32 num, const _Context& context, ti32(*comp)(const _Context&, const KeyT&, const T&));

#include "TccQuickSort.inl.h"
#define __QuickSortUseContext__
#include "TccQuickSort.inl.h"



#define _TccVectorIncreaseSize 16

template <typename T, typename _traits = TccTraits<T> >
class TccVector {
public:
	TccVector();
	~TccVector();

protected:

	T* iData;
	ti32 iSize;
	ti32 iLen;
	
public:

	class Iterator{
		friend class TccVector;
	protected:
		ti32 iMaxNum;
		ti32 iPos;
		T* iData;		
		Iterator(ti32 aNum, ti32 aPos, T* aData) : iMaxNum(aNum), iPos(aPos), iData(aData){ }
		inline void Set(ti32 aNum, ti32 aPos, T* aData){
			iMaxNum = aNum;
			iPos = aPos;
			iData = aData;
		}
	public:
		Iterator() : iMaxNum(0), iPos(0), iData(NULL){}
		~Iterator(){}

		Iterator(const Iterator& it){
			*this = it;
		}

		Iterator& operator=(const Iterator& it){
			Set(it.iMaxNum, it.iPos, it.iData);
			return *this;
		}

		const T& operator*() const {
			TccAssert(NULL != iData);
			return iData[iPos];
		}

		const T* operator->() const {
			TccAssert(NULL != iData);
			return &(iData[iPos]);
		}

		T& operator*(){
			TccAssert(NULL != iData);
			return iData[iPos];
		}

		T* operator->(){
			TccAssert(NULL != iData);
			return &(iData[iPos]);
		}

		Iterator& operator++(){ //++xx
			TccAssert(iPos < iMaxNum);
			iPos++;
			return *this;
		}

		Iterator operator++(ti32){ //xx++
			Iterator it = *this;
			++(*this);
			return it;
		}
		Iterator& operator--(){ //--xx
			TccAssert(iPos > 0);
			iPos--;
			return *this;
		}

		Iterator operator--(ti32){
			Iterator it = *this;
			--(*this);
			return it;
		}

		tbool operator!=(const Iterator& it){
			return (tbool)(iPos != it.iPos);
		}
		
		tbool isEnd(){return (tbool)(iPos >= iMaxNum);}
	};


	inline T* Ptr() const;
	inline ti32 Size() const;
	inline void SetSize(ti32 aSize);
	inline ti32 MaxSize() const;


	terror Resize(ti32 asize);

	/// Add an element to the end of the vector. 
	inline void PushBackA(const T& element);
	inline terror PushBack(const T& element);
	terror PushBack(const T& element, ti32 aIncreaseSize);
	inline terror Insert(ti32 nIndex, const T& element);
	terror Insert(ti32 nIndex, const T& element, ti32 aIncreaseSize);
	

	terror Copy(const T* data, ti32 len);
	inline terror Copy(const TccVector<T, _traits>& aVector){return Copy(aVector.Ptr(), aVector.Size());}
	terror Append(const T* data, ti32 len);

	inline void Zero();

	///Tests if the vector container is empty.
	inline tbool Empty() const;

	///Erases the elements of the vector.
	void Clear();

	void Destroy();

	T& operator[](ti32 aIndex);
	const T& operator[](ti32 aIndex) const;

	inline T& At(ti32 aIndex);
	inline const T& At(ti32 aIndex) const;
	
	void Erase(const T& element);
	void EraseAndDestroy(const T& element);

	void Erase(Iterator& element);
	void EraseAndDestroy(Iterator& element);
	
	void Remove(ti32 aIndex);
	void RemoveAndDestroy(ti32 aIndex);
	
	void PopBack();
	void PopBackAndDestroy();


	void Swap(ti32 a, ti32 b);


	template<typename TT>
	void SortEx(){
		TccQuickSort(iData, iLen, TT::Compare);
	}
	
	template<typename _Context>
	void SortEx(const _Context& context, ti32(*comp)(const _Context&, const T&, const T&)){
		TccQuickSortEx(iData, iLen, context, comp);
	}

	template<typename TT , typename KeyT>
	void BSearchEx(const KeyT& key){
		return TccBinarySearch(key, iData, iLen, TT::Compare);
	}

	void Sort(); //qsort
	//ti32 BSearch(const T& element) const;//bsearch
	//ti32 Search(const T& element) const;
	
	template<typename KeyT>
	ti32 BSearch(const KeyT& key) const {
		ti32 lo = 0;
		ti32 hi = iLen - 1;
		ti32 mid = 0;
		ti32 half = 0;
		ti32 result = 0;
		ti32 num = iLen;
		while (lo <= hi){
			if ((half = num / 2) != 0){
				mid = lo + (num & 1 ? half : (half - 1));
				if ((result = _traits::Compare(key, iData[mid])) == 0){
					return (mid);
				}
				else if (result < 0){
					hi = mid - 1;
					num = num & 1 ? half : half - 1;
				}
				else{
					lo = mid + 1;
					num = half;
				}
			}
			else if (num){
				return (_traits::Compare(key, iData[lo]) ? -1 : lo);
			}
			else{
				break;
			}
		}
		return -1;
	}
	
	template<typename KeyT>
	ti32 Search(const KeyT& element) const {
		for(ti32 i = 0; i < iLen; i++){
			if(_traits::Compare(element, iData[i]) == 0){
				return i;
			}
		}
		return -1;
	}

	void MemorySwapAndDestroy(T* aPtr, ti32 aSize){
		Destroy();
		iData = aPtr;
		iSize = aSize;
		iLen = aSize;
	}


	///Returns a reference to the last element of the vector.
	T& Back();
	///Returns a reference to the first element in a vector.
	T& Front();

	inline Iterator Begin() const;
	inline Iterator End() const;
	inline void Begin(Iterator& it) const;
	inline void End(Iterator& it) const;

};





#include "TccVector.inl.h"


#endif //__TCC_VECTOR_H_DEFINE__



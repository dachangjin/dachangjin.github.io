//
//  TMFInstructionCenter.h
//  GTFreeWifi
//
//  Created by klaudz on 3/4/2018.
//  Modified by charmxiao on 19/4/2.
//  Copyright © 2018 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFInstructionDefines.h"
#import "TMFInstruction.h"
#import "TMFInstructionResult.h"

NS_ASSUME_NONNULL_BEGIN

#define TMFInstructionNotificationContainsID(__notification__, __instructionID__) ({                    \
    NSIndexSet *IDs = [__notification__.userInfo objectForKey:TMFInstructionCenterUpdatedIDsKey];   \
    ([IDs isKindOfClass:[NSIndexSet class]] && [IDs containsIndex:__instructionID__]);              \
})

@interface TMFInstructionCenter : NSObject

+ (instancetype)defaultCenter;
- (instancetype)init NS_UNAVAILABLE;

/**
 *  @brief  云指令存储路径
 *
 *  @return configPath 云指令存储路径
 */
@property (nonatomic, copy, readonly) NSString *configPath;

#pragma mark - Update

/**
 *  @brief 云指令更新
 */
- (void)checkForUpdates;
- (void)checkForUpdatesIfNeeded;

#pragma mark - Observe

typedef void (^TMFInstructionHandler)(TMFInstruction *instruction);

/**
 *  @brief  监听云指令 ID 的更新
 *
 *  @param  ID 需要监听的云指令 ID
 *  @param  handler 用于处理云指令更新的回调
 */
- (void)observeID:(TMFInstructionID)ID handler:(TMFInstructionHandler)handler;

#pragma mark - Report

/**
 *  @brief  云指令执行结果上报
 *
 *  @param  instructionResult 云指令结果内容
 *  @return 存入上报列表的结果
 */
- (BOOL)reportInstructionResult:(TMFInstructionResult *)instructionResult;

#pragma mark - Value

/**
 *  @brief  云指令内容
 *
 *  @param  ID 云指令 ID
 *  @return 云指令内容
 */
- (nullable NSString *)stringForID:(TMFInstructionID)ID;

- (NSInteger)integerForID:(TMFInstructionID)ID;
- (float)floatForID:(TMFInstructionID)ID;
- (double)doubleForID:(TMFInstructionID)ID;
- (BOOL)boolForID:(TMFInstructionID)ID;

- (nullable NSURL *)URLForID:(TMFInstructionID)ID;

#pragma mark - Log

/**
 *  设置云指令组件日志级别
 *
 *  @param  logLevels 日志级别 详见「TMFInstructionLogLevel」
 */
+ (void)setLogLevels:(TMFInstructionLogLevel)logLevels;

/**
 *  当前组件的日志级别
 *
 *  @return 日志级别
 */
+ (TMFInstructionLogLevel)logLevels;

@end

NS_ASSUME_NONNULL_END

#ifndef __TCC_CONV_H_DEFINE__
#define __TCC_CONV_H_DEFINE__

#include "TccSys.h"

TCCIMPORT ti32 TccUtf8Encode(tu8* buf, tu32 ucs);
TCCIMPORT ti32 TccUtf8Decode(const tu8* src, ti32 srclen, tu32* ucs);
TCCIMPORT ti32 TccUtf16Decode(const twchar* src, ti32 srclen, tu32* ucs);

TCCIMPORT ti32 TccUtf8ToUtf16(const tu8* src, ti32 srclen, twchar* dst, ti32 dstlen);
TCCIMPORT ti32 TccUtf16ToUtf8(const twchar* src, ti32 srclen, tu8* dst, ti32 dstlen);

#if !defined(__TccSymbianTcbMode__)
TCCIMPORT ti32 TccGbkToUcs(const tu8* src, ti32 srclen, twchar* dst, ti32 dstlen);
TCCIMPORT ti32 TccUcsToGbk(const twchar* src, ti32 srclen, tu8* dst, ti32 dstlen);
#endif

TCCIMPORT ti32 TccEncodeBase64(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen, ti32 aMaxlinelen);
TCCIMPORT ti32 TccDecodeBase64(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen);

TCCIMPORT ti32 TccEncodeQuotedPrintable(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen, ti32 aMaxlinelen);
TCCIMPORT ti32 TccDecodeQuotedPrintable(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen);

TCCIMPORT ti32 TccEncodeUrlString(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen);
TCCIMPORT ti32 TccDecodeUrlString(const tu8* src, ti32 srclen, tu8* dst, ti32 dstlen);


#endif //__TCC_CONV_H_DEFINE__


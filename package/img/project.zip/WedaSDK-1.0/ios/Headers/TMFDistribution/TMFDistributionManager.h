//
//  TMFDistributionManager.h
//  TMFDistribution
//
//  Created by bentonxiu on 2019/8/6.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFDistributionDefines.h"

NS_ASSUME_NONNULL_BEGIN


@class TMFDistributionInfo;

/**
 *  @brief  发布处理结果回调
 *
 *  @note   必须在 `TMFDistributionHandler` 结束时调用 完成闭环
 *  @param updated  是否采取更新操作 (eg. 打开 App Store 等)
 */
typedef void (^TMFDistributionCompletionBlock)(BOOL updated);

/**
 *  @brief  发布更新后的数据处理方法
 *
 *  @param info 本次发布更新的信息 包含 标题/特性描述/本次更新 Build 号/是否强制更新/提示周期/App Store 链接
 *  @param completionHandler 发布处理结果回调 必须在 handler 结束调用完成闭环
 */
typedef void (^TMFDistributionHandler)(TMFDistributionInfo * _Nullable info, TMFDistributionCompletionBlock completionHandler);

/**
 *  @brief  发布管理器
 *
 *  @note   用于监听发布更新等
 */
@interface TMFDistributionManager : NSObject

#pragma mark - Life Cycle

+ (instancetype)sharedManager;

/**
 *  @brief  使服务开始生效
 *
 *  @note   必须在云指令组件 `TMFInstructionCenter` 初始化之前调用
 */
- (void)initialize;

/**
 *  @brief  主动检测是否有发布更新
 *
 *  @note   如果有新的发布更新，则会进入 `-[TMFDistributionManager setDistributionWithHandler:]` 回调
 */
- (void)checkForUpdates __unavailable;

#pragma mark - Data

/**
 *  @brief  获取最近的更新信息
 *
 *  @note   如果没有最近更新信息 则为 nil
 */
@property (nonatomic, readonly, nullable) TMFDistributionInfo *distributionInfo;

#pragma mark - Handler

/**
 *  @brief  设置监听发布更新的回调
 *
 *  @note   当实现此方法 则会使用自定义 Handler 来处理发布更新
 *  @param handler 监听到发布更新后的处理
 *
 *  @note   下面是一个使用实例：
 *  @code
    [[TMFDistributionManager sharedManager] setDistributionHandler:^(TMFDistributionInfo * _Nullable info,
                                                                     TMFDistributionCompletionBlock  _Nonnull completionHandler) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:info.distributionTitle
                                                                                 message:info.featureDescription
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel
                                                                             handler:^(UIAlertAction * _Nonnull action) {
            completionHandler(NO); // cancel
        }];
        UIAlertAction *updateAction = [UIAlertAction actionWithTitle:@"Update" style:UIAlertActionStyleDefault
                                                                             handler:^(UIAlertAction * _Nonnull action) {
            completionHandler(YES); // update
        }];
        [alertController addAction:updateAction];
        if (!info.updatesForcibly) {
            [alertController addAction:cancelAction];
        }
        // present Alert
    }];
 *  @endcode
 */
- (void)setDistributionHandler:(TMFDistributionHandler)handler
    DEPRECATED_MSG_ATTRIBUTE("use -setDidReceiveDistributionHandler: instead");

/**
 *  @brief  设置监听发布更新的回调
 *
 *  @note   当实现此方法 则会使用自定义 Handler 来处理发布更新
 *  @param handler 监听到发布更新后的处理
 *
 *  @note   下面是一个使用实例：
 *  @code
    [[TMFDistributionManager sharedManager] setDidReceiveDistributionHandler:^(TMFDistributionInfo * _Nullable info,
        TMFDistributionCompletionBlock  _Nonnull completionHandler) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:info.distributionTitle
                                                                                 message:info.featureDescription
                                                                          preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel
                                                             handler:^(UIAlertAction * _Nonnull action) {
            completionHandler(NO); // cancel
        }];
        UIAlertAction *updateAction = [UIAlertAction actionWithTitle:@"Update" style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * _Nonnull action) {
            completionHandler(YES); // update
        }];
        [alertController addAction:updateAction];
        if (!info.updatesForcibly) {
            [alertController addAction:cancelAction];
        }
        // present Alert
    }];
 *  @endcode
 */
- (void)setDidReceiveDistributionHandler:(TMFDistributionHandler)handler;

#pragma mark - Log

/**
 *  @brief  发布组件日志级别
 *
 *  @note   release 模式下请设置 `TMFDistributionLogNone`
 */
@property (nonatomic, assign) TMFDistributionLogLevel logLevels
    DEPRECATED_MSG_ATTRIBUTE("use +logLevels: instead");

/**
 *  @brief  设置发布组件日志级别
 *
 *  @note   日志级别 详见「TMFDistributionLogLevel」
 */
@property (class, nonatomic, assign) TMFDistributionLogLevel logLevels;

@end

NS_ASSUME_NONNULL_END

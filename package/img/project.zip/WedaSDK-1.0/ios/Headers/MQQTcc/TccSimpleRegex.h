#ifndef __TCC_SIMPLE_REGEX_H_DEFINE__
#define __TCC_SIMPLE_REGEX_H_DEFINE__

#include "TccString.h"

//һ���򵥵��������ʽ
// A simple C++ wrapper for <regex.h>.  It uses the POSIX Extended Regular Expression syntax.

TCCIMPORT bool TccSimpleRegexValidate(const tu8* regex, ti32 regexlen);

inline bool TccSimpleRegexValidate(const tchar* regex){
	if (NULL == regex) {return false;}
	return TccSimpleRegexValidate((const tu8*)regex, TccStrlen(regex));
}
inline bool TccSimpleRegexValidate(const TccDesC8& regex){
	return TccSimpleRegexValidate(regex.Ptr(), regex.Length());
}

TCCIMPORT bool TccSimpleRegexFullMatch(const tu8* str, int len, const tu8* regex, int regexlen);
TCCIMPORT bool TccSimpleRegexPartialMatch(const tu8* str, int len, const tu8* regex, int regexlen);

inline bool TccSimpleRegexFullMatch(const tchar* str, const tchar* regex){
	return TccSimpleRegexFullMatch((const tu8*)str, TccStrlen(str), (const tu8*)regex, TccStrlen(regex));
}
inline bool TccSimpleRegexPartialMatch(const tchar* str, const tchar* regex){
	return TccSimpleRegexPartialMatch((const tu8*)str, TccStrlen(str), (const tu8*)regex, TccStrlen(regex));
}
inline bool TccSimpleRegexFullMatch(const TccDesC8& str, const TccDesC8& regex){
	return TccSimpleRegexFullMatch(str.Ptr(), str.Length(), regex.Ptr(), regex.Length());
}
inline bool TccSimpleRegexPartialMatch(const TccDesC8& str, const TccDesC8& regex){
	return TccSimpleRegexPartialMatch(str.Ptr(), str.Length(), regex.Ptr(), regex.Length());
}


TCCIMPORT bool TccSimpleRegexFullMatch(const twchar* str, int len, const tu8* regex, int regexlen);
TCCIMPORT bool TccSimpleRegexPartialMatch(const twchar* str, int len, const tu8* regex, int regexlen);

inline bool TccSimpleRegexFullMatch(const twchar* str, const tchar* regex){
	return TccSimpleRegexFullMatch(str, TccWcslen(str), (const tu8*)regex, TccStrlen(regex));
}
inline bool TccSimpleRegexPartialMatch(const twchar* str, const tchar* regex){
	return TccSimpleRegexPartialMatch(str, TccWcslen(str), (const tu8*)regex, TccStrlen(regex));
}
inline bool TccSimpleRegexFullMatch(const TccDesC16& str, const TccDesC8& regex){
	return TccSimpleRegexFullMatch(str.Ptr(), str.Length(), regex.Ptr(), regex.Length());
}
inline bool TccSimpleRegexPartialMatch(const TccDesC16& str, const TccDesC8& regex){
	return TccSimpleRegexPartialMatch(str.Ptr(), str.Length(), regex.Ptr(), regex.Length());
}


#endif //__TCC_SIMPLE_REGEX_H_DEFINE__


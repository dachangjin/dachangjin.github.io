//
//  AppDelegate.m
//  weapps
//
//  Created by tommywwang on 2020/5/28.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "WAAppDelegate.h"
//#import "WADebugInfo.h"
//#import "WADebugViewController.h"
//#import "WAWebViewController.h"
#import <WedaSDK/WAWebViewController.h>
#import <WedaSDK/Weapps.h>

#import "TMFConfigurations.h"
//#import "TMFSharkCenterConfiguration.h"
#import <WedaSDK/TMFSharkCenterConfiguration.h>
//#import "TMFSharkCenter.h"
#import <WedaSDK/TMFSharkCenter.h>
//#import "TMFInstructionCenter.h"
#import <WedaSDK/TMFInstructionCenter.h>
//#import "TMFWebOffline.h"
#import <WedaSDK/TMFWebOffline.h>
//#import "TMFDistribution.h"
#import <WedaSDK/TMFDistribution.h>
//#import "TMFProfile.h"
#import <WedaSDK/TMFProfile.h>
//#import "TMFPush.h"
#import <WedaSDK/TMFPush.h>
//#import "TMFStatistics.h"
//#import <WedaSDK/TMFStatistics.h>
#import "WAJSCustomTestHandler.h"
#import "CustomNavigationController.h"

#define kPrivicy NO

@interface WAAppDelegate () <TMFPushDelegate>

// 避免显示webView加载本地文件时显示白屏，使用跟applaunchImage同样视觉效果图来遮住webView
@property (nonatomic, strong) UIImageView *launchImageView;

@end

@implementation WAAppDelegate

- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    
    if (kPrivicy) {
        UIViewController *VC = [UIStoryboard storyboardWithName:@"LaunchScreen"
                                                         bundle:[NSBundle mainBundle]].instantiateInitialViewController;
        self.window.rootViewController = VC;
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"协议"
                                                                         message:@"是否同意隐私协议" preferredStyle:UIAlertControllerStyleAlert];
        [alertVC addAction:[UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction * _Nonnull action) {
            [self initApp];
        }]];
        [VC presentViewController:alertVC
                         animated:YES
                       completion:nil];
        
    } else {
        [self initApp];
    }
    
    return YES;
}

- (void)initApp
{
    [self prepareTMF];
    [self initWeapps];
    [self prepareWebViewController];
}

- (BOOL)application:(UIApplication *)app
            openURL:(NSURL *)url
            options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    Weapps *weapps = [Weapps sharedApps];
    if ([weapps respondsToSelector:@selector(application:openURL:options:)]) {
        return [weapps application:app
                           openURL:url
                           options:options];
    }
    return YES;
}

- (BOOL)application:(UIApplication *)application
continueUserActivity:(NSUserActivity *)userActivity
 restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
    Weapps *weapps = [Weapps sharedApps];
    if ([weapps respondsToSelector:@selector(application:continueUserActivity:restorationHandler:)]) {
        return [weapps application:application
              continueUserActivity:userActivity
                restorationHandler:restorationHandler];
    }
    return YES;
}

- (void)application:(UIApplication *)application
didReceiveRemoteNotification:(NSDictionary *)userInfo
fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler
{
    Weapps *weapps = [Weapps sharedApps];
    if ([weapps respondsToSelector:@selector(application:didReceiveRemoteNotification:fetchCompletionHandler:)]) {
        [weapps application:application
didReceiveRemoteNotification:userInfo
     fetchCompletionHandler:completionHandler];
    }
}

- (void)prepareWebViewController
{
    WAWebViewController *VC = [[WAWebViewController alloc] init];
    
    // 加载本地资源
//    NSBundle *h5 = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"H5" ofType:@"bundle"]];
//    NSString *path = [NSString stringWithFormat:@"%@/main/preview/back-service/index.html",[h5 bundlePath]];
//    VC.URL = [NSURL fileURLWithPath:path];
    
    // 加载远程资源
    NSString *path = @"https://cpcwefusion-gw.pdcts.com.cn/weapps_app/preview/gankuaiban/back-service/index.html";
    VC.URL = [NSURL URLWithString:path];
    CustomNavigationController *navVC = [[CustomNavigationController alloc] initWithRootViewController:VC];
    self.window.rootViewController = navVC;
    
    self.launchImageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.launchImageView.backgroundColor = [UIColor whiteColor];
    self.launchImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.launchImageView.image = [UIImage imageNamed:@"launchImage"];
    [self.window addSubview:self.launchImageView];
    // 保底2秒后移除launchImageView
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.5
                         animations:^{
            self.launchImageView.alpha = 0;
        } completion:^(BOOL finished) {
            [self.launchImageView removeFromSuperview];
        }];
    });
    __weak typeof(self) weakSelf = self;
    VC.finishLaunchBlock = ^{
        __strong typeof(self) self = weakSelf;
        [UIView animateWithDuration:0.5
                         animations:^{
            self.launchImageView.alpha = 0;
        } completion:^(BOOL finished) {
            [self.launchImageView removeFromSuperview];
        }];
    };
}

#pragma mark - init weapps
- (void)initWeapps
{
    WASDKConfig *config = [[WASDKConfig alloc] init];
    config.mapApiKey = @"6FSBZ-AT53D-M4O4S-PNK6D-YO2SH-FJB5Q";
//    config.buglyId = @"158afb0dc4";
    [[Weapps sharedApps] initWithConfig:config];
    [[Weapps sharedApps] registerCustomHandler:[[WAJSCustomTestHandler alloc] init]];
}

#pragma mark - TMF
#define TMFLOG  1
- (void)prepareTMF{
    [self initSharkCenter];
    [self prepareDistribution];
    [self prepareCloudInstructionAndChcekUpdate];
    [self preparePush];
    [self prepareWebOffline];
    [self prepareStatistics];
    
    [[TMFInstructionCenter defaultCenter] checkForUpdatesIfNeeded];
}

- (void)initSharkCenter
{
    /** 调试日志 **/
#if DEBUG && TMFLOG
    [TMFSharkCenterConfiguration setLogLevels:1];
#endif
    /** 初始化 Shark 的配置 **/
    TMFSharkCenterConfiguration *masterConfiguration = [TMFSharkCenterConfiguration masterConfiguration];
    
    masterConfiguration.productID       = TMF_PID;
    masterConfiguration.HTTPURL         = TMF_GW_HTTP_URL;
    
    masterConfiguration.productKey      = TMF_APP_KEY;
    masterConfiguration.RSAPublicKey    = TMF_GW_RKEY;
    masterConfiguration.SM2PublicKey    = TMF_GW_SKEY;
    
    masterConfiguration.customerID      = TMF_CUSTOM_ID;
    masterConfiguration.keychainAccessGroup = @"7Y79ESXG99.com.tencent.tmf.shared";

    [[TMFSharkCenter masterCenter] initialize];
    [[TMFSharkCenter masterCenter] fetchGUID:^(NSString * _Nullable GUID, NSError * _Nullable error) {
        NSLog(@"[Demo shark] TMF GUID: %@", GUID);
    }];
}

- (void)prepareCloudInstructionAndChcekUpdate {
    // 初始化云指令配置并检查更新
#if DEBUG && TMFLOG
    [TMFInstructionCenter setLogLevels:TMFInstructionLogLevelAll];
#endif
    [TMFInstructionCenter defaultCenter];
}

#pragma mark - TMFWebOffline
/// 离线包日志
//void loggerWebOffline(TMFWebOfflineLoggerLevel level, const char* log) {
//    if (level <= TMFWebOfflineLoggerLevelError) { NSLog(@"%s", log); }
//}

/// 离线包下载进度监听回调
//void downloadProgressHandler(NSString *Bid, NSProgress *progress){
//    NSLog(@"[TMFWebOffline Prog] download Bid:%@, progerss:%.2lf",Bid,progress.completedUnitCount *1.0 / progress.totalUnitCount);
//}
/// 空间不足警告
//- (void)webOfflineNoSpaceHandler{
////    NSLog(@"[⚠️][TMFWebOffline no space]");
//}

#define ENABLE_PUSH_HANDLER
- (void)prepareWebOffline {
#if DEBUG && TMFLOG
//    [TMFWebOfflineService registerLogger:loggerWebOffline];
#endif
//    [TMFWebOfflineService registerDownloadProgressHandler:downloadProgressHandler];

    NSString *publicKeyPath = [[NSBundle mainBundle] pathForResource:@"weboffline_public_key" ofType:@"pem"];
    NSString *publicKey = [NSString stringWithContentsOfFile:publicKeyPath encoding:NSUTF8StringEncoding error:nil];
    [TMFWebOfflineService setPublicKey:publicKey];
    
//    TMFWebOfflineConfiguration *configuration = [TMFWebOfflineConfiguration configuration];
//    configuration.pushHandlePolicy = TMFWebOfflinePushHandlePolicyWiFiAndCellular;
//    [TMFWebOfflineService activateWithConfiguration:configuration];
//    [TMFWebOfflineService pauseHandler];
    [TMFWebOfflineService uncompressPackagesIfNeeded];
//    [[NSNotificationCenter defaultCenter]  addObserver:self
//                                              selector:@selector(webOfflineNoSpaceHandler)
//                                                  name:(NSString *)TMFWebOfflineDownloadNoSpaceNotification object:nil];
    
    
    [TMFWebOfflineService checkAndUpdateAllAvailablePackagesWithCompletionHandler:^(NSArray<NSString *> * _Nonnull updatedBIDs) {
        if (updatedBIDs.count) {
            [TMFWebOfflineService uncompressPackagesIfNeeded];

        }
        NSLog(@"[Demo weboffline] update bids:%@", updatedBIDs);
        NSLog(@"[Demo weboffline] webOffline path:%@", [TMFWebOfflineService localPathForBID:@"webOfflineTest"]);
    }];
    
}

- (void)preparePush {
//#if DEBUG && TMFLOG
//    [TMFPush defaultManager].logEnabled = YES;
//#endif
//
//    [[TMFPush defaultManager] startPushWithDelegate:self];
//    NSLog(@"[Demo TMFPush] deviceToken: %@", [TMFPushTokenManager defaultTokenManager].deviceTokenString);
}

- (void)tmfPushDidRegisterDeviceToken:(NSString *)deviceToken error:(NSError *)error {
    NSLog(@"[Demo TMFPush] did register deviceToken: %@, error: %@", deviceToken, error);
}

// 点击notification，进入app时调用。
- (void)tmfPushUserNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(nullable UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler API_AVAILABLE(ios(10.0)) {
    
    Weapps *weapps = [Weapps sharedApps];
    if ([weapps respondsToSelector:@selector(userNotificationCenter:didReceiveNotificationResponse:withCompletionHandler:)]) {
        [weapps userNotificationCenter:center
        didReceiveNotificationResponse:response
                 withCompletionHandler:completionHandler];
    } else {
        completionHandler();
    }
}

- (void)prepareDistribution
{
#if DEBUG && TMFLOG
    [TMFDistributionManager setLogLevels:TMFDistributionLogLevelAll];
#endif
//    // 注册自定义 Handler
//    [[TMFDistributionManager sharedManager] setDidReceiveDistributionHandler:^(TMFDistributionInfo * _Nullable info,
//                                                                               TMFDistributionCompletionBlock  _Nonnull completionHandler) {
//        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:info.distributionTitle
//                                                                                 message:info.featureDescription
//                                                                          preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel
//                                                             handler:^(UIAlertAction * _Nonnull action) {
//                                                                 completionHandler(NO);
//                                                             }];
//        UIAlertAction *updateAction = [UIAlertAction actionWithTitle:@"更新" style:UIAlertActionStyleDefault
//                                                             handler:^(UIAlertAction * _Nonnull action) {
//                                                                 if ([[UIApplication sharedApplication] canOpenURL:info.appStoreURL]) {
//                                                                     [[UIApplication sharedApplication] openURL:info.appStoreURL];
//                                                                 }
//                                                                 completionHandler(YES);
//                                                             }];
//        [alertController addAction:updateAction];
//        if (!info.updatesForcibly) {
//            [alertController addAction:cancelAction];
//        }
//
//        // 弹出弹窗
//        UIViewController *rootController = [UIApplication sharedApplication].keyWindow.rootViewController;
//        [rootController presentViewController:alertController animated:YES completion:nil];
//    }];
    
    // 初始化
    [[TMFDistributionManager sharedManager] initialize];
}

- (void)prepareStatistics {
//#if DEBUG
//    TMFStatisticsManager.logEnabled = YES;
//#endif
//
//#if OUTPUT_NSLOG_FILE
//    [self outputNSlogToDocumentFolder];
//#endif
//
//    // Note: 上报策略可以组合使用
//    TMFStatisticsReporterStrategy strategy = TMFStatisticsReporterStrategyBatch |
//                                             TMFStatisticsReporterStrategyTimer |
//                                             TMFStatisticsReporterStrategyIntelligence;
//    TMFStatisticsReporterStrategyInterval timerInterval = 1;
//    TMFStatisticsReporterStrategyInterval thresholdInterval = 30;
//
//    TMFStatisticsConfiguration *configuration = [TMFStatisticsConfiguration configureWithAppKey:TMF_XM_KEY
//                                                                                      channelID:@"iOS"
//                                                                                       strategy:strategy
//                                                                                  timerInterval:timerInterval
//                                                                              thresholdInterval:thresholdInterval];
//    [[TMFStatisticsManager defaultManager] startWithConfiguration:configuration];
}

- (void)outputNSlogToDocumentFolder {
    // Note: 将NSLog的日志写入到沙盒文件
    NSString *documentDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
    NSDateFormatter *dateformat = [[NSDateFormatter  alloc] init];
    [dateformat setDateFormat:@"yyyy-MM-dd"];
    NSString *fileName = [NSString stringWithFormat:@"tmf-demo-%@.txt",[dateformat stringFromDate:[NSDate date]]];
    NSString *logFilePath = [documentDirectory stringByAppendingPathComponent:fileName];
    
    // 将log输入到文件
    freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding], "a+", stdout);
    freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding], "a+", stderr);
}


@end

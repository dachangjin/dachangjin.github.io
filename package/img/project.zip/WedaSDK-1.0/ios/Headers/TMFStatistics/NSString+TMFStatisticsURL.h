//
//  NSString+TMFStatisticsURL.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TMFStatisticsURL)

- (BOOL)tmfstatistics_isEqualToString:(NSString *)string;

@end

NS_ASSUME_NONNULL_END

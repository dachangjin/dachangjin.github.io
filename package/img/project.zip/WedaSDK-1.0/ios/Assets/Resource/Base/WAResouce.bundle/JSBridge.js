(function () {

  const log = function (params) {
    if (params == undefined) {
      params = {
        method: 'log',
        data: '',
      };
    } else {
      const args = [];
      for (let index = 0; index < arguments.length; index++) {
        const element = arguments[index];
        args.push(element);
      }
      params = {
        method: 'log',
        data: args,
      };
    }
    try {
      params = JSON.stringify(params);
    } catch (error) {
      params = { info: 'params fail to stringify' };
    }
    window.webkit.messageHandlers.weapps.postMessage(params);
  };

  console.log = log;
  console.error = log;
  console.warn = log;

  window.onerror = function (errorMsg, url, lineNumber) {
    console.log(`Error: ${errorMsg} Script: ${url} Line: ${lineNumber}`);
  };

  const weapps = {};

  weapps.log = function (params) {
    if (typeof params != 'string') {
      params = JSON.stringify(params);
    }
    syncCall('log', params);
  };
  window.$$isIOSWeapps = true;
  window.__weappsNative = weapps;
})();

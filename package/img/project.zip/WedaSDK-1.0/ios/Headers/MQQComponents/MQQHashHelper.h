//
//  MQQHashHelper.h
//  MQQSecure
//
//  Created by Kloudz Liang on 14-4-18.
//  Copyright (c) 2014年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MQQHashHelper : NSObject

@end



@interface MQQHashHelper (MD5)

/**
 * 计算数据的MD5值。
 *
 * @param data 目标数据。
 *
 * @return MD5字符串值。若失败则返回nil。
 */
+ (NSString *)MD5WithData:(NSData *)data;

/**
 * 计算文件的MD5值。
 *
 * @param fileHandle 目标文件。
 *
 * @return MD5字符串值。若失败则返回nil。
 */
+ (NSString *)MD5WithFileHandle:(NSFileHandle *)fileHandle;

/**
 * 计算文件的MD5值。
 *
 * @param fileHandle 目标文件。
 * @param offset     起始文件位移
 * @param length     数据长度（暂时没有实现!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!）
 *
 * @return MD5字符串值。若失败则返回nil。
 */
+ (NSString *)MD5WithFileHandle:(NSFileHandle *)fileHandle offset:(unsigned long long)offset length:(unsigned long long)length;

@end


@interface MQQHashHelper (SHA1)

/**
 * 计算数据的SHA1值。
 *
 * @param data 目标数据。
 *
 * @return SHA1字符串值。若失败则返回nil。
 */
+ (NSString *)SHA1WithData:(NSData *)data;

/**
 * 计算文件的SHA1值。
 *
 * @param fileHandle 目标文件。
 *
 * @return SHA1字符串值。若失败则返回nil。
 */
+ (NSString *)SHA1WithFileHandle:(NSFileHandle *)fileHandle;

@end


@interface MQQHashHelper (SHA256)

/**
 * 计算数据的SHA256值。
 *
 * @param data 目标数据。
 *
 * @return SHA256字符串值。若失败则返回nil。
 */
+ (NSString *)SHA256WithData:(NSData *)data;

/**
 * 计算文件的SHA256值。
 *
 * @param fileHandle 目标文件。
 *
 * @return SHA256字符串值。若失败则返回nil。
 */
+ (NSString *)SHA256WithFileHandle:(NSFileHandle *)fileHandle;

@end


@interface MQQHashHelper (HMAC_SHA1)

/**
 * 计算数据的HMAC_SHA1值。
 *
 * @param data 目标数据。
 *
 * @return HMAC_SHA1字符串值。若失败则返回nil。
 */
+ (NSString *)HMACSHA1WithData:(NSData *)data key:(NSData *)key;

/**
 * 计算数据的HMAC_SHA1值。
 *
 * @param data 目标数据。
 *
 * @return HMAC_SHA1值。若失败则返回nil。
 */
+ (NSData *)HMACSHA1DataWithData:(NSData *)data key:(NSData *)key;

@end

@interface MQQHashHelper (HMAC_SHA256)

/**
 * 计算数据的HMAC_SHA256值。
 *
 * @param data 目标数据。
 *
 * @return HMAC_SHA256字符串值。若失败则返回nil。
 */
+ (NSString *)HMACSHA256WithData:(NSData *)data key:(NSData *)key;

/**
* 计算数据的HMAC_SHA256值。
*
* @param data 目标数据。
*
* @return HMAC_SHA256值。若失败则返回nil。
*/
+ (NSData *)HMACSHA256DataWithData:(NSData *)data key:(NSData *)key;

@end

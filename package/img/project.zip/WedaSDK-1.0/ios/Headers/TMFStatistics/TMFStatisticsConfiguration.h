//
//  TMFStatisticsConfiguration.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/1.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFStatisticsUtilities.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsConfiguration : NSObject <NSCopying>

/**
 @brief 应用Key
*/
@property (nonatomic, copy, readonly) NSString *appKey;

/**
 @brief 渠道ID
*/
@property (nonatomic, copy, readonly) NSString *channelID;

/**
 @brief 会话时长
*/
@property (nonatomic, assign, readonly) NSInteger sessionDuration;

/**
 @brief 上报策略
*/
@property (nonatomic, assign, readonly) TMFStatisticsReporterStrategy strategy;

/**
 @brief 周期上报策略值
 @note 仅在 `TMFStatisticsReporterStrategyTimer` 周期上报模式下有效。时间间隔（单位分钟），取值范围：[1,7*24*60]。-1：停止周期上报。
 */
@property (nonatomic, assign, readonly) TMFStatisticsReporterStrategyInterval timerInterval;

/**
 @brief 批量上报策略值。该值根据策略而异
 @note 仅在 `TMFStatisticsReporterStrategyBatch` 为批量上报时有效。该阈值大于 0。
 */
@property (nonatomic, assign, readonly) TMFStatisticsReporterStrategyInterval thresholdInterval;

/**
 @brief 构造配置器实例
 @param appKey SDK需要的 AppKey，区分支持的应用
 @param channelID 渠道ID
 @param strategy 上报策略，支持组合设置
 @param timerInterval 周期上报策略值
 @param thresholdInterval 批量上报策略值
*/
+ (nullable instancetype)configureWithAppKey:(NSString *)appKey channelID:(NSString *)channelID strategy:(TMFStatisticsReporterStrategy)strategy timerInterval:(TMFStatisticsReporterStrategyInterval)timerInterval thresholdInterval:(TMFStatisticsReporterStrategyInterval)thresholdInterval;

/**
 @brief 构造配置器实例
 @param appKey SDK需要的 AppKey，区分支持的应用
 @param channelID 渠道ID
 @param strategy 上报策略，支持组合设置
 @param timerInterval 周期上报策略值
 @param thresholdInterval 批量上报策略值
 @param sessionDuration 会话时间（单位秒）
*/
+ (nullable instancetype)configureWithAppKey:(NSString *)appKey channelID:(NSString *)channelID strategy:(TMFStatisticsReporterStrategy)strategy timerInterval:(TMFStatisticsReporterStrategyInterval)timerInterval thresholdInterval:(TMFStatisticsReporterStrategyInterval)thresholdInterval sessionDuration:(NSInteger)sessionDuration;

- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

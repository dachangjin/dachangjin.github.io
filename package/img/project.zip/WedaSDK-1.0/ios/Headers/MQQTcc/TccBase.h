#ifndef __TCC_BASE_H_DEFINE__
#define __TCC_BASE_H_DEFINE__

#include "TccSys.h"
#include "TccErrorCode.h"

#if !defined(__TccSymbian__)
#define TCC_TEMPLATE_SPECIALIZATION template<>
#else
#define TCC_TEMPLATE_SPECIALIZATION TEMPLATE_SPECIALIZATION
#endif



#if !defined(__TccSymbianKernel__)
#if !defined(__TccSymbian__)
class TccBase
{
public:
	inline TccBase(){};
	inline virtual ~TccBase(){};
};
typedef void (*TccPtrDeleteHandle)(void*);
#else
#include <e32base.h>
#define TccBase										CBase
typedef TCleanupOperation							TccPtrDeleteHandle;
#endif

#if !defined(__TccSymbian__)
template <class T>
class TRefByValue
{
public:
	inline TRefByValue(T& aRef);
	inline operator T&();
private:
	TRefByValue& operator=(TRefByValue aRef);
private:
	T &iRef;
};
//Constructs this value reference for the specified referenced object.
template <class T>
inline TRefByValue<T>::TRefByValue(T &aRef) : iRef(aRef){}

//Gets a reference to the object encapsulated inside this value reference.
template <class T>
inline TRefByValue<T>::operator T &(){return(iRef);}
#endif

//-----------------------------------------

template<class T>
class TccCleanUpPtrTemplate {
public:
	static void DeleteHandle(void* p){
		delete static_cast<T*>(p);
	}
};

template<class T>
class TccCleanUpArrayTemplate {
public:
	static void DeleteHandle(void* p){
		T* pp = static_cast<T*>(p);
		delete []pp;
	}
};

class TccCleanUpMemoryBlock {
public:
	static void DeleteHandle(void* p){
		TccFree(p);
	}
};

template<class T>
class TccCleanUpCloseTemplate {
public:
	static void DeleteHandle(void* p){
		(static_cast<T*>(p))->Close();
	}
};

template<class T>
class TccCleanUpClearTemplate {
public:
	static void DeleteHandle(void* p){
		(static_cast<T*>(p))->Clear();
	}
};

#if defined(__TccWindows__)
#include <windows.h>
class TccCleanUpDeleteHandleTemplate {
public:
	static void DeleteHandle(void* p){
		CloseHandle((HANDLE)p);
	}
};
#endif

#if defined(__TccAndroidNDK__)	// Java Navtive Interface!

inline void _TccLeave(ti32) {}
inline void _TccLeaveIfError(ti32) {}
inline void _TccLeaveIfNull(void*) {}
inline void _TccLeaveNoMemory()	{}
#define _TccTrap(s) s
#define _TccTrapd(e, s)	ti32 e = 0; s;

#elif !defined(__TccSymbian__)

/*
#if defined(__TccWin32__)
#define WIDEN2(x) L ## x
#define WIDEN(x) WIDEN2(x)
#define __WFILE__ WIDEN(__FILE__)

#define __check_exception	,__FILE__,__LINE__
#else
#define __check_exception
#endif
*/

class TccException{
public:
	terror iReason;
	TccException() : iReason(0) {}
	TccException(const terror& aReason) : iReason(aReason) {}
	~TccException(){}
	inline terror GetReason() const {return iReason; }
};

#define _TccLeave(_reason)						{ throw(TccException(_reason)); }
inline void _TccLeaveIfError(terror _err){if(0 > _err){ throw(TccException(_err));}}
#define _TccLeaveIfNull(_pointer)				{ if(NULL == _pointer) throw(TccException(_TccErrNoMemory)); }
#define _TccLeaveNoMemory()						{ throw(TccException(_TccErrNoMemory)); }

#define _TccTrapd(_r, _s)									\
	terror _r = _TccErrNone;								\
	{try {_s;}												\
	catch (const TccException& l) { _r = l.GetReason();}	\
	catch (...) { _r = _TccErrExtensionNotSupported;} }

#define _TccTrap(_r, _s)									\
	_r = _TccErrNone;								\
{try {_s;}												\
	catch (const TccException& l) { _r = l.GetReason();}	\
	catch (...) { _r = _TccErrExtensionNotSupported;} }

#else // defined __TccSymbian__


#ifdef EKA2
#define LTRY { TRAP_INSTRUMENTATION_START; try {					\
		       __WIN32SEHTRAP										\
		       TTrapHandler* ____t = User::MarkCleanupStack();

#define LCATCH(x)     User::UnMarkCleanupStack(____t);				\
	{ TRAP_INSTRUMENTATION_NOLEAVE; }								\
	__WIN32SEHUNTRAP }												\
	catch (XLeaveException& l) { TInt x; x = l.GetReason();	x = x;	\
	{ TRAP_INSTRUMENTATION_LEAVE(x); }

#define LCATCHX(x)     User::UnMarkCleanupStack(____t);				\
	{ TRAP_INSTRUMENTATION_NOLEAVE; }								\
	__WIN32SEHUNTRAP }												\
	catch (XLeaveException& l) {x = l.GetReason();					\
	{ TRAP_INSTRUMENTATION_LEAVE(x); }

#define LENDTRY } catch (...){										\
		User::Invariant();											\
	}																\
	}

#else
#define LTRY { TTrap t; TInt __lTryLeaveCode; if (t.Trap(__lTryLeaveCode) == 0) {
#define LCATCH(x) TTrap::UnTrap(); } else { TInt x; x = __lTryLeaveCode; x = x;
#define LCATCHX(x) TTrap::UnTrap(); } else { x = __lTryLeaveCode;
#define LENDTRY } }
#endif

// SAFE_DELETE, RENEW, RENEW_ELEAVE
#define SAFE_DELETE(a) \
	delete a; \
	(a) = NULL;

#define RENEW(a, b) \
	SAFE_DELETE(a) \
	a = new b

#define RENEW_ELEAVE(a, b) RENEW(a, (ELeave)b)

// TRAP_IGNORE for EKA1
#if !defined TRAP_IGNORE
	#define TRAP_IGNORE(x)	\
	{ \
		TRAPD(__trapIgnoreErr, x);	\
		__trapIgnoreErr = KErrNone;     /* avoid warning: parameter initialized but not used */	\
	}
#endif

#define _TccLeave(_reason)						User::Leave(_reason)
#define _TccLeaveIfError(_reason)				User::LeaveIfError(_reason)
#define _TccLeaveIfNull(_aPtr)					User::LeaveIfNull(_aPtr)
#define _TccLeaveNoMemory()						User::LeaveNoMemory()
#define _TccTrapd								TRAPD
#define _TccTrap								TRAP

#endif //__TccSymbian__


//-------------------------------------------------------------------------



class TccCleanUpItem{
public:
	TccPtrDeleteHandle iOperation;
	void* iPtr;

	TccCleanUpItem(){
		iOperation = NULL;
		iPtr = NULL;
	}
	~TccCleanUpItem(){}

	inline void Del(){
		if(iPtr != NULL){
			if(iOperation != NULL){
				iOperation(iPtr);
			}
			else{
				delete (static_cast<TccBase*>(iPtr));
			}
		}
		iOperation = NULL;
		iPtr = NULL;
	}
	inline void Pop(){ 
		iOperation = NULL; 
		iPtr = NULL; 
	}
};

#if !defined(__TccSymbian__)

#define _TccCleanUpStackMaxLen		16
template<ti32 StackSize = _TccCleanUpStackMaxLen>
class TccCleanUpStack{
private:
	TccCleanUpItem iStack[StackSize];
	ti32 iPos;

public:

	TccCleanUpStack(){
		iPos = 0;
	}

	~TccCleanUpStack(){
		while(iPos > 0){
			--iPos;
			iStack[iPos].Del();
		}
	}

	inline void PushL(TccPtrDeleteHandle aOperation, void* aPtr){
		if(iPos > StackSize) _TccLeave(-9);
		iStack[iPos].iOperation = aOperation;
		iStack[iPos].iPtr = aPtr;
		iPos++;
	}

	inline void PushL(TccBase* aPtr){
		PushL(TccCleanUpPtrTemplate<TccBase>::DeleteHandle, aPtr);
	}

	template<class T>
	inline void PushDeleteL(T* aPtr){
		PushL(TccCleanUpPtrTemplate<T>::DeleteHandle, aPtr);
	}

	template<class T>
	inline void PushArrayL(T* aPtr){
		PushL(TccCleanUpArrayTemplate<T>::DeleteHandle, aPtr);
	}

	template<class T>
	inline void PushCloseL(T& aRef){
		PushL(TccCleanUpCloseTemplate<T>::DeleteHandle, &aRef);
	}

	inline void PushMemBlockL(void* aPtr){
		PushL(TccCleanUpMemoryBlock::DeleteHandle, aPtr);
	}

	template<class T>
	inline void PushClearL(T& aRef){
		PushL(TccCleanUpClearTemplate<T>::DeleteHandle, &aRef);
	}

	inline void Pop(void* aPtr) {
		TccAssert(iPos > 0);
		TccAssert(iStack[iPos - 1].iPtr == aPtr);
		iPos--;
		iStack[iPos].Pop();
	}

	inline void Pop(int aNum){
		for (ti32 i = 0; (iPos > 0) && (i < aNum); i++){
			iPos--;
			iStack[iPos].Pop();
		}
	}

	inline void Pop(){
		if(iPos > 0){
			iPos--;
			iStack[iPos].Pop();
		}
	}

	inline void PopAndDestroy(void* aPtr) {
		TccAssert(iPos > 0);
		TccAssert(iStack[iPos - 1].iPtr == aPtr);
		iPos--;
		iStack[iPos].Del();
	}

	inline void PopAndDestroy(ti32 aNum){
		for (ti32 i = 0; (iPos > 0) && (i < aNum); i++){
			iPos--;
			iStack[iPos].Del();
		}
	}
	inline void PopAndDestroy(){
		if(iPos > 0){
			iPos--;
			iStack[iPos].Del();
		}
	}
};

///CleanUpStack code define

#define _TccCleanUpBegin()							TccCleanUpStack<_TccCleanUpStackMaxLen> ___TccCleanUpStack
#define _TccCleanUpPushL(_aPtr)						{___TccCleanUpStack.PushL(_aPtr);}
#define _TccCleanUpDeletePushL(_aPtr)				{___TccCleanUpStack.PushDeleteL(_aPtr);}
#define _TccCleanUpArrayDeletePushL(_aPtr)			{___TccCleanUpStack.PushArrayL(_aPtr);}
#define _TccCleanUpMemBlockPushL(_aPtr)				{___TccCleanUpStack.PushMemBlockL(_aPtr);}
#define _TccCleanUpPtrHandlePushL(_Handle, _aPtr)	{___TccCleanUpStack.PushL(_Handle ,_aPtr);}
#define _TccCleanUpClosePushL(aRef)					{___TccCleanUpStack.PushCloseL(aRef);}
#define _TccCleanUpClearPushL(aRef)					{___TccCleanUpStack.PushClearL(aRef);}

#define _TccCleanUpPop()							{___TccCleanUpStack.Pop();}
#define _TccCleanUpPopN(_aNum)						{___TccCleanUpStack.Pop(_aNum);}
#define _TccCleanUpPopPtr(_aPtr)					{___TccCleanUpStack.Pop(_aPtr);}

#define _TccCleanUpDestroy()						{___TccCleanUpStack.PopAndDestroy();}
#define _TccCleanUpDestroyN(_aNum)					{___TccCleanUpStack.PopAndDestroy(_aNum);}
#define _TccCleanUpDestroyPtr(_aPtr)				{___TccCleanUpStack.PopAndDestroy(_aPtr);}

#else // defined __TccSymbian__

template<class T>
class TccCleanUpPointerArrayPtrTemplate {
public:
	static void DeleteHandle(void* aPtr){
		static_cast<T*>(aPtr)->ResetAndDestroy();
		delete static_cast<T*>(aPtr);
	}
};
template <typename T> inline void CleanupPointerArrayPushL(T* aPtr){
	CleanupStack::PushL(TCleanupItem(TccCleanUpPointerArrayPtrTemplate<T>::DeleteHandle, aPtr));
}

#define _TccCleanUpBegin()							{}
#define _TccCleanUpPushL(_aPtr)						{CleanupStack::PushL(_aPtr);}
#define _TccCleanUpDeletePushL(_aPtr)				{CleanupDeletePushL(_aPtr);}
#if defined(__StSeries60_1st__)
template <class T>
inline void _TccCleanUpArrayDeletePushL(T* aPtr)	{
	CleanupStack::PushL(TCleanupItem(TccCleanUpArrayTemplate<T>::DeleteHandle, aPtr));
}
#else
#define _TccCleanUpArrayDeletePushL(_aPtr)			{CleanupArrayDeletePushL(_aPtr);}
#endif
#define _TccCleanUpMemBlockPushL(_aPtr)				{CleanupStack::PushL(_aPtr);}
#define _TccCleanUpPtrHandlePushL(_Handle, _aPtr)	{CleanupStack::PushL(TCleanupItem(_Handle, _aPtr));}
#define _TccCleanUpClosePushL(aRef)					{CleanupClosePushL(aRef);}

template <class T>
inline void _TccCleanUpClearPushL(T& aRef)	{
	CleanupStack::PushL(TCleanupItem(TccCleanUpClearTemplate<T>::DeleteHandle, &aRef));
}

#define _TccCleanUpPop()							{CleanupStack::Pop();}
#define _TccCleanUpPopN(_aNum)						{CleanupStack::Pop(_aNum);}
#define _TccCleanUpPopPtr(_aPtr)					{CleanupStack::Pop(_aPtr);}

#define _TccCleanUpDestroy()						{CleanupStack::PopAndDestroy();}
#define _TccCleanUpDestroyN(_aNum)					{CleanupStack::PopAndDestroy(_aNum);}
#define _TccCleanUpDestroyPtr(_aPtr)				{CleanupStack::PopAndDestroy(_aPtr);}

#endif //__TccSymbian__


#if !defined(__TccSymbian__)
#define _TNewEL(_ClassName, _aName) \
	_ClassName * _aName = new _ClassName(); _TccLeaveIfNull(_aName)
#else
#define _TNewEL(_ClassName, _aName) \
	_ClassName * _aName = new(ELeave) _ClassName()
#endif

#define _SCBegin									_TccCleanUpBegin
#define _SCPL										_TccCleanUpPushL
#define _SCDPL										_TccCleanUpDeletePushL
#define _SCADPL										_TccCleanUpArrayDeletePushL
#define _SCMPL										_TccCleanUpMemBlockPushL

#define _SCP										_TccCleanUpPop
#define _SCPN										_TccCleanUpPopN
#define _SCPP										_TccCleanUpPopPtr

#define _SCD										_TccCleanUpDestroy
#define _SCDN										_TccCleanUpDestroyN
#define _SCDP										_TccCleanUpDestroyPtr

#define _SL											_TccLeave
#define _SLE										_TccLeaveIfError
#define _SLN										_TccLeaveIfNull
#define _SLM										_TccLeaveNoMemory
#define _SLT										_TccTrapd

#else
inline void _TccLeave(ti32) {}
inline void _TccLeaveIfError(ti32) {}
inline void _TccLeaveIfNull(ti32) {}
inline void _TccLeaveNoMemory()	{}
#define _TccTrap(s) s
#define _TccTrapd(e, s)	ti32 e = 0; s;
#endif

#endif //__TCC_BASE_H_DEFINE__


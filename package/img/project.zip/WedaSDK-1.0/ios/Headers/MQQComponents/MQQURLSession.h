//
//  MQQURLSession.h
//  MQQSecure
//
//  Created by klaudz on 12/8/2016.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MQQHttpRequest.h"
#import "NSURLSessionConfiguration+MQQHttpRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface MQQURLSession : NSObject

+ (BOOL)supportsNSURLSession;

// A shared instance of MQQURLSession.
// Its configuration is a default configuration with the properties below:
//  1. configuration.timeoutIntervalForRequest = kMQQHttpRequestTimeoutSeconds;
+ (instancetype)sharedSession;

+ (instancetype)sessionWithConfiguration:(NSURLSessionConfiguration *)configuration;
- (instancetype)initWithConfiguration:(NSURLSessionConfiguration *)configuration;

+ (instancetype)unavailableSession;
- (instancetype)initUnavailableSession;

- (instancetype)init NS_UNAVAILABLE;

@property (nonatomic, readonly, copy) NSURLSessionConfiguration *configuration;
@property (nonatomic, readonly, copy) NSURLSession *session;

- (MQQHttpRequest *)requestWithURL:(NSURL *)URL;

- (void)invalidateAndCancel;

@property (nonatomic, copy, nullable) dispatch_block_t backgroundURLSessionCompletionHandler;

@end

NS_ASSUME_NONNULL_END

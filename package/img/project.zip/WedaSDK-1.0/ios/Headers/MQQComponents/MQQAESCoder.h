//
//  MQQAESCoder.h
//  Pods
//
//  Created by klaudz on 28/6/2019.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT
NSData * _Nullable MQQAES128EncryptECB(NSData *data, NSString *key);

FOUNDATION_EXPORT
NSData * _Nullable MQQAES128DecryptECB(NSData *data, NSString *key);

NS_ASSUME_NONNULL_END

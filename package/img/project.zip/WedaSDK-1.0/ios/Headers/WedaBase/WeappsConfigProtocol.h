//
//  WeappsConfigProtocol.h
//  weapps
//
//  Created by tommywwang on 2021/1/13.
//  Copyright © 2021 tencent. All rights reserved.
//

#ifndef WeappsConfigProtocol_h
#define WeappsConfigProtocol_h

#import "WAUIConfig.h"

/// 配置信息变化协议
@protocol WeappsConfigDelegate <NSObject>

- (void)weappsConfigDidChange:(WAUIConfig *)config withSource:(NSString *)source;

@end

#endif /* WeappsConfigProtocol_h */

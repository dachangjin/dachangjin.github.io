//
//  NSArray+TMFStatisticsFormat.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/3.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (TMFStatisticsFormat)

- (NSString *)tmfstatistics_formatWithSelector:(SEL)aSelector;

@end

NS_ASSUME_NONNULL_END

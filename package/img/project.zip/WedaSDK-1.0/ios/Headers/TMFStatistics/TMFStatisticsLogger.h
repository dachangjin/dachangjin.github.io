//
//  TMFStatisticsLog.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/11/11.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#if DEBUG
#define TMF_LOG_ENABLED 1
#endif

extern BOOL TMFStatisticsLogger_logEnabled;

/**
 @brief 日志级别
 */
typedef NS_ENUM(NSInteger, TMFStatisticsLogLevel) {
    TMFStatisticsLogLevelDebug = 0,         ///<  调试帮助日志
    TMFStatisticsLogLevelInfo = 1,          ///< 运行过程关键日志
    TMFStatisticsLogLevelWarn = 2,          ///< 存在潜在问题日志
    TMFStatisticsLogLevelError = 3,         ///< 严重错误导致系统退出日志
};

#define TMFStatisticsDebug(_format_, ...)      TMFStatisticsLog(TMFStatisticsLogLevelDebug, @"", _format_, ##__VA_ARGS__)
#define TMFStatisticsInfo(_format_, ...)       TMFStatisticsLog(TMFStatisticsLogLevelInfo, @"", _format_, ##__VA_ARGS__)
#define TMFStatisticsWarn(_format_, ...)       TMFStatisticsLog(TMFStatisticsLogLevelWarn, @"[⚠️]", _format_, ##__VA_ARGS__)
#define TMFStatisticsError(_format_, ...)      TMFStatisticsLog(TMFStatisticsLogLevelError, @"[❌]", _format_, ##__VA_ARGS__)

#if TMF_LOG_ENABLED
#define TMFStatisticsLog(lv, _tag_, _format_, ...) \
    if (TMFStatisticsLogger_logEnabled) { \
        NSLog(@"[TMFStatistics] -> [class:%@]%@ " _format_, [self class], _tag_, ##__VA_ARGS__); \
    }
#else
#define TMFStatisticsLog(lv, _tag_, _format_, ...)
#endif

NS_ASSUME_NONNULL_END

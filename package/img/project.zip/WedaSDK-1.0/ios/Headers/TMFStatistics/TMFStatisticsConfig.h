//
//  TMFStatisticsConfig.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#ifndef TMFStatisticsConfig_h
#define TMFStatisticsConfig_h

#pragma mark - SANDBOX

#define TMF_SANDBOX_INTERNAL_DIR [NSHomeDirectory() stringByAppendingPathComponent:@"Library/TMF"]
#define TMF_SANDBOX_INTERNAL_PATH(__componentName__, __fileName__) ({ \
    NSString *filePath = [__componentName__ stringByAppendingPathComponent:__fileName__]; \
    [TMF_SANDBOX_INTERNAL_DIR stringByAppendingPathComponent:filePath]; \
})

#define TMFStatistics_Directory ([TMF_SANDBOX_INTERNAL_DIR stringByAppendingPathComponent:@"TMFStatistics"])
#define TMFStatistics_DataFilePath ([TMFStatistics_Directory stringByAppendingPathComponent:@".st.dat"])
#define TMFStatistics_UpdateFilePath ([TMFStatistics_Directory stringByAppendingPathComponent:@".cfg.dat"])

#pragma mark - SDK

#define TMF_SDK_VERSION @"1.0.0"         // tmf移动分析tmf sdk version
#define TMF_SDK_PF      @"2"             // tmf移动分析sdk的平台,1:Android,2:IOS,3:小程序,4:H5页面
#define TMF_SDK_OS      @"2"             // 平台,1:Android,2:IOS(必填)

#endif /* TMFStatisticsConfig_h */

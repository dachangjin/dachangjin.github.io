//
//  TMFStatisticsReporter+Active.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (Active)

- (void)et4_APP_EventWithDuration:(NSInteger)duration configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

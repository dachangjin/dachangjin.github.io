//
//  TMFWKViewHelper.h
//  QBWebView
//
//  Created by zuckchen on 9/12/16.
//  Copyright © 2017 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMFWKProtocolWorker.h"
@interface TMFWKViewHelper : NSObject

/*
 *  启动QBWebView的HttpDNS代理。传入的参数需要是TMFWKProtocolWorker类或者其子类（必须调用）。
 */
+ (void)startProxyWithWorker:(Class _Nonnull)worker;

/*
 *  启动QBWebView的HttpDNS代理。
 *  worker参数需要是TMFWKProtocolWorker类或者其子类（必须调用）
 *  isNeedInitialize参数表示是否需要执行初始化环境检查
 */
+ (void)startProxyWithWorkerWithInitialize:(Class _Nonnull)worker initialize:(BOOL)isNeedInitialize;

/*
 *  检查初始化环境
 */
+ (void)checkInitialize;

/*
 *  判断此request是否是QBWebViewProtocol能处理的请求
 *  QBWebView注册的NSURLProtocol只处理QBWebView发起的http,https,ftp请求
 *  建议如果返回值是YES，将此请求交予QBWebView SDK的NSURLProtocol处理。
 */
+ (BOOL)isQBWebViewRequest:(NSURLRequest * _Nonnull )request;

/*
 *  提供对本地缓存存储前的一些特殊处理,提供对vary的支持
 *  如果为sharpP格式数据,会返回nil,不需要再调用[super storeCachedResponse:response forRequest:request]进行存储
 */
+ (NSCachedURLResponse * _Nullable)processCachedResponse:(NSCachedURLResponse * _Nonnull)cachedResponse forRequest:(NSURLRequest * _Nonnull)request;


#if !QBModule_ReducePackage_3
+ (void)setCustomUA:(NSString *_Nonnull) userAgent;

/*
 *  接收host app传递过来的缓存cache，网络层判断cache时效性后将使用有效的cache直接返回，不发送网络请求。
 *  我们发现对于[NSURLCache cachedResponseForRequest:]方法，系统调用此方法获得数据的概率大于app主动调用获取数据的概率。
 *  因此我们建议，如果app使用了自定义类来管理NSURLCache,那在重写[NSURLCache cachedResponseForRequest:]时，如果获取NSCachedURLResponse值，可以讲其通过下面的方法传递给sdk。这样sdk在请求数据时，会先判断app是否针对此request传递过cache--如果是，
 并且没有过期的情况下，sdk会使用cache以节省流量与时间。
 */
+ (void)URLCacheDidFetchCacheResponse:(NSCachedURLResponse *_Nonnull)response forRequest:(NSURLRequest * _Nonnull )request;
#endif

#if !QBModule_ReducePackage

+ (void)clearCookiesCompletionHandler:( void (^ _Nullable )(void))completionHandler;

+ (void)clearCachesCompletionHandler:( void (^ _Nullable )(void))completionHandler;
#endif
@end

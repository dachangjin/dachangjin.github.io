#ifndef __TCC_ENDIAN_H_DEFINE__
#define __TCC_ENDIAN_H_DEFINE__

#include "TccSys.h"


//#define __TccSystemLittleEndian__
//#define __TccSystemBigEndian__


//��Сͷת��(�����)
#define _TccEndianSwap16(n) ((((n) & 0xFFU) << 8) | (((n) & 0xFF00U) >> 8))
#define _TccEndianSwap32(n) ((((n) & 0xFFU) << 24) | (((n) & 0xFF00U) << 8) | (((n) & 0xFF0000U) >> 8) | (((n)& 0xFF000000U) >> 24))
#ifdef __TccHasU64Type__
#define _TccEndianSwap64(n) ( \
    ((tu64)(n) & 0x00000000000000ffULL) << 56 | \
    ((tu64)(n) & 0x000000000000ff00ULL) << 40 | \
    ((tu64)(n) & 0x0000000000ff0000ULL) << 24 | \
    ((tu64)(n) & 0x00000000ff000000ULL) << 8 | \
    ((tu64)(n) & 0x000000ff00000000ULL) >> 8 | \
    ((tu64)(n) & 0x0000ff0000000000ULL) >> 24 | \
    ((tu64)(n) & 0x00ff000000000000ULL) >> 40 | \
    ((tu64)(n) & 0xff00000000000000ULL) >> 56)
#endif

/* Handle endian-ness */
#ifndef __TccSystemBigEndian__
#define _TccMakeSureEndian(n) (n)
#elif defined(b_TWAP_32)
#define _TccMakeSureEndian(n) b_TWAP_32(n)
#else
#define _TccMakeSureEndian(n) _TccEndianSwap32(n)
#endif

//---------------------------------------------------------------------
inline void TccGetU64FromBigEndianBuf(const tu8* aBuf, tu32& aU32){
	*((tu8*)(&aU32) + 0) = *(aBuf + 3);
	*((tu8*)(&aU32) + 1) = *(aBuf + 2);
	*((tu8*)(&aU32) + 2) = *(aBuf + 1);
	*((tu8*)(&aU32) + 3) = *(aBuf + 0);
}
inline void TccGetU64FromLittleEndianBuf(const tu8* aBuf, tu32& aU32){
//	aU32 = *((tu32*)aBuf);
	*((tu8*)(&aU32) + 0) = *(aBuf + 0);
	*((tu8*)(&aU32) + 1) = *(aBuf + 1);
	*((tu8*)(&aU32) + 2) = *(aBuf + 2);
	*((tu8*)(&aU32) + 3) = *(aBuf + 3);
}
inline void TccGetU32FromBigEndianBuf(const tu8* aBuf, tu32& aU32){
	*((tu8*)(&aU32) + 0) = *(aBuf + 3);
	*((tu8*)(&aU32) + 1) = *(aBuf + 2);
	*((tu8*)(&aU32) + 2) = *(aBuf + 1);
	*((tu8*)(&aU32) + 3) = *(aBuf + 0);
}
inline void TccGetU32FromLittleEndianBuf(const tu8* aBuf, tu32& aU32){
//	aU32 = *((tu32*)aBuf);
	*((tu8*)(&aU32) + 0) = *(aBuf + 0);
	*((tu8*)(&aU32) + 1) = *(aBuf + 1);
	*((tu8*)(&aU32) + 2) = *(aBuf + 2);
	*((tu8*)(&aU32) + 3) = *(aBuf + 3);
}

inline void TccGetI32FromBigEndianBuf(const tu8* aBuf, ti32& aU32){
	*((tu8*)(&aU32) + 0) = *(aBuf + 3);
	*((tu8*)(&aU32) + 1) = *(aBuf + 2);
	*((tu8*)(&aU32) + 2) = *(aBuf + 1);
	*((tu8*)(&aU32) + 3) = *(aBuf + 0);
}
inline void TccGetI32FromLittleEndianBuf(const tu8* aBuf, ti32& aU32){
//	aU32 = *((ti32*)aBuf);
	*((tu8*)(&aU32) + 0) = *(aBuf + 0);
	*((tu8*)(&aU32) + 1) = *(aBuf + 1);
	*((tu8*)(&aU32) + 2) = *(aBuf + 2);
	*((tu8*)(&aU32) + 3) = *(aBuf + 3);
}

inline void TccSetU32ToBigEndianBuf(char& b1,char& b2,char& b3,char& b4){
	char a1 =  b1, a2 = b2, a3 = b3, a4 = b4;
	b1 = a4;b2 = a3;b3 = a2;b4 = a1;
}

inline void TccSetU32ToBigEndianBuf(tu32* aBuf){
	tu32 src = *aBuf;
	((tu8*)aBuf)[0] = (tu8)(((src) & 0xFF000000U) >> 24);
	((tu8*)aBuf)[1] = (tu8)(((src) & 0x00FF0000U) >> 16);
	((tu8*)aBuf)[2] = (tu8)(((src) & 0x0000FF00U) >> 8);
	((tu8*)aBuf)[3] = (tu8)( (src) & 0x000000FFU);
}

inline void TccSetU32ToBigEndianBuf(tu32 aU32, tu8* aBuf){
	aBuf[0] = (tu8)(((aU32) & 0xFF000000U) >> 24);
	aBuf[1] = (tu8)(((aU32) & 0x00FF0000U) >> 16);
	aBuf[2] = (tu8)(((aU32) & 0x0000FF00U) >> 8);
	aBuf[3] = (tu8)( (aU32) & 0x000000FFU);
}

inline void TccSetU32ToLittleEndianBuf(tu32 aU32, tu8* aBuf){
	//*((tu32*)aBuf) = aU32;
	aBuf[0] = (tu8)( (aU32) & 0x000000FFU);
	aBuf[1] = (tu8)(((aU32) & 0x0000FF00U) >> 8);
	aBuf[2] = (tu8)(((aU32) & 0x00FF0000U) >> 16);
	aBuf[3] = (tu8)(((aU32) & 0xFF000000U) >> 24);
}

//---------------------------------------------------------------------
inline void TccGetU16FromBigEndianBuf(const tu8* aBuf, tu16& aU16){
	*((tu8*)(&aU16) + 0) = *(aBuf + 1);
	*((tu8*)(&aU16) + 1) = *(aBuf + 0);
}
inline void TccGetU16FromLittleEndianBuf(const tu8* aBuf, tu16& aU16){
//	aU16 = *((tu16*)aBuf);
	*((tu8*)(&aU16) + 0) = *(aBuf + 0);
	*((tu8*)(&aU16) + 1) = *(aBuf + 1);
}

inline void TccGetI16FromBigEndianBuf(const tu8* aBuf, ti16& aU16){
	*((tu8*)(&aU16) + 0) = *(aBuf + 1);
	*((tu8*)(&aU16) + 1) = *(aBuf + 0);
}
inline void TccGetI16FromLittleEndianBuf(const tu8* aBuf, ti16& aU16){
//	aU16 = *((ti16*)aBuf);
	*((tu8*)(&aU16) + 0) = *(aBuf + 0);
	*((tu8*)(&aU16) + 1) = *(aBuf + 1);
}
inline void TccSetU16ToBigEndianBuf(tu16* aBuf){
	tu16 src = *aBuf;
	((tu8*)aBuf)[0] = (tu8)(((src) & 0xFF00U) >> 8);
	((tu8*)aBuf)[1] = (tu8)( (src) & 0x00FFU);
}
inline void TccSetU16ToBigEndianBuf(tu16 aU16, tu8* aBuf){
	aBuf[0] = (tu8)(((aU16) & 0xFF00U) >> 8);
	aBuf[1] = (tu8)( (aU16) & 0x00FFU);
}
inline void TccSetU16ToLittleEndianBuf(tu16 aU16, tu8* aBuf){
	aBuf[0] = (tu8)( (aU16) & 0x00FFU);
	aBuf[1] = (tu8)(((aU16) & 0xFF00U) >> 8);
}

inline tu16 TccHtoNS(tu16 n){return _TccEndianSwap16(n);}
inline tu32 TccHtoNL(tu32 n){return _TccEndianSwap32(n);}

#ifdef __TccHasU64Type__
inline tu64 TccHtoNLL(tu64 n){ return _TccEndianSwap64(n);}
#define TccHtoNQ TccHtoNLL
#endif

#define TccNtoHS TccHtoNS
#define TccNtoHL TccHtoNL
#define TccNtoHLL TccHtoNLL
#ifdef __TccHasU64Type__
#define TccNtoHQ TccHtoNQ
#endif

#endif //__TCC_ENDIAN_H_DEFINE__


//
//  MQQHTTPSocketFetcher.h
//  MQQHTTPURLSession
//
//  Created by hauzhong on 2019/2/15.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define MQQCelluerInterface @"pdp_ip0"

extern NSErrorDomain const MQQHTTPSocketFetcherErrorDomain;

@interface MQQHTTPSocketFetcher : NSObject

/* timeout for request. default is 15s. */
@property (nonatomic, assign) NSTimeInterval timeoutIntervalForRequest;

@property (nonatomic, copy, readonly) NSString *interface;
@property (nonatomic, assign) BOOL optimizedInterface;

- (void)fetchWithURL:(NSURL *)URL completionHandler:(void(^)(NSData * _Nullable data, NSHTTPURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;
- (void)fetchWithRequest:(NSURLRequest *)request completionHandler:(void(^)(NSData * _Nullable data, NSHTTPURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;

- (void)cancel;

@end

@interface MQQHTTPSocketFetcher (Interface)

- (void)fetchWithURL:(NSURL *)URL viaInterface:(nullable NSString *)interface completionHandler:(void(^)(NSData * _Nullable data, NSHTTPURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;
- (void)fetchWithRequest:(NSURLRequest *)request viaInterface:(nullable NSString *)interface completionHandler:(void(^)(NSData * _Nullable data, NSHTTPURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;

@end

NS_ASSUME_NONNULL_END

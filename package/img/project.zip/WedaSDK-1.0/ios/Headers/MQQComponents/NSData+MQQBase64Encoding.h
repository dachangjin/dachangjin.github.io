//
//  NSData+MQQBase64.h
//  MQQSecure
//
//  Created by klaudz on 1/4/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (MQQBase64)

- (instancetype)initWithMqqBase64EncodedString:(NSString *)base64String;

- (NSString *)mqqBase64EncodedString;

@end

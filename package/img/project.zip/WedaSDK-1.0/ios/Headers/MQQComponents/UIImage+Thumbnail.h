//
//  UIImage+Thumbnail.h
//  MQQSecure
//
//  Created by Kloudz Liang on 12-7-12.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 * 提供获取图片缩略图的方法
 */
@interface UIImage (Thumbnail)
/**
 * 生成缩略图，缩放比例为图片比例
 * @param size  : 缩略图尺寸
 */
- (UIImage *)thumbnailWithSize:(CGSize)size;
/**
 * 生成缩略图
 * @param size  : 缩略图尺寸
 * @param scale : 缩放比例
 */
- (UIImage *)thumbnailWithSize:(CGSize)size withScale:(CGFloat)scale;
@end

//
//  TMFSM2Coder.h
//  Pods
//
//  Created by klaudz on 20/5/2019.
//

#import <Foundation/Foundation.h>
#import "TMFSMDefines.h"

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN
TMFSMStatus TMFSM2Encrypt(NSData *dataIn,
                          NSData *publicKey_X, NSData *publicKey_Y,
                          NSData * _Nullable * _Nullable dataOut_C1, NSData * _Nullable * _Nullable dataOut_C3, NSData * _Nullable * _Nullable dataOut_C2);

FOUNDATION_EXTERN
TMFSMStatus TMFSM2Decrypt(NSData *dataIn_C1, NSData *dataIn_C3, NSData *dataIn_C2,
                          NSData *privateKey,
                          NSData * _Nullable * _Nullable dataOut);

FOUNDATION_EXTERN
TMFSMStatus TMFSM2EncryptEx(NSData *dataIn,
                            NSData *publicKey_X_Y,
                            NSData * _Nullable * _Nullable dataOut_C1_C3_C2);

FOUNDATION_EXTERN
TMFSMStatus TMFSM2DecryptEx(NSData *dataIn_C1_C3_C2,
                            NSData *privateKey,
                            NSData * _Nullable * _Nullable dataOut);

NS_ASSUME_NONNULL_END

//
//  MQQKeyHelper.h
//  MQQSecure
//
//  Created by Kloudz Liang on 14-5-30.
//  Copyright (c) 2014年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Warning!!!
 *
 * 此方法只适用于加密本地的密钥。
 *
 * 由于此方法的算法可能不断优化或改变，具有版本性，
 * 因此，已加密的密钥只适合用于hard code，
 * 不能把通过此方法加密得到的密钥保存到数据库或上传到云端。
 */


// 换个名字伪装，降低反编译后代码的可读性
#define MQQEncodeLocalizedKey MQQDataFromString
#define MQQDecodeLocalizedKey MQQStringFromData


#ifdef DEBUG
/**
 * 把本地密码加密
 */
extern bool MQQEncodeLocalizedKey(size_t length, const char *src, char *des, char salt);
#endif

/**
 * 把已加密的本地密码解密
 *
 * example:
 * =============== 华丽分割线 ===============
 *  static const char MQQEncodeKey[] = { ... };
 *  static const char MQQEncodeKeySalt = '*';
 *
 *  size_t keyLen = sizeof(MQQEncodeKey);
 *  char *keyData = (char *)malloc(keyLen);
 *  if (keyData) {
 *      MQQDecodeLocalizedKey(keyLen, MQQEncodeKey, keyData, MQQEncodeKeySalt);
 *      // use the keyData (original key)...
 *      free(keyData);
 *  }
 * =============== 华丽分割线 ===============
 */
extern bool MQQDecodeLocalizedKey(size_t length, const char *src, char *des, char salt);

//
//  TMFWkWebView.h
//  QBWebView
//
//  Created by zuckchen on 7/15/16.
//  Copyright © 2017 Tencent. All rights reserved.
//

#import <WebKit/WebKit.h>

API_AVAILABLE(macosx(10.10), ios(8.0)) @interface TMFWkWebView : WKWebView

//默认不调起第三方app
@property (nonatomic, assign)BOOL isULinksEnable;

/*
 *  TMFWkWebView选中的文本
 */
@property (nonatomic, readonly, copy) NSString *selectedString;

/*
 *  判断TMFWkWebView是否可以过NSURLProtocol代理
 *  @vital TMFWkWebView有非常小的可能性过代理失败，这里宿主应该要做容错处理
 */
+ (BOOL)isProzyAvailable;

/*
 *  设置过代理，如果代理不可以用，则返回NO,否则返回YES（TMFWkWebView有非常小的可能性过代理失败，这里宿主应该要做容错处理，失败原因可参考error）
 *  如果不想用代理，请不要调用这个接口。
 */
+ (BOOL)enableWKProzy:(NSError **)error;

/*
 * 清除设置代理的内存，后面创建的WKWebView就不会过代理了（PS：之前创建的WKWebView过代理状态不受影响）
 */
+ (void)clearProzyMemory;


/*
 *  释放TMFWkWebView
 *  @vital 释放TMFWkWebView时一定要调用下destroy方法，否则有可能crash
 */
- (void)destroy;
@end

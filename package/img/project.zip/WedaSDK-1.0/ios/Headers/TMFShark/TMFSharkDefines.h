//
//  TMFSharkDefines.h
//  TMFShark
//
//  Created by klaudz on 12/12/2017.
//  Copyright © 2017 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, TMFSharkPlatform) {
    TMFSharkPlatformNone = 0,
    TMFSharkPlatformIOS = 3,
    TMFSharkPlatformMacOS = 11,
};

typedef NS_ENUM(NSInteger, TMFSharkSubplatform) {
    TMFSharkSubplatformNone = 0,
    TMFSharkSubplatformIPhone = 301,
    TMFSharkSubplatformIPad = 302,
    TMFSharkSubplatformIPod = 303,
    TMFSharkSubplatformMacOS = 1101,
};

NS_ASSUME_NONNULL_END

//
//  MQQHttpRequestError.h
//  MQQSecure
//
//  Created by Kloudz Liang on 14-5-19.
//  Copyright (c) 2014年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

// 错误域
extern NSString *const kMQQHttpRequestErrorDomain;

// 错误码
extern NSInteger const kMQQHttpRequestErrorURLConnectionCannotInit; // NSURLConnection init 失败
extern NSInteger const kMQQHttpRequestErrorFileHasBeenDownloading; // 文件已经在下载
extern NSInteger const kMQQHttpRequestErrorCannotWriteDataToFile; // 写入文件失败
extern NSInteger const kMQQHttpRequestErrorInvalidResponseForFile; // 文件请求失败，例如返回404等情况
extern NSInteger const kMQQHttpRequestErrorInvalidDownloadDestinationPath; // 非法的文件路径

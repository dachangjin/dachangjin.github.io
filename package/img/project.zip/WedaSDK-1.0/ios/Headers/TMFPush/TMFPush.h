//
//  TMFPush.h
//  TMFPush
//
//  Created by hauzhong on 2019/6/25.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 点击行为对象的属性配置
 
 - TMFNotificationActionOptionNone: 无
 - TMFNotificationActionOptionAuthenticationRequired: 需要认证的选项
 - TMFNotificationActionOptionDestructive: 具有破坏意义的选项
 - TMFNotificationActionOptionForeground: 打开应用的选项
 */
typedef NS_OPTIONS(NSUInteger, TMFNotificationActionOptions) {
    TMFNotificationActionOptionNone = (0),
    TMFNotificationActionOptionAuthenticationRequired = (1 << 0),
    TMFNotificationActionOptionDestructive = (1 << 1),
    TMFNotificationActionOptionForeground = (1 << 2)
};

/**
 * @brief 定义了一个可以在通知栏中点击的事件对象
 */
@interface TMFNotificationAction : NSObject

/**
 @brief 在通知消息中创建一个可以点击的事件行为
 
 @param identifier 行为唯一标识
 @param title 行为名称
 @param options 行为支持的选项
 @return 行为对象
 @note 通知栏带有点击事件的特性，只有在iOS8+以上支持，iOS 8 or earlier的版本，此方法返回空
 */
+ (nullable id)actionWithIdentifier:(NSString *)identifier title:(NSString *)title options:(TMFNotificationActionOptions)options;

/**
 @brief 点击行为的标识
 */
@property (nullable, nonatomic, copy, readonly) NSString *identifier;

/**
 @brief 点击行为的标题
 */
@property (nullable, nonatomic, copy, readonly) NSString *title;

/**
 @brief 点击行为的特性
 */
@property (readonly, nonatomic) TMFNotificationActionOptions options;

@end


/**
 @brief 分类对象的属性配置
 
 - TMFNotificationCategoryOptionNone: 无
 - TMFNotificationCategoryOptionCustomDismissAction: 发送消失事件给UNUserNotificationCenter(iOS 10 or later)对象
 - TMFNotificationCategoryOptionAllowInCarPlay: 允许CarPlay展示此类型的消息
 */
typedef NS_OPTIONS(NSUInteger, TMFNotificationCategoryOptions) {
    TMFNotificationCategoryOptionNone = (0),
    TMFNotificationCategoryOptionCustomDismissAction = (1 << 0),
    TMFNotificationCategoryOptionAllowInCarPlay = (1 << 1)
};


/**
 * 通知栏中消息指定的分类，分类主要用来管理一组关联的Action，以实现不同分类对应不同的Actions
 */
@interface TMFNotificationCategory : NSObject


/**
 @brief 创建分类对象，用以管理通知栏的Action对象
 
 @param identifier 分类对象的标识
 @param actions 当前分类拥有的行为对象组
 @param intentIdentifiers 用以表明可以通过Siri识别的标识
 @param options 分类的特性
 @return 管理点击行为的分类对象
 @note 通知栏带有点击事件的特性，只有在iOS8+以上支持，iOS 8 or earlier的版本，此方法返回空
 */
+ (nullable id)categoryWithIdentifier:(NSString *)identifier actions:(nullable NSArray<TMFNotificationAction *> *)actions intentIdentifiers:(nullable NSArray<NSString *> *)intentIdentifiers options:(TMFNotificationCategoryOptions)options;

/**
 @brief 分类对象的标识
 */
@property (readonly, copy, nonatomic) NSString *identifier;

/**
 @brief 分类对象拥有的点击行为组
 */
@property (readonly, copy, nonatomic) NSArray<TMFNotificationAction *> *actions;

/**
 @brief 可用以Siri意图的标识组
 */
@property (nullable, readonly, copy, nonatomic) NSArray<NSString *> *intentIdentifiers;

/**
 @brief 分类的特性
 */
@property (readonly, nonatomic) TMFNotificationCategoryOptions options;

@end


/**
 @brief 注册通知支持的类型
 
 - TMFUserNotificationTypeNone: 无
 - TMFUserNotificationTypeBadge: 支持应用角标
 - TMFUserNotificationTypeSound: 支持铃声
 - TMFUserNotificationTypeAlert: 支持弹框
 - TMFUserNotificationTypeCarPlay: 支持CarPlay,iOS 10.0+
 - TMFUserNotificationTypeCriticalAlert: 支持紧急提醒播放声音, iOS 12.0+
 - TMFUserNotificationTypeProvidesAppNotificationSettings: 让系统在应用内通知设置中显示按钮, iOS 12.0+
 - TMFUserNotificationTypeProvisional: 能够将非中断通知临时发布到 Notification Center, iOS 12.0+
 - TMFUserNotificationTypeNewsstandContentAvailability: 支持 Newsstand, iOS 3.0–8.0
 */
typedef NS_OPTIONS(NSUInteger, TMFUserNotificationTypes) {
    TMFUserNotificationTypeNone = (0),
    TMFUserNotificationTypeBadge = (1 << 0),
    TMFUserNotificationTypeSound = (1 << 1),
    TMFUserNotificationTypeAlert = (1 << 2),
    TMFUserNotificationTypeCarPlay = (1 << 3),
    TMFUserNotificationTypeCriticalAlert = (1 << 4),
    TMFUserNotificationTypeProvidesAppNotificationSettings = (1 << 5),
    TMFUserNotificationTypeProvisional = (1 << 6),
    TMFUserNotificationTypeNewsstandContentAvailability = (1 << 3)
};

/**
 @brief 管理推送消息通知栏的样式和特性
 */
@interface TMFNotificationConfigure : NSObject

/**
 @brief 配置通知栏对象，主要是为了配置消息通知的样式和行为特性
 
 @param categories 通知栏中支持的分类集合
 @param types 注册通知的样式
 @return 配置对象
 */
+ (nullable instancetype)configureNotificationWithCategories:(nullable NSSet<TMFNotificationCategory *> *)categories types:(TMFUserNotificationTypes)types;

- (instancetype)init NS_UNAVAILABLE;
/**
 @brief 返回消息通知栏配置对象
 */
@property (readonly, nullable, strong, nonatomic) NSSet<TMFNotificationCategory *> *categories;


/**
 @brief 返回注册推送的样式类型
 */
@property (readonly, nonatomic) TMFUserNotificationTypes types;

/**
 @brief 默认的注册推送的样式类型
 */
@property (readonly, nonatomic) TMFUserNotificationTypes defaultTypes;

@end


@interface TMFPushTokenManager : NSObject

/**
 @brief 创建设备token的管理对象，用来管理token的绑定与解绑操作
 
 @return 设备token管理对象
 @note 此类的 APIs 调用都是以 Token 在推送服务上完成注册为前提
 */

+ (instancetype)defaultTokenManager;
- (instancetype)init NS_UNAVAILABLE;

/**
 @brief 返回当前设备token的字符串
 */
@property (copy, nonatomic, nullable, readonly) NSString *deviceTokenString;

@end


/**
 @brief 监控推送服务启动和设备token注册的一组方法
 */
@protocol TMFPushDelegate <NSObject>

@optional

/**
 @brief 收到推送消息后，应用被被拉起或者被唤醒后进入此回调
 
 @param notification 当前推送消息
 @param completionHandler 处理结果
 */
- (void)tmfPushDidReceiveRemoteNotification:(id)notification withCompletionHandler:(nullable void (^)(UIBackgroundFetchResult))completionHandler;

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0
/**
 @brief 处理iOS 10 UNUserNotification.framework的对应的方法
 
 @param center [UNUserNotificationCenter currentNotificationCenter]
 @param notification 通知对象
 @param completionHandler 回调对象，必须调用
 */
- (void)tmfPushUserNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(nullable UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler API_AVAILABLE(ios(10.0));

/**
 @brief 处理iOS 10 UNUserNotification.framework的对应的方法
 
 @param center [UNUserNotificationCenter currentNotificationCenter]
 @param response 用户对通知消息的响应对象
 @param completionHandler 回调对象，必须调用
 */
- (void)tmfPushUserNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(nullable UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler API_AVAILABLE(ios(10.0));

#endif

/**
 @brief 设备token注册推送服务的回调
 
 @param deviceToken 当前设备的token
 @param error 错误信息
 */
- (void)tmfPushDidRegisterDeviceToken:(nullable NSString *)deviceToken error:(nullable NSError *)error;

@end


extern NSString *const TMFPushRequestErrorDomain;

/**
 @brief 管理TMF推送服务的对象，负责注册推送权限、消息的管理、调试模式的开关设置等
 */
@interface TMFPush : NSObject

#pragma mark - 初始化相关

/**
 @brief 获取TMF推送管理的单例对象
 
 @return TMF推送对象
 */
+ (instancetype)defaultManager;
- (instancetype)init NS_UNAVAILABLE;

/**
 @brief 关于TMF推送SDK接口协议的对象
 */
@property (weak, nonatomic, nullable, readonly) id<TMFPushDelegate> delegate;

/**
 @brief TMF推送管理对象，管理推送的配置选项，例如，注册推送的样式
 */
@property (nullable, strong, nonatomic) TMFNotificationConfigure *notificationConfigure;

/**
 @brief 这个开关表明是否打印推送SDK的日志信息
 */
@property (assign, nonatomic, getter=isLogEnabled) BOOL logEnabled;

/**
 @brief 通过使用在推送官网注册的应用的信息，启动TMF推送服务
 
 @param delegate 回调对象
 @note 接口所需参数必须要正确填写，反之推送服务将不能正确为应用推送消息
 */
- (void)startPushWithDelegate:(nullable id<TMFPushDelegate>)delegate;

/**
 @brief 停止TMF推送服务
 @note 调用此方法将导致当前设备不再接受推送服务推送的消息.如果再次需要接收推送服务的消息推送，则必须需要再次调用startTMFPushWithAppID:appKey:delegate:方法重启TMF推送服务
 */
- (void)stopPushNotification;

/**
 @brief 查询设备通知权限是否被用户允许
 
 @param handler 查询结果的返回方法
 @note iOS 10 or later 回调是异步地执行
 */
- (void)deviceNotificationIsAllowed:(void (^)(BOOL isAllowed))handler;

/**
 @brief 查看SDK的版本
 
 @return sdk版本号
 */
- (NSString *)sdkVersion;

@end

NS_ASSUME_NONNULL_END

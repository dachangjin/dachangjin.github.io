/*
 * TccCompress.h
 *
 *  Created on: 2009-11-11
 *      Author: PalmSu
 */
//gzipѹ�����ѹ��
#include "TccString.h"

#if !defined(__TCC_USE_OS_BUILT_IN_COMPRESS__)

#if defined(__TccMac__) || defined(__TccAndroidNDK__)
#include <zlib.h>
#else
#include "../3rdparty/zlib/zlib.h"
#endif

#elif defined(__TccSymbian__)	// defined(__TCC_USE_OS_BUILT_IN_COMPRESS__) && defined(__TccSymbian__)

#include <e32base.h>
#include <f32file.h>
#include <ezbufman.h>

#define TCC_COMPRESS_BUF_SIZE 	1024

/**
Concrete class to manage the input and output buffers for compression and de-compression
@publishedAll
@released
*/
class CTccEZMemoryBufferManager : public MEZBufferManager{

public:
	TCCIMPORT CTccEZMemoryBufferManager(TccStr8 &aDes, const TccDesC8 &aSour);

	TCCIMPORT void InitializeL(CEZZStream &aZStream);
	TCCIMPORT void NeedInputL(CEZZStream &aZStream);
	TCCIMPORT void NeedOutputL(CEZZStream &aZStream);
	TCCIMPORT void FinalizeL(CEZZStream &aZStream);

protected:
	TBuf8<TCC_COMPRESS_BUF_SIZE>  	iCompressBuffer;
	TPtrC8							iSourBuffer;
	TccStr8&						iDesBuffer;
	TInt    						iSourBufferLen;
};

#else	// defined(__TCC_USE_OS_BUILT_IN_COMPRESS__) && unknown platform!

#error Please implement the compression using current OS API

#endif	// __TCC_USE_OS_BUILT_IN_COMPRESS__


class TccCompress{
public:
	TCCIMPORT static terror Compress(TccStr8 &aDes, const TccDesC8 &aSour);
	TCCIMPORT static terror Decompress(TccStr8 &aDes, const TccDesC8 &aSour);
};



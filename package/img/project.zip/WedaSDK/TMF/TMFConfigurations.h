
#ifndef TMFConfigurations_h
#define TMFConfigurations_h

#pragma mark - App Key

#define TMF_APP_KEY                     @"17af6c99ca6"
#define TMF_PID                         1001
#define TMF_CUSTOM_ID                   @"90c8a7f0-f102-11eb-a901-5b440eb32ed5"

#pragma mark - Shark

#define TMF_GW_HTTP_URL                 @"http://129.211.204.94:30013"
#define TMF_GW_TCP_HOST                 @"129.211.204.94"
#define TMF_GW_TCP_PORT                 30014
#define TMF_GW_SYM_ENC
#define TMF_GW_ASYM_ENC
#define TMF_GW_RKEY                     @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDAlziWKDUmUdkDq9r6lYrmX6/hlSZWpCVyPTFzaTBy/X4Jrv9/nOFq/43QR5NSvXTHjYwI5phviybZBHDaXVv5OYrxyjEAj6koZEVz65ZV7Oy6vSaTsyq9HVogzU2Vm14qUfiZbEMMttNMc6As8kZtzqWsuaTrC6+ObA3AJS9r0QIDAQAB"
#define TMF_GW_SKEY                     @"20118100eb36709cd6bc0a17353f1e249f072424bdc5d60cddf0e547a2c909bacd9ef190eba5b93dfc3606fef05e98fe97e36d95f81d531082f2fc987914def0"


#pragma mark - QAPM

#define TMF_QAPM_KEY                    @""
#define TMF_QAPM_URL                    @"http://172.16.1.66:30013"

#pragma mark - XM

#define TMF_XM_KEY                      @"17af6c99ca6204"
#define TMF_XM_URL                      @"http://172.16.1.66:30013"

#pragma mark - Live

#define TMF_LIVE_KEY                    @""
#define TMF_LIVE_LICENSE                @""


#endif


#ifndef __TCC_ERROR_CODE_H_DEFINE__
#define __TCC_ERROR_CODE_H_DEFINE__

#include "TccSys.h"

typedef ti32 terror;
typedef terror TccErrCode;


/**
System wide error code - no error.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrNone								0

/**
System wide error code - item not found.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrNotFound							-1 // Must remain set to -1

/**
System wide error code - an error that has no specific categorisation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrGeneral							-2

/**
System wide error code - indicates an operation that has been cancelled.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCancel							-3

/**
System wide error code - an attempt to allocate memory has failed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrNoMemory							-4

/**
System wide error code - some functionality is not supported in a given context.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
There may be many reasons for this; for example, a device may not support some specific behaviour.
*/
#define _TccErrNotSupported						-5

/**
System wide error code - an argument is out of range.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrArgument							-6

/**
System wide error code - a calculation has lost precision.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
This error arises when converting from an internal 96-bit real representation to a TReal32; the exponent of the 
 internal representation is so small that the 32-bit real cannot contain it.
*/
#define _TccErrTotalLossOfPrecision				-7

/**
System wide error code - an invalid handle has been passed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
A function involving a resource owned by a server or the kernel has specified an invalid handle.
*/
#define _TccErrBadHandle						-8

/**
System wide error code - indicates an overflow in some operation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
In the context of mathematical or time/date functions, indicates a calculation
that has produced arithmetic overflow exceeding the bounds allowed by the representation.
In the context of data transfer, indicates that a buffer has over-filled without being emptied soon enough.
*/
#define _TccErrOverflow							-9

/**
System wide error code - indicates an underflow in some operation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
In the context of mathematical or time/date functions, indicates a calculation that has produced a result smaller 
than the smallest magnitude of a finite number allowed by the representation.
In the context of data transfer, indicates that a buffer was under-filled when data was required.
*/
#define _TccErrUnderflow						-10

/**
System wide error code - an object already exists.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
An object of some name/type is to be created, but an object of that name/type already exists.
*/
#define _TccErrAlreadyExists					-11

/**
System wide error code - in the context of file operations, a path was not found.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrPathNotFound						-12

/**
System wide error code - a handle refers to a thread that has died.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDied								-13

/**
System wide error code - a requested resource is already in exclusive use.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrInUse							-14

/**
System wide error code - a client/server send/receive operation cannot run, because the server has terminated.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrServerTerminated					-15

/**
System wide error code - a client/server send/receive operation cannot run, because the server is busy handling another request.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrServerBusy						-16

/**
System wide error code - indicates that an operation is complete, successfully or otherwise.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
This code may be used to indicate that some follow on operation can take place. It does not necessarily indicate an error condition.
*/
#define _TccErrCompletion						-17

/**
System wide error code - indicates that a device required by an i/o operation is not ready to start operations.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
A common reason for returning this code is because a device has not been initialised, or has no power.
*/
#define _TccErrNotReady							-18

/**
System wide error code - a device is of unknown type.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrUnknown							-19

/**
System wide error code - indicates that some media is not formatted properly, or links between sections of it have been corrupted.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCorrupt							-20

/**
System wide error code - access to a file is denied, because the permissions on the file do not allow the requested operation to be performed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrAccessDenied						-21

/**
System wide error code - an operation cannot be performed, because the part of the file to be read or written is locked.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrLocked							-22

/**
System wide error code - during a file write operation, not all the data could be written.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrWrite							-23

/**
System wide error code - a volume which was to be used for a file system operation has been dismounted.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDisMounted						-24

/**
System wide error code - indicates that end of file has been reached.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
Note that RFile::Read() is a higher-level interface. When the end of the file is reached, 
it returns zero bytes in the destination descriptor, and a KErrNone return value. KErrEof is not used for this purpose; 
other error conditions are returned only if some other error condition was indicated on the file.
*/
#define _TccErrEof								-25

/**
System wide error code - a write operation cannot complete, because the disk is full.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDiskFull							-26

/**
System wide error code - a driver DLL is of the wrong type.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrBadDriver						-27

/**
System wide error code - a file name or other object name does not conform to the required syntax.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrBadName							-28

/**
System wide error code - a communication line has failed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCommsLineFail					-29

/**
System wide error code - a frame error has occurred in a communications operation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCommsFrame						-30

/**
System wide error code - an overrun has been detected by a communications driver.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCommsOverrun						-31

/**
System wide error code - a parity error has occurred in communications.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCommsParity						-32

/**
System wide error code - an operation has timed out.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrTimedOut							-33

/**
System wide error code - a session could not connect.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCouldNotConnect					-34

/**
System wide error code - a session could not disconnect.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCouldNotDisconnect				-35

/**
System wide error code - a function could not be executed because the required session was disconnected.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDisconnected						-36

/**
System wide error code - a library entry point was not of the required type.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrBadLibraryEntryPoint				-37

/**
System wide error code - a non-descriptor parameter was passed by a client interface, when a server expected a descriptor.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrBadDescriptor					-38

/**
System wide error code - an operation has been aborted.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrAbort							-39

/**
System wide error code - a number was too big.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrTooBig							-40

/**
System wide error code - a divide-by-zero operation has been attempted.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDivideByZero						-41	// Added by AnnW

/**
System wide error code - insufficient power was available to complete an operation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrBadPower							-42

/**
System wide error code - an operation on a directory has failed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrDirFull							-43

/**
System wide error code - an operation cannot be performed because the necessary hardware is not available.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrHardwareNotAvailable				-44

/**
System wide error code - the completion status when an outstanding client/server message is completed because a shared session has been closed.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrSessionClosed					-45

/**
System wide error code - an operation cannot be performed due to a potential security violation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrPermissionDenied					-46

/**
System wide error code - a requested extension function is not supported by the object concerned.
*/
#define _TccErrExtensionNotSupported			-47

/**
System wide error code - a break has occurred in a communications operation.
A system wide error code indicates an error in the environment, or in user input from which a program may recover.
*/
#define _TccErrCommsBreak						-48


#define _TccErr									-32000
#define _TccErrConvUtf8Value					-32001
#define _TccErrConvUtf16Value					-32002
#define _TccErrWouldBlock						-32003 //��Ҫ�첽����
#define _TccErrNullBuf							-32004 //������


#define _TccErrFileOpen							-32005 //��һ���ļ�ʧ��
#define _TccErrFileRead							-32006 //�ļ���ȡʧ��
#define _TccErrFileWrite						-32007 //�ļ�д��ʧ��
//#define _TccErrFileEof							-32008 //�ļ��Ѿ�����
#define _TccErrFileFlush						-32009 //�ļ�Flushʧ��
#define _TccErrFileSeek							-32010 //�ļ�Seekʧ��


#define _TccErrLocalSyncGeneral					-32100 ///< LocalSync���ֵ����д���Ŀ�ʼ��ʶ
#define _TccErrTagFileNotExist					-32101 ///< ָ��·����Tag�ļ�������
#define _TccErrTagFileCorrupt					-32102 ///< ��ȡTag�ļ�,�����ļ���ʽ�Ѿ���
#define _TccErrTagFileValidate					-32103 ///< У��ʧ��
#define _TccErrTagFileEncrypt					-32104 ///< ����ʧ��
#define _TccErrTagFileDecrypt					-32105 ///< ����ʧ��
#define _TccErrTagFileDiskFull					_TccErrDiskFull //-32106 ///< ���̿ռ䲻��


#define _TccErrSyncml							-32200
#define _TccErrWbxmlInvalid						-32201
#define _TccErrWbxmlInvalidValue				-32202
#define _TccErrWbxmlInvalidVersion				-32203
#define _TccErrWbxmlInvalidCharset				-32204
#define _TccErrWbxmlInvalidPubilcID				-32205
#define _TccErrWbxmlTagStackOverFlow			-32206
#define _TccErrSyncmlNotFound					-32211
#define _TccErrDataServerMapFormat				-32212 //���ش洢�ķ�������¼�����ļ���ʽ�汾̫��or���ƻ�or������
#define _TccErrDataServerMapPopList				-32213 //map�ļ��߼�������...
#define _TccErrSyncTargetMismatch				-32214 //ָ��Ŀ���Ҳ���, ������syncmlЭ���߼�����
#define _TccErrSyncInvalidCredentials			-32215 //��֤ʧ��
#define _TccErrSyncAlertFail					-32217 //��֤ʧ��,���������ݿ���д��
#define _TccErrSyncLargeObjectSizeMismatch		-32218 //�����size��ƥ��
#define _TccErrSyncLargeObjectError				-32219 //�������ճ���,��������ʧ
#define _TccErrSyncDeviceFull					-32220 //�������洢�ռ�����
#define _TccErrSyncLogic						-32221 //������syncmlЭ���߼�����
//#define _TccErrSyncMapFileInvalid				-32222 //map�ļ������ˡ�
//#define _TccErrSyncMapFileWriteFail			-32223 //map�ļ�д��ʧ�ܡ�
//#define _TccErrSyncConfigure					-32224 //���ô��󣨿��ַ�֮�ࣩ��assert�����,������
#define _TccErrSyncDataSourceExist				-32225 //����Դ�Ѵ���
#define _TccErrSyncTransportEncrypt				-32226//���ܳ���
#define _TccErrSyncTransportDecrypt				-32227//���ܳ���
//����ʱ�ڵĴ���ֵ,�������
#define _TccErrSyncReadRecall					-32228	// ��ȡDB����
#define _TccErrSyncWriteRecall					-32229	// д��DB����

#define _TccErrSyncCancel						-32230	//��ֹ��ͬ��


#define _TccErrDataGetEof						-33001 //ö�����ݵ�����
#define _TccErrDataNotFound						-33002 //�Ҳ���oidָ�������
#define _TccErrDataCommandFailed				-33003 //����ִ��ʧ��
#define _TccErrDataCommandNotImpl				-33004 //������ͻ���ûʵ��
#define _TccErrDataInvalid						-33005 //vobject ��ʽ����
#define _TccErrDataBaseFull						-33006 //���ݿ�����
#define _TccErrDataAlreadyExists				-33007


#define _TccErrSqlBase							-36000 
#define _TccErrSqlError							-36001 // SQL error or missing database
#define _TccErrSqlInternal						-36002 // Internal logic error in SQLite
#define _TccErrSqlPermssionDenied				-36003 // Access permission denied
#define _TccErrSqlAbort							-36004 // Callback routine requested an abort
#define _TccErrSqlBusy							-36005 // The database file is locked
#define _TccErrSqlLocked						-36006 // A table in the database is locked
//#define SQLITE_NOMEM        7   /* A malloc() failed */ ���ת�� _TccErrNoMemory
#define _TccErrSqlReadOnly						-36008 // Attempt to write a readonly database
#define _TccErrSqlInterrupt						-36009 // Operation terminated by sqlite3_interrupt()
#define _TccErrSqlIoErr							-36010 // Some kind of disk I/O error occurred
#define _TccErrSqlCorrupt						-36011 // The database disk image is malformed
#define _TccErrSqlNotFound						-36012 // NOT USED. Table or record not found
#define _TccErrSqlFull							-36013 // Insertion failed because database is full
#define _TccErrSqlCantopen						-36014 // Unable to open the database file
#define _TccErrSqlProtocol						-36015 // NOT USED. Database lock protocol error
#define _TccErrSqlEmpty							-36016 // Database is empty
#define _TccErrSqlSchema						-36017   // The database schema changed
#define _TccErrSqlTooBig						-36018   // String or BLOB exceeds size limit
#define _TccErrSqlConstraint					-36019   // Abort due to constraint violation
#define _TccErrSqlMismatch						-36020   // Data type mismatch
#define _TccErrSqlMisuse						-36021   // Library used incorrectly
#define _TccErrSqlNOLFS							-36022   // Uses OS features not supported on host 
#define _TccErrSqlAuth							-36023   // Authorization denied 
#define _TccErrSqlFormat						-36024   // Auxiliary database format error
#define _TccErrSqlRange							-36025   // 2nd parameter to sqlite3_bind out of range
#define _TccErrSqlNotADb						-36026   // File opened that is not a database file 
#define _TccErrSqlRow							-36100  // sqlite3_step() has another row ready 
#define _TccErrSqlDone							-36101  // sqlite3_step() has finished executing




#endif //__TCC_ERROR_CODE_H_DEFINE__




//����,����Ѿ����������,���쳣
template <typename T, typename _traits>
void TccTreeSet<T, _traits>::InsertL(const T& object){
	TreeSetNode* p = new TreeSetNode(object);
	_TccLeaveIfNull(p);
	TreeSet::insert(TreeSet::iRoot, p);
}

//����,����Ѿ����������,�����쳣
template <typename T, typename _traits>
terror TccTreeSet<T, _traits>::Insert(const T& object){
	TreeSetNode* p = new TreeSetNode(object);		
	if(p == NULL) return _TccErrNoMemory;
	TreeSet::insert(TreeSet::iRoot, p);
	return _TccErrNone;
}



#if 0
//����һ��Ԫ���Ƿ��Ѵ���
template <typename T, typename _traits>
tbool TccTreeSet<T, _traits>::Exist(const T& key){
	return (tbool)(NULL != TreeSet::find(key));
}
//����һ��Ԫ��
template <typename T, typename _traits>
void TccTreeSet<T, _traits>::Erase(const T& key){
	tbool isfind = tfalse;
	T data_result;
	TreeSet::erase(TreeSet::iRoot, key, data_result, isfind);
}

//Ĩ��һ��Ԫ��,��ʹ��Traits��delete������������
template <typename T, typename _traits>
void TccTreeSet<T, _traits>::EraseAndDestroy(const T& key){
	tbool isfind = tfalse;
	T data_result;
	TreeSet::erase(TreeSet::iRoot, key, data_result, isfind);
	if(isfind){
		_traits::DeleteHandle(data_result);
	}
}
//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ��ָ��,�������򷵻�NULL
template <typename T, typename _traits>
T* TccTreeSet<T, _traits>::Find(const T& key) const {
	TreeSetNode* search = TreeSet::find(key);
	if(search == NULL){
		return NULL;
	}
	return &(search->iElement);
}

#endif

//����һ��Ԫ��,�����Ԫ�ش��ڵĻ�,����true,��Ԫ��
template <typename T, typename _traits>
tbool TccTreeSet<T, _traits>::Erase(const T& key, T& object){
	tbool isfind = tfalse;
	TreeSet::erase(TreeSet::iRoot, key, object, isfind);
	return isfind;
}

//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,�����������쳣
template <typename T, typename _traits>
T& TccTreeSet<T, _traits>::FindL(const T& key) const {
	TreeSetNode* search = TreeSet::find(key);
	if(search == NULL){
		_TccLeave(_TccErrNotFound);
	}
	return search->iElement;
}

//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,����������һ����Ԫ��,������Ԥ���ɵ�ֵ����
template <typename T, typename _traits>
T& TccTreeSet<T, _traits>::FindExL(const T& key){
	TreeSetNode* search = TreeSet::find(key);
	if(search == NULL){
		search = new TreeSetNode(key);
		_TccLeaveIfNull(search);
		TreeSet::insert(TreeSet::iRoot, search);
	}
	return search->iElement;
}


//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,����������һ����Ԫ��,������Ԥ���ɵ�ֵ����
template <typename T, typename _traits>
T& TccTreeSet<T, _traits>::operator[](const T& key){
	return FindExL(key);
}

//----------------------------------------------------------------------------------------------------------
template <typename KT, typename VT, typename _KTraits, typename _VTraits>
void TccTreeMap<KT, VT, _KTraits, _VTraits>::InsertL(const KT& key, const VT& element){
	TreeMapNode* p = new TreeMapNode();
	_TccLeaveIfNull(p);
	p->iElement.iFirst = key;
	p->iElement.iSecond = element;
	TreeMap::insert(TreeMap::iRoot, p); //TreeMap
}

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
terror TccTreeMap<KT, VT, _KTraits, _VTraits>::Insert(const KT& key, const VT& element){
	TreeMapNode* p = new TreeMapNode();
	if(p == NULL) return _TccErrNoMemory;
	p->iElement.iFirst = key;
	p->iElement.iSecond = element;
	TreeMap::insert(TreeMap::iRoot, p);
	return _TccErrNone;
}

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
tbool TccTreeMap<KT, VT, _KTraits, _VTraits>::Erase(const KT& key, VT& object){
	TccCntrPair<KT, VT> data_result;
	tbool isfind = tfalse;
	TreeMap::erase(TreeMap::iRoot, key, data_result, isfind);
	if(isfind){
		_KTraits::DeleteHandle(data_result.iFirst); //�ǵ�delete�Ǹ�key...
		object = data_result.iSecond;
	}
	return isfind;
}


#if 0
template <typename KT, typename VT, typename _KTraits, typename _VTraits>
tbool TccTreeMap<KT, VT, _KTraits, _VTraits>::Exist(const KT& key){
	return (tbool)(NULL != TreeMap::find(key));
}


template <typename KT, typename VT, typename _KTraits, typename _VTraits>
void TccTreeMap<KT, VT, _KTraits, _VTraits>::EraseAndDestroy(const KT& key){
	tbool isfind = tfalse;
	TccCntrPair<KT, VT> data_result;
	TreeMap::erase(TreeMap::iRoot, key, data_result, isfind);
	if(isfind){
		_KTraits::DeleteHandle(data_result.iFirst);
		_VTraits::DeleteHandle(data_result.iSecond);
	}
}

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
void TccTreeMap<KT, VT, _KTraits, _VTraits>::EraseFix(const KT& key){
	tbool isfind = tfalse;
	TccCntrPair<KT, VT> data_result;
	TreeMap::erase(TreeMap::iRoot, key, data_result, isfind);
}


template <typename KT, typename VT, typename _KTraits, typename _VTraits>
VT* TccTreeMap<KT, VT, _KTraits, _VTraits>::Find(const KT& key) const {
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		return NULL;
	}
	return &(search->iElement.iSecond);
}
#endif

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
void TccTreeMap<KT, VT, _KTraits, _VTraits>::Find(const KT& key, TreeMapIterator& aIt) const {
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		aIt.Set(NULL);
	}
	else{
		aIt.SetOne(search);
	}
}

//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,�����������쳣
template <typename KT, typename VT, typename _KTraits, typename _VTraits>
VT& TccTreeMap<KT, VT, _KTraits, _VTraits>::FindL(const KT& key) const {
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		_TccLeave(_TccErrNotFound);
	}
	return search->iElement.iSecond;
}

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
VT& TccTreeMap<KT, VT, _KTraits, _VTraits>::FindExL(const KT& key){
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		search = new TreeMapNode();
		_TccLeaveIfNull(search);
		search->iElement.iFirst = key;
		TreeMap::insert(TreeMap::iRoot, search);
	}
	return search->iElement.iSecond;
}

template <typename KT, typename VT, typename _KTraits, typename _VTraits>
VT& TccTreeMap<KT, VT, _KTraits, _VTraits>::operator[](const KT& key){
	return FindExL(key);
}


//----------------------------------------------------------------------------------------------



#if defined(__TccSymbian__)
template <typename _HBufC, typename _TDesC, typename _traits>
void TccDesTreeSet<_HBufC, _TDesC, _traits>::InsertL(const _TDesC& object){
	_HBufC objectCopy = object.AllocLC();
	TreeSetNode* p = new TreeSetNode(objectCopy);
	_TccLeaveIfNull(p);
	CleanupStack::Pop(objectCopy);
	TreeSet::insert(TreeSet::iRoot, p);
}
//����һ��Ԫ���Ƿ��Ѵ���
template <typename _HBufC, typename _TDesC, typename _traits>
tbool TccDesTreeSet<_HBufC, _TDesC, _traits>::Exist(const _TDesC& key){
	return (tbool)(NULL != TreeSet::find(key));
}
//����һ��Ԫ��
template <typename _HBufC, typename _TDesC, typename _traits>
void TccDesTreeSet<_HBufC, _TDesC, _traits>::Erase(const _TDesC& key){
	tbool isfind = tfalse;
	_HBufC data_result = NULL;
	TreeSet::erase(TreeSet::iRoot, key, data_result, isfind);
	_traits::DeleteHandle(data_result);
}
//����һ��Ԫ��,�����Ԫ�ش��ڵĻ�,����true,��Ԫ��
template <typename _HBufC, typename _TDesC, typename _traits>
tbool TccDesTreeSet<_HBufC, _TDesC, _traits>::Erase(const _TDesC& key, _HBufC& object){
	tbool isfind = tfalse;
	TreeSet::erase(TreeSet::iRoot, key, object, isfind);
	return isfind;
}
//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,�����������쳣
template <typename _HBufC, typename _TDesC, typename _traits>
_HBufC& TccDesTreeSet<_HBufC, _TDesC, _traits>::FindL(const _TDesC& key) const {
	TreeSetNode* search = TreeSet::find(key);
	if(search == NULL){
		_TccLeave(_TccErrNotFound);
	}
	return search->iElement;
}
//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ��ָ��,�������򷵻�NULL
template <typename _HBufC, typename _TDesC, typename _traits>
_HBufC* TccDesTreeSet<_HBufC, _TDesC, _traits>::Find(const _TDesC& key) const {
	TreeSetNode* search = TreeSet::find(key);
	if(search == NULL){
		return NULL;
	}
	return &(search->iElement);
}
//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,����������һ����Ԫ��,������Ԥ���ɵ�ֵ����
template <typename _HBufC, typename _TDesC, typename _traits>
_HBufC& TccDesTreeSet<_HBufC, _TDesC, _traits>::FindExL(const _TDesC& object){
	TreeSetNode* search = TreeSet::find(object);
	if(search == NULL){
		_HBufC objectCopy = object.AllocLC();
		TreeSetNode* search = new TreeSetNode(objectCopy);
		_TccLeaveIfNull(search);
		CleanupStack::Pop(objectCopy);
		TreeSet::insert(TreeSet::iRoot, search);
	}
	return search->iElement;
}

//------------------------

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
void TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::InsertL(const _TDesC& key, const VT& element){

	_HBufC keyCopy = key.AllocLC();
	TreeMapNode* p = new TreeMapNode();
	_TccLeaveIfNull(p);
	CleanupStack::Pop(keyCopy);

	p->iElement.iFirst = keyCopy;
	p->iElement.iSecond = element;
	TreeMap::insert(TreeMap::iRoot, p);

}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
tbool TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::Exist(const _TDesC& key){
	return (tbool)(NULL != TreeMap::find(key));
}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
void TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::Erase(const _TDesC& key){
	tbool isfind = tfalse;
	TccCntrPair<_HBufC, VT> data_result;
	TreeMap::erase(TreeMap::iRoot, key, data_result, isfind);
	if(isfind){
		_KTraits::DeleteHandle(data_result.iFirst);
		_VTraits::DeleteHandle(data_result.iSecond);
	}
}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
tbool TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::Erase(const _TDesC& key, VT& object){
	TccCntrPair<_HBufC, VT> data_result;
	tbool isfind = tfalse;
	TreeMap::erase(TreeMap::iRoot, key, data_result, isfind);
	if(isfind){
		_KTraits::DeleteHandle(data_result.iFirst);
		object = data_result.iSecond;
	}
	return isfind;
}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
VT* TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::Find(const _TDesC& key){
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		return NULL;
	}
	return &(search->iElement.iSecond);
}

//����һ��ԭ��,��������򷵻ظ�Ԫ�ص�ֵ������,�����������쳣
template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
VT& TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::FindL(const _TDesC& key){
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		_TccLeave(_TccErrNotFound);
	}
	return search->iElement.iSecond;
}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
VT& TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::FindExL(const _TDesC& key){
	TreeMapNode* search = TreeMap::find(key);
	if(search == NULL){
		_HBufC keyCopy = key.AllocLC();
		search = new TreeMapNode();
		_TccLeaveIfNull(search);
		CleanupStack::Pop(keyCopy);
		search->iElement.iFirst = keyCopy;		
		TreeMap::insert(TreeMap::iRoot, search);
	}
	return search->iElement.iSecond;
}

template <typename VT, typename _VTraits, typename _HBufC, typename _TDesC, typename _KTraits>
VT& TccDesTreeMap<VT, _VTraits, _HBufC, _TDesC, _KTraits>::operator[](const _TDesC& key){
	return FindExL(key);
}


#endif



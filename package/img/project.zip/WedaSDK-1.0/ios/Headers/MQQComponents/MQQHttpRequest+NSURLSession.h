//
//  MQQHttpRequest+NSURLSession.h
//  MQQSecure
//
//  Created by klaudz on 7/24/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import "MQQHttpRequest+Private.h"

@interface MQQHttpRequest (NSURLSession) <NSURLSessionDelegate, NSURLSessionTaskDelegate, NSURLSessionDataDelegate, NSURLSessionDownloadDelegate>

- (void)SS_startConnect;
- (void)SS_clearAll;

- (void)SS_resume;
- (void)SS_suspend;

- (BOOL)SS_prepareForDownloadWithError:(NSError **)error;
- (void)SS_clearDownloadingFiles;

@end

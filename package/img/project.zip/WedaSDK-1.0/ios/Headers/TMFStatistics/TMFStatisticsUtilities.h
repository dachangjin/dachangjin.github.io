//
//  TMFStatisticsUtilities.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/1.
//  Copyright © 2020 Tencent. All rights reserved.
//

#ifndef TMFStatisticsUtilities_h
#define TMFStatisticsUtilities_h

/**
 @brief 上报策略
*/
typedef NS_OPTIONS(NSInteger, TMFStatisticsReporterStrategy) {
    TMFStatisticsReporterStrategyBatch              = 1 << 0,      ///<  批量上报
    TMFStatisticsReporterStrategyRealTime           = 1 << 1,      ///<  实时上报
    TMFStatisticsReporterStrategyTimer              = 1 << 2,      ///<  周期上报
    TMFStatisticsReporterStrategyIntelligence       = 1 << 3,      ///<  智能上报
};

typedef NSInteger TMFStatisticsReporterStrategyInterval;

#endif /* TMFStatisticsUtilities_h */

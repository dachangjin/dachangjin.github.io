//
//  MQQHTTPSocketRequest.h
//  MQQHTTPURLSession
//
//  Created by hauzhong on 2019/2/15.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#define HTTPSocketHTTPVersion @"HTTP/1.1"

// 请求类型
typedef NS_ENUM(NSInteger, MQQHTTPSocketRequestMethod) {
    MQQHTTPSocketRequestMethodHTTP   = 0, // HTTP请求
    MQQHTTPSocketRequestMethodHTTPS  = 1, // HTTPS请求
};

// 标准HTTP响应码，此处定义仅用于状态判断
typedef NS_ENUM(NSInteger, MQQHTTPSocketResponseCode) {
    MQQHTTPSocketResponseCodeOK                  = 200, //
    MQQHTTPSocketResponseCodePartialOK           = 206, //
    MQQHTTPSocketResponseCodePermanentlyMoved    = 301, //
    MQQHTTPSocketResponseCodeTemporarilyMoved    = 302, //
    MQQHTTPSocketResponseCodeBadRequest          = 400, //
    MQQHTTPSocketResponseCodeTimeout             = 408, //
};

// 响应传输类型
typedef NS_ENUM(NSInteger, MQQHTTPSocketResponseType) {
    MQQHTTPSocketResponseTypeNormal     = 0, // 整体响应
    MQQHTTPSocketResponseTypeChunked    = 1, // 分块响应
};

@protocol MQQHTTPSocketRequestDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface MQQHTTPSocketRequest : NSObject

/* timeout for request. default is 15s. */
@property (nonatomic, assign) NSTimeInterval timeoutIntervalForRequest;

@property (nonatomic, copy, nullable) NSData *HTTPBody;

@property (nonatomic, copy, nullable) NSString *HTTPPath;
@property (nonatomic, copy, nullable) NSString *HTTPQuery;
@property (nonatomic, copy, nullable) NSString *HTTPMethod;

@property (nonatomic, copy, nullable) NSDictionary *requestHeaders;
@property (nonatomic, retain, readonly) NSMutableDictionary *responseHeaders;

@property (nonatomic, retain, nullable) NSError *error;
@property (nonatomic, assign) NSInteger responseCode;
@property (nonatomic, assign, nullable) id<MQQHTTPSocketRequestDelegate> delegate;

@property (nonatomic, assign) BOOL optimizedInterface;

- (void)requestWithHost:(NSString *)host port:(NSInteger)port method:(MQQHTTPSocketRequestMethod)method;
- (void)requestWithHost:(NSString *)host port:(NSInteger)port method:(MQQHTTPSocketRequestMethod)method viaInterface:(nullable NSString *)interface;

- (void)cancelRequest;

@end

@protocol MQQHTTPSocketRequestDelegate <NSObject>

@optional
- (void)request:(MQQHTTPSocketRequest *)httpSocketRequest didDisconnectWithError:(NSError *)error;
- (void)request:(MQQHTTPSocketRequest *)httpSocketRequest didConnectToHost:(NSString *)host;
- (void)request:(MQQHTTPSocketRequest *)httpSocketRequest didReceiveData:(NSData *)receivedData;

@end

NS_ASSUME_NONNULL_END

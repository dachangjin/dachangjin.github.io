

#ifndef __TCC_CONFIG_H_DEFINE__
#define __TCC_CONFIG_H_DEFINE__

// DEBUG��
//#define __TCCDEBUG__	// ����debug

// �Ƿ񵼳����ţ��������ɶ�̬��
//#define __TCC_ENABLE_BUILD_DL__

/**
 * @deprecated
 */
#if defined(__TCCDEBUG__) && !defined(__USE_LOG__)
#define __USE_LOG__				// ����debug log
#endif
/**
 * @recommend
 */
#if defined(__TCCDEBUG__) && !defined(__USE_TRACER__)
#define __USE_TRACER__			// ����debug trace
#endif

#ifdef __SYMBIAN32__
#define __TCC_USE_OS_BUILT_IN_COMPRESS__
#endif

#ifdef __TCC_USE_OS_BUILT_IN_API__

#ifdef __SYMBIAN32__
#ifndef __TCC_USE_OS_BUILT_IN_CRC__
#define __TCC_USE_OS_BUILT_IN_CRC__
#endif

//#ifndef __TCC_USE_OS_BUILT_IN_CRYPT__
//#define __TCC_USE_OS_BUILT_IN_CRYPT__
//#endif

#ifndef __TCC_USE_OS_BUILT_IN_COMPRESS__
#define __TCC_USE_OS_BUILT_IN_COMPRESS__
#endif

#endif	// __SYMBIAN32__

#endif	// __TCC_USE_OS_BUILT_IN_API__

//#define __REPORT_MEMORY__
//#define __DISABLE_SSL_CRYPT_MODE__ //�����˺��ʾ��ʹ��ssl���ܴ��ͷ�ʽ
//#define __NO_WLAN__	//��֧��WLAN //add by palmsu 20091103

#if !defined(__SYMBIAN32__) && defined(_WIN32) && ! defined(_WIN32_WCE)
#define __TCC_DEVELOP__ //tcc����״̬ģʽ
#endif

#endif /* __TCC_CONFIG_H_DEFINE__ */

#ifndef __TCC_SIMPLE_DEQUE_H_DEFINED__
#define __TCC_SIMPLE_DEQUE_H_DEFINED__

#include "TccBase.h"
#include "TccContainerBase.inl.h"

template <typename T, typename _traits = TccTraits<T> >
class TccDeque{

protected:
	class Node {
	public:
		T iElement;
		Node* iNext;
		Node() : iNext(NULL){}
		Node(const T& object) : iElement(object), iNext(NULL){}
		~Node(){}
	};

	Node* iRootBack; //���Ľڵ�
	Node* iRootFront; //��ǰ�Ľڵ�
	ti32 iSize;

public:
	class Iterator{
		friend class TccDeque;
	protected:
		Node* iCurr;
	public:
		Iterator(Node* p = NULL) : iCurr(p){}
		Iterator(const Iterator& it){
			*this = it;
		}
		Iterator& operator=(const Iterator& it){
			iCurr = it.iCurr;
			return *this;
		}
		T& operator*(){
			TccAssert(NULL != iCurr);
			return iCurr->iElement;
		}
		T* operator->(){
			TccAssert(NULL != iCurr);
			return &(iCurr->iElement);
		}

		const T& operator*() const {
			TccAssert(NULL != iCurr);
			return iCurr->iElement;
		}
		const T* operator->() const {
			TccAssert(NULL != iCurr);
			return &(iCurr->iElement);
		}

		Iterator& operator++(){ //++xx
			if(iCurr != NULL) iCurr = iCurr->iNext;
			return *this;
		}
		Iterator operator++(int){ //xx++
			Iterator it = (*this);
			++(*this);
			return it;
		}
		tbool operator!=(const Iterator& it){
			return (tbool)(iCurr != it.iCurr);
		}
		tbool isEnd() const {return (tbool)(iCurr == NULL);}
	};

	TccDeque();
	~TccDeque();

	inline ti32 Size() const;
	Iterator Begin() const;
	void Begin(Iterator& it) const;
	Iterator End() const;


	void PushFrontL(const T& element);
	terror PushFront(const T& element);
	
	void PushBackL(const T& element);
	terror PushBack(const T& element);
	
	inline T& Back();
	inline T& Top();

	inline const T& Back() const;
	inline const T& Top() const;

	void Pop();
	void PopAndDestroy();

	void Clear();
	inline tbool Empty() const;
	void Destroy();

	void Sort();

	void Merge(TccDeque<T, _traits>& rhs);
	void Swap(TccDeque<T, _traits>& rhs);

	T& At(ti32 aPos);
	const T& At(ti32 aPos) const;

	inline Node* PopNode(); //�����׽ڵ�
	inline void AddNodeFront(Node* p); //������һ��Deque�������Ľڵ㣬�ӵ�ͷ
	inline void AddNodeBack(Node* p); //������һ��Deque�������Ľڵ㣬�ӵ�β

};


#include "TccDeque.inl.h"

#endif //__TCC_SIMPLE_DEQUE_H_DEFINED__





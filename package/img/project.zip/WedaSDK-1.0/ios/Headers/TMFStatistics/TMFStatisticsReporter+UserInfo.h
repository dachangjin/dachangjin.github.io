//
//  TMFStatisticsReporter+UserInfo.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsReporter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsReporter (UserInfo)

- (void)et5_CUSTOM_USER_ID_EventWithHybridH5:(BOOL)hybridH5 labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

//
//  TMFWKProtocolWorker.h
//  QBWebView
//
//  Created by ozonelmy on 16/6/29.
//  Copyright © 2017 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 *  根据返回的URL，业务需要自己判断该请求是否需要自己处理https认证
 *  如果需要自己处理，处理成功后，返回YES
 *  如果不属于自己的业务，不需要处理，务必返回NO，走系统默认流程，否则该请求无法正常处理
 *
 */

@protocol QBWKAuthenticationDelegate <NSObject>
@optional
/*
 @protocol NSURLConnectionDelegate <NSObject>
 @optional
 - (void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge;
 */
- (BOOL) qbProxyProtocolWillSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
                                                           forURL:(NSURL *)url;

/*
 @protocol NSURLSessionDelegate <NSObject>
 @optional
 - (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
 completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * _Nullable credential))completionHandler;
 */
- (BOOL) qbProxyProtocolDidReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
                          completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler
                                     forURL:(NSURL *)url;
@end


@interface TMFWKProtocolWorker : NSObject

@property (nonatomic, weak) NSURLProtocol *protocol;
/*
 *  增加https认证代理
 *
 */
+ (void)addAuthenticationDelegate:(nonnull id<QBWKAuthenticationDelegate>)delegate;

/*
 *  删除https认证代理
 *  delegate注册的时候以弱引用形式保存在tbs侧，当业务场景退出的时候，需要保证delegate释放或者主动调用remove进行注销
 *  如果delegate一直保留不释放，也没有主动调用remove注销，后续其它业务的HTTPS认证请求都会走入你注册的回调，存在一定风险
 */
+ (void)removeAuthenticationDelegate:(nonnull id<QBWKAuthenticationDelegate>)delegate;

/*
 *  告知protocol是否能处理此request
 *  若此方法返回值为YES，即使这个request并不是QBWebView发起的，TMFWKProxyURLProtocol仍然会处理对应的request。
 *  若此方法返回值为NO，那无论此request是否是QBWebView发起，TMFWKProxyURLProtocol仍然会不会进行处理。
 *  默认情况下，TMFWKProxyURLProtocol只处理由QBSDK发起的请求，即返回isQBWebViewReques的值。
 *  注意：若用户实现老方法[TMFWKProtocolWorker qbProxyProtocolCanInitWithRequest:]，则QBSDK优先调用老方法，不会调用此方法
 *  @param request:需要进行判断的request
 *  @param isQBWebViewReques:指出当前request是否是QBSDK发起的请求。
 */
+ (BOOL) qbProxyProtocolCanInitWithRequest:(NSURLRequest *)request isQBWebViewRequest:(BOOL)isQBWebViewRequest;

/*
 *  这个方法已经废弃。
 *  请改用qbProxyProtocolCanInitWithRequest:(NSURLRequest *)request isQBWebViewRequest:(BOOL)isQBWebViewReques方法。
 */
+ (BOOL) qbProxyProtocolCanInitWithRequest:(NSURLRequest *)request;

/*
 *  标准化request
 *  默认情况下直接返回request
 *  @param request:需要进行判断的request
 *  @result:标准化之后的request
 */
+ (NSURLRequest *)qbProxyCanonicalRequestForRequest:(NSURLRequest *)request;

/*
 *  检测两个request用于缓存目的时是否应该看做是一样的
 *  默认情况下TMFWKProtocolWorker没有实现这个方法，用户如果需要可以自行实现。
 *  @param a:需要与b进行对比的request
 *  @param b:需要与a进行对比的request
 *  @result:两个request是否应该看做一样
 */
+ (BOOL)qbProxyRequestIsCacheEquivalent:(NSURLRequest *)a toRequest:(NSURLRequest *)b;

/*
 *  protocol正式发起请求之前询问代理是否有额外的http头加载
 *  @param request:需要进行判断的request
 *  @result:用户希望增加的http header。如没有则直接返回nil即可
 */
+ (NSDictionary *) qbProxyProtocolAddCustomHTTPHeader:(NSURLRequest *)request;


+ (NSCachedURLResponse *) getWebOffLineRequestRes:(NSURLRequest *)request;

/*
 *  protocol被初始化之后通知代理
 */
- (void) qbProxyProtocolDidInitialized;

/*
 *  protocol正式开始向网络请求数据之前询问代理是否应该发起请求
 *  代理可能会自行载入本地文件直接返回给[NSURLProtocol client]而无需发起请求。
 *  @result:如果用户自行处理了这个request请求，比如从缓存中获取了数据直接返回给client。则返回NO。否则返回YES，protocol将发起请求。
 */
- (BOOL) qbProxyProtocolShouldStartLoading;

/*
 *protocol发起请求之后的回调
 */
- (void) qbProxyProtocolDidStartLoading;

/*
 *  protocol收到response之后的回调。如果用户返回NO，则protocol停止接收http 正文。
 *  用户可以选择返回error
 *  @param response:网络层收到的请求response，用户可以自定义将其重新赋值，返回自己希望的response
 *  @param error:用于接收错误信息
 *  @result:返回NO则表示停止请求数据，同时若error被赋值，则protocol会抛出错误给client。
 *
 */
- (BOOL) qbProxyProtocolDidReceiveResponse:(inout NSURLResponse **)response error:(out NSError **)error;

/*
 *  protocol收到data之后的回调。用户可以根据收到的正文data自定义返回data。比如插入js代码等。
 *  若无需自定义，则直接返回data即可。
 *  @param data:app收到的页面正文内容。
 *  @result:返回给app的正文。
 */
- (NSData *) qbProxyProtocolDidReceiveData:(NSData *)data;

/*
 *protocol结束请求之后的回调
 */
- (void) qbProxyProtocolDidFinishLoading;

/*
 *protocol请求失败之后的回调
 */
- (void) qbProxyProtocolDidFailWithError:(NSError *)error;

/*
 *  protocol发生请求跳转之后的回调。
 *  用户可以自定义request。若无此需求，直接返回request即可。
 *  @param request:protocol中请求将跳转至此request
 *  @param response:跳转请求对应的response
 *  @result:protocol将跳转至此request。
 */
- (NSURLRequest *) qbProxyProtocolWillSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response;

/*
 *protocol结束代理请求之后的回调
 */
- (void) qbProxyProtocolDidStopLoading;

/*
 *protocol使用缓存之后的回调
 *@param cachedURLResponse:使用的缓存NSCachedURLResponse对象
 *@param errCode:不适用缓存的原因
 */
- (void) qbProxyProtocolDidFinishLoadingWithCached:(NSCachedURLResponse*)cachedURLResponse errCode:(NSInteger)errCode;

/*
 *protocol发送请求后的回调
 *@param request:发送的请求
 */
- (void) qbProxyProtocolAfterSendRequest:(NSURLRequest *)request;

@end

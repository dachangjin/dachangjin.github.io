//
//  ViewController.h
//  weapps
//
//  Created by tommywwang on 2020/5/28.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^WebViewFinishLaunchBlock)(void);

/// webView视图控制器，影藏了原生navigationBar。
/// 支持URL和serviceId两种方式加载资源，URL优先。
@interface WAWebViewController : UIViewController

/// 资源文件URL，支持本地资源文件和远程资源文件
@property (nonatomic, copy) NSURL *URL;

// WebViewFinishNavigation回调
@property (nonatomic, copy) WebViewFinishLaunchBlock finishLaunchBlock;

/// 服务id，根据服务id访问特定的本地资源
/// 先查找沙盒document文件夹下资源，若没有则查找mainBundle下H5.bundle下文件资源
/// 路径为xxxx/bid/preview/back-service.html
/// 若还是找不到，会下载离线包
@property (nonatomic, copy) NSString *bid;

@property (nonatomic, assign) BOOL showLoading;

@end


//
//  JSCustomCallBaseHandler.h
//  weapps
//
//  Created by tommywwang on 2021/6/8.
//  Copyright © 2021 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WAJSCustomCallHandling.h"
NS_ASSUME_NONNULL_BEGIN

@interface WAJSCustomCallBaseHandler : NSObject <WAJSCustomCallHandling>
    
/// 支持的方法集合
- (NSArray<NSString *> *)supportMethods;

/// 处理事件
/// @param event 事件
- (void)handleEvent:(WAJSCustomEvent *)event;

@end

NS_ASSUME_NONNULL_END

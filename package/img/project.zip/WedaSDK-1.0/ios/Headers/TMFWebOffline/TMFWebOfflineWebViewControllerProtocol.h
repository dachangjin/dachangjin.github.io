//
//  TMFWebOfflineWebViewControllerProtocol.h
//  Pods
//
//  Created by klaudz on 20/4/2019.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class TMFWebOfflineHandler;

/**
 @brief 离线包webView容器协议
 */
@protocol TMFWebOfflineWebViewControllerProtocol <NSObject>

/**
 @brief 当前webView容器中的WebView实例
 */
@property (nonatomic, retain, readonly) __kindof UIView *tmf_webView;

/**
 @brief 当前webView容器中的离线包处理器实例
 */
@property (nonatomic, retain) TMFWebOfflineHandler *tmf_webOfflineHandler;

@end

NS_ASSUME_NONNULL_END

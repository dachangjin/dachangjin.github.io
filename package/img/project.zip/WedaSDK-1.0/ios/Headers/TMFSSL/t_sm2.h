/**************************************************
* File name: sm2_encrypt_and_decrypt.h
* Author: HAN Wei
* Date: Dec 8th, 2018
* Description: declare SM2 encrypt data and decrypt
	ciphertext functions
**************************************************/

#ifndef HEADER_SM2_ENCRYPT_AND_DECRYPT_COMPUTATION_H
#define HEADER_SM2_ENCRYPT_AND_DECRYPT_COMPUTATION_H

#ifdef  __cplusplus
extern "C" {
#endif

#include "t_err.h"
#include "t_buf.h"









	//==================================================================

	typedef struct sm2_sig_structure {
		unsigned char r_coordinate[32];
		unsigned char s_coordinate[32];
	} SM2_SIGNATURE_STRUCT;

	/**************************************************
	* Name: sm2_sign_data
	* Function: compute SM2 signature
	* Parameters:
		message[in]      input message
		message_len[in]  input message length, size in bytes
		id[in]           user id
		id_len[in]       user id length, size in bytes
		pub_key[in]      SM2 public key
		pri_key[in]      SM2 private key
		sm2_sig[out]     SM2 signature
	* Return value:
		0:                function executes successfully
		any other value:  an error occurs
	* Notes:
	1. The user id value cannot be NULL. If the specific
	   value is unknown, the default user id "1234567812345678"
	   can be used.
	2. "pub_key" is a octet string of 64 byte length. It
	   is a concatenation of X || Y. X and Y both are
	   SM2 public key coordinates of 32-byte length.
	3. "pri_key" is a octet string of 32 byte length.
	**************************************************/
	int sm2_sign_data(const unsigned char *message,
		const int message_len,
		const unsigned char *id,
		const int id_len,
		const unsigned char* pub_key_x_,
		const unsigned char* pub_key_y_,
		const unsigned char* pri_key,
		SM2_SIGNATURE_STRUCT *sm2_sig);

	/**************************************************
	* Name: sm2_verify_sig
	* Function: verify SM2 signature
	* Parameters:
		message[in]      input message
		message_len[in]  input message length, size in bytes
		id[in]           user id
		id_len[in]       user id length, size in bytes
		pub_key[in]      SM2 public key
		sm2_sig[out]     SM2 signature
	* Return value:
		0:                signature passes verification
		any other value:  an error occurs
	* Notes:
	1. "pub_key" is a octet string of 64 byte length. It
	   is a concatenation of X || Y. X and Y both are
	   SM2 public key coordinates of 32-byte length.
	**************************************************/
	int sm2_verify_sig(const unsigned char *message,
		const int message_len,
		const unsigned char *id,
		const int id_len,
		const unsigned char* pub_key_x,
		const unsigned char* pub_key_y,
		SM2_SIGNATURE_STRUCT *sm2_sig);

	//----------------------------------------------------------

	typedef struct tmf_sm2_key_pair_structure {
		uint8_t pri_key[32];
		uint8_t pub_key_x[32];
		uint8_t pub_key_y[32];
	} TMF_SM2_KEY_PAIR;

	t_err tmf_sm2_create_key_pair(TMF_SM2_KEY_PAIR *key_pair);


	//SM2 ciphertext is defined as a concatenation of c1 || c3 || c2 in GM / T 0003.4 - 2012.
//out_c2������䲻С��in_len���Ŀռ䣬���ĺ�ԭ��һ�����ġ�
	t_err tmf_sm2_encrypt(const uint8_t* in_, int in_len,
		const uint8_t pub_key_x[32],
		const uint8_t pub_key_y[32],
		uint8_t out_c1[64],
		uint8_t out_c3[32],
		uint8_t* out_c2);

	t_err tmf_sm2_decrypt(const uint8_t in_c1[64],
		const uint8_t in_c3[32],
		const uint8_t* in_c2,
		int in_c2_len,
		const uint8_t pri_key[32],
		uint8_t* out_buf);


	t_err TmfHexToSm2Key(const char* hex, uint8_t key[32]);


	t_err TmfSm2Encrypt(const void* in_buf,
		int in_len,
		const uint8_t pub_key_x[32],
		const uint8_t pub_key_y[32],
		t_buf* outbuf);

	t_err TmfSm2Decrypt(const void* in_buf, 
		int in_len,
		const uint8_t pri_key[32],
		t_buf* outbuf);



#ifdef  __cplusplus
}
#endif

#endif  /* end of HEADER_SM2_ENCRYPT_AND_DECRYPT_COMPUTATION_H */

//
//  WAViewController.m
//  WedaSDK
//
//  Created by tommywwang on 08/18/2021.
//  Copyright (c) 2021 tommywwang. All rights reserved.
//

#import "WAViewController.h"

@interface WAViewController ()

@end

@implementation WAViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

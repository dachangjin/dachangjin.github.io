//
//  UIDevice+Keychain.h
//  QQPimSDKDemo
//
//  Created by ken on 12-4-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 提供读取设备唯一标识符的方法
 */
@interface UIDevice (CustomUDID)

+ (NSString *)udidWithWifiMacAddressAndDeviceModelMD5; //读取wifi的mac地址和机器型号，对结果取md5的值
+ (NSString *)wifiMac;
+ (BOOL)hasAPT;

@end

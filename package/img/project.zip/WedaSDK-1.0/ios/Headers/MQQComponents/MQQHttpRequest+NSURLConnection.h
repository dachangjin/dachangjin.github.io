//
//  MQQHttpRequest+NSURLConnection.h
//  MQQSecure
//
//  Created by klaudz on 7/24/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import "MQQHttpRequest+Private.h"

@interface MQQHttpRequest (NSURLConnection) <NSURLConnectionDataDelegate>

- (void)CN_startConnect;
- (void)CN_clearAll;

- (BOOL)CN_prepareForDownloadWithError:(NSError **)error;
- (void)CN_clearDownloadingFiles;

@end


#ifndef __TCC_BUFFER_H__
#define __TCC_BUFFER_H__


#define SM2_BLOCK_SIZE 32
#define SM4_BLOCK_SIZE 16



#include "t_err.h"


#include <wchar.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct __t_buf {
	unsigned char* buf;
	int len;
	int buf_memory_size;
}t_buf;

extern t_buf* t_buf_new(int size);
extern void t_buf_free(t_buf* buff);
extern int t_buf_resize(t_buf* p, int _size);

extern t_err TccBufferHexStrToByte(t_buf* to, const char* from, int len);
extern t_err TccBufferByteToHexStr(t_buf* to, const char* from, int len);

void hex_str_to_buf(const unsigned char* hex, unsigned char* buf, int buflen);


#ifdef  __cplusplus
}
#endif

#endif //__TCC_BUFFER_H__

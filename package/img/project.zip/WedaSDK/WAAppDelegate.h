//
//  WAAppDelegate.h
//  WedaSDK
//
//  Created by tommywwang on 08/18/2021.
//  Copyright (c) 2021 tommywwang. All rights reserved.
//

@import UIKit;

@interface WAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

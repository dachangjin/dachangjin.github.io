#ifndef __TCC_CONTAINER_BASE_H_DEFINE__
#define __TCC_CONTAINER_BASE_H_DEFINE__


#include "TccString.h"

template<typename T>
inline void TccCntrSwap(T& _Left, T& _Right){
	T _Tmp;
	_Tmp = _Left;
	_Left = _Right;
	_Right = _Tmp;
}

template<typename T>
inline void TccCntrSwap(TccStr16& _Left, TccStr16& _Right){
	TccStr16::Swap(_Left, _Right);
}

template<typename T>
inline void TccCntrSwap(TccStr8& _Left, TccStr8& _Right){
	TccStr8::Swap(_Left, _Right);
}

template<typename T>
inline void TccCntrArrSwap(T* base, ti32 a, ti32 b){
	if (a != b){
		TccCntrSwap(base[a], base[b]);
	}
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccCntrArrSwap(TccStr16* base, ti32 a, ti32 b){
	if (a != b){
		TccStr16::Swap(base[a], base[b]);
	}
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccCntrArrSwap(TccStr8* base, ti32 a, ti32 b){
	if (a != b){
		TccStr8::Swap(base[a], base[b]);
	}
}

//-------------------------------------------

template<typename T>
class TccTraits {
public:
	static inline void DeleteHandle(T&){}
	static inline ti32 Compare(const T& a, const T& b){
		if(b < a) return 1;
		else if(a < b) return -1;
		return 0;
	}
};

TCC_TEMPLATE_SPECIALIZATION
class TccTraits<tchar*> {
public:
	typedef tchar* _char_ptr_;
	static inline void DeleteHandle(_char_ptr_&){}
	static inline ti32 Compare(const _char_ptr_& a, const _char_ptr_& b){
		return TccStrcmp(a, b);
	}
};

TCC_TEMPLATE_SPECIALIZATION
class TccTraits<tu8*> {
public:
	typedef tu8* _char_ptr_;
	static inline void DeleteHandle(_char_ptr_&){}
	static inline ti32 Compare(const _char_ptr_& a, const _char_ptr_& b){
		return TccStrcmp(a, b);
	}
};

TCC_TEMPLATE_SPECIALIZATION
class TccTraits<twchar*> {
public:
	typedef twchar* _char_ptr_;
	static inline void DeleteHandle(_char_ptr_&){}
	static inline ti32 Compare(const _char_ptr_& a, const _char_ptr_& b){
		return TccWcscmp(a, b);
	}
};

template<class T>
class TccPtrTraits {
public:
	static inline void DeleteHandle(T& a){ 
		delete a;
	}
	static inline ti32 Compare(const T& a, const T& b){
		if(*b < *a) return 1;
		else if(*a < *b) return -1;
		return 0;
	}
};

//----------------------------------------------------------------------
template <typename T1, typename T2>
class TccCntrPair
{
public:
	T1 iFirst;	// the first stored value
	T2 iSecond;	// the second stored value

	//TccCntrPair() : iFirst(T1()), iSecond(T2()){}
	TccCntrPair(){}
	TccCntrPair(const T1& _Val1, const T2& _Val2){
		iFirst = _Val1;
		iSecond = _Val2;
	}

	template<class _Other1, class _Other2>
	TccCntrPair(const TccCntrPair<_Other1, _Other2>& _Right){
		iFirst = _Right.iFirst;
		iSecond = _Right.iSecond;
	}

	inline T1& First(){return iFirst;}
	inline T2& Second(){return iSecond;}

	inline TccCntrPair& operator=(const TccCntrPair& _Right){
		iFirst = _Right.iFirst;
		iSecond = _Right.iSecond;
		return *this;
	}
};

template<typename T1, typename T2, typename _T1Traits = TccTraits<T1>, typename _T2Traits = TccTraits<T2> >
class TccCntrPairTraits{
public:
	static inline void DeleteHandle(TccCntrPair<T1, T2>& a){
		_T1Traits::DeleteHandle(a.iFirst);
		_T2Traits::DeleteHandle(a.iSecond);
	}
	static inline ti32 Compare(const TccCntrPair<T1, T2>& a, const TccCntrPair<T1, T2>& b){
		return _T1Traits::Compare(a.iFirst, b.iFirst);
	}
	static inline ti32 Compare(const T1& a, const TccCntrPair<T1, T2>& b){
		return _T1Traits::Compare(a, b.iFirst);
	}
	static inline ti32 Compare(const TccCntrPair<T1, T2>& a, const T1& b){
		return _T1Traits::Compare(a.iFirst, b);
	}
	static inline ti32 Compare(const T1& a, const T1& b){
		return _T1Traits::Compare(a, b);
	}
	template<class KEY>
	static inline ti32 Compare(const KEY& key, const TccCntrPair<T1, T2>& a){
		return _T1Traits::Compare(key, a.iFirst);
	}
};


TCC_TEMPLATE_SPECIALIZATION
inline void TccCntrSwap(TccCntrPair<ti32, TccStr16>& _Left, TccCntrPair<ti32, TccStr16>& _Right){
	TccCntrSwap(_Left.iFirst, _Right.iFirst);
	TccStr16::Swap(_Left.iSecond, _Right.iSecond);
}

TCC_TEMPLATE_SPECIALIZATION
inline void TccCntrArrSwap(TccCntrPair<ti32, TccStr16>* base, ti32 a, ti32 b){
	if (a != b){
		TccCntrSwap(base[a].iFirst, base[b].iFirst);
		TccStr16::Swap(base[a].iSecond, base[b].iSecond);
	}
}


#endif //__TCC_CONTAINER_BASE_H_DEFINE__


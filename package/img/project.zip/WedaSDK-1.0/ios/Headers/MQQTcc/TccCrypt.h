
#ifndef __TCC_CRYPT_H_DEFINE__
#define __TCC_CRYPT_H_DEFINE__


#include "TccSys.h"
#include "TccEndianSwap.h"

#define SHA1HashSize 20
#define SHA2HashSize 32
#define Md5HashSize 16

TCCIMPORT void TccCrc32Init(tu32 crc32_table[256]);
TCCIMPORT tu32 TccCrc32(const void* inbuf, ti32 len, tu32* crc32_table);
inline tu32 TccCrc32(const tu8* inbuf, tu32* crc32_table){
	return TccCrc32(inbuf, TccStrlen(inbuf), crc32_table);
}



//-----------------------------------------------------------------------------
#if !defined(__TCC_USE_OS_BUILT_IN_CRYPT__)

typedef struct _TccMd5Context {
	tu32 A;
	tu32 B;
	tu32 C;
	tu32 D;
	tu32 total[2];
	ti32 buflen;
	tu8 buffer[128];
}TccMd5Context;

#elif defined (__TccSymbian__)

class CMessageDigest;
typedef struct _TccMd5Context {
	CMessageDigest* iMD;
}TccMd5Context;

#else

#error Please implement the MD5 using current OS API

#endif	// __TCC_USE_OS_BUILT_IN_CRYPT__

TCCIMPORT void TccMd5Init(TccMd5Context* ctx);
TCCIMPORT void TccMd5Update(TccMd5Context* ctx, const void* data, ti32 length);
TCCIMPORT void TccMd5Final(TccMd5Context* ctx, tu8 Message_Digest[Md5HashSize]);
TCCIMPORT void TccMd5(const void *data, ti32 dlen, tu8 digest[Md5HashSize]);

TCCIMPORT void TccHmacMd5Init(TccMd5Context* md5Context, const void* key, ti32 klen);
TCCIMPORT void TccHmacMd5Update(TccMd5Context* md5Context, const void* data, ti32 dlen);
TCCIMPORT void TccHmacMd5Final(TccMd5Context* md5Context, const void* key, ti32 klen, tu8 digest[Md5HashSize]);
TCCIMPORT void TccHmacMd5(const void* data, ti32 dlen, const void* key, ti32 klen, tu8 digest[Md5HashSize]);

//---------------------------------------------------------------------

#if !defined(__TCC_USE_OS_BUILT_IN_CRYPT__)

typedef struct _TccSha1Context{
	tu32 Intermediate_Hash[SHA1HashSize / 4];	///< Message Digest
	tu32 Length_Low;							///< Message length in bits
	tu32 Length_High;							///< Message length in bits
	ti32 Message_Block_Index;					///< Index into message block array
	tu8 Message_Block[64];						///< 512-bit message blocks
	ti32 Computed;								///< Is the digest computed?
	ti32 Corrupted;								///< Is the message digest corrupted?
} TccSha1Context;

#elif defined (__TccSymbian__)

typedef struct _TccSha1Context {
	CMessageDigest* iMD;
}TccSha1Context;

#else

#error Please implement the SHA1 using current OS API

#endif

TCCIMPORT void TccSha1Init(TccSha1Context* context);
TCCIMPORT void TccSha1Update(TccSha1Context* context, const void* message_array, ti32 length);
TCCIMPORT void TccSha1Final(TccSha1Context* context, tu8 Message_Digest[SHA1HashSize]);
TCCIMPORT void TccSha1(const void *data, ti32 dlen, tu8 digest[SHA1HashSize]);

TCCIMPORT void TccHmacSha1Init(TccSha1Context *sha1Context, const void* key, ti32 klen);
TCCIMPORT void TccHmacSha1Update(TccSha1Context *sha1Context, const void* data, ti32 dlen);
TCCIMPORT void TccHmacSha1Final(TccSha1Context *sha1Context, const void* key, ti32 klen, tu8 digest[SHA1HashSize]);
TCCIMPORT void TccHmacSha1(const void* data, ti32 dlen, const void* key, ti32 klen, tu8 digest[SHA1HashSize]);

//------------------------------------------------------------------------------


typedef struct _TccSha2Context {
	tu32 Intermediate_Hash[SHA2HashSize / 4];	// Message Digest
	tu32 Length_Low;							// Message length in bits
	tu32 Length_High;							// Message length in bits
	ti32 Message_Block_Index;					// Message_Block array index
	tu8 Message_Block[64];						// 512-bit message blocks
	ti32 Computed;								// Is the digest computed?
	ti32 Corrupted;								// Is the digest corrupted? lasterror һ��Ķ���
} TccSha2Context;


TCCIMPORT void TccSha2Init(TccSha2Context* context);
TCCIMPORT void TccSha2Update(TccSha2Context* context, const void* message_array, ti32 length);
TCCIMPORT void TccSha2Final(TccSha2Context* context, tu8 Message_Digest[SHA2HashSize]);
inline void TccSha2(const void* data, ti32 len, tu8 Message_Digest[SHA2HashSize]){
	_TccSha2Context sha2Context;
	TccSha2Init(&sha2Context);
	TccSha2Update(&sha2Context, data, len);
	TccSha2Final(&sha2Context, Message_Digest);
}


TCCIMPORT void TccHmacSha2Init(TccSha2Context *sha1Context, const void* key, ti32 klen);
TCCIMPORT void TccHmacSha2Update(TccSha2Context *sha1Context, const void* data, ti32 dlen);
TCCIMPORT void TccHmacSha2Final(TccSha2Context *sha1Context, const void* key, ti32 klen, tu8 digest[SHA2HashSize]);
TCCIMPORT void TccHmacSha2(const void* data, ti32 dlen, const void* key, ti32 klen, tu8 digest[SHA2HashSize]);


//------------------------------------------------------------------------------
inline ti32 TccFindXxTeaEncryptSize(ti32 aLen){return (_TccAlign32(aLen) + 4);}
TCCIMPORT ti32 TccXxteaEncrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* enc_chr, ti32 enclen);
TCCIMPORT ti32 TccXxteaDecrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* dec_chr, ti32 declen);

//��tagformat�õļ��ܽ��ܷ���,�ص���4�ֽڶ���͹���,����Ҫ����ռ�.����xxtea.
TCCIMPORT ti32 TccTagDataEncrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* enc_chr, ti32 enclen);
TCCIMPORT ti32 TccTagDataDecrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* dec_chr, ti32 declen);

TCCIMPORT ti32 TccTeaFindEncryptSize(ti32 nLen);
TCCIMPORT ti32 TccTeaEncrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* enc_chr, ti32 enclen);
TCCIMPORT ti32 TccTeaDecrypt(const tu8* str, ti32 slen, const tu8* key, ti32 keylen, tu8* dec_chr, ti32 declen);

TCCIMPORT void MakeMd5HashSizePassword(const void* aStr, ti32 aLen, tu8 aPassword[Md5HashSize]);


#endif //__TCC_CRYPT_H_DEFINE__


//
//  TMFInstructionResult.h
//  TMFInstruction
//
//  Created by charmxiao on 2019/8/1.
//

#import <Foundation/Foundation.h>
#import "TMFInstruction.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, TMFInstructionPhase) {
    TMFInstructionPhaseNone             = 0,
    TMFInstructionPhaseShown            = 1,  ///< 云指令显示上报
    TMFInstructionPhaseUserConfirmed    = 2,  ///< 云指令用户确认上报
    TMFInstructionPhaseExecuted         = 3,  ///< 云指令执行上报
};

typedef NS_ENUM(NSInteger, TMFInstructionStatus) {
    TMFInstructionStatusNone = 0,           ///< 默认
    TMFInstructionStatusSuccessful = 1,     ///< 云指令执行成功
    TMFInstructionStatusFailed = 2,         ///< 云指令执行失败
    TMFInstructionStatusInvalid = 3,        ///< 云指令无效
    TMFInstructionStatusExpired = 4,        ///< 云指令过期失效
    TMFInstructionStatusCancelled = 10,     ///< 云指令取消
    TMFInstructionStatusRevoked = 11,       ///< 云指令撤销
};

@interface TMFInstructionResult : NSObject

@property (nonatomic, retain) TMFInstruction *instruction;          ///< 云指令内容
@property (nonatomic, assign) TMFInstructionPhase phase;            ///< 云指令执行阶段
@property (nonatomic, assign) TMFInstructionStatus status;          ///< 云指令执行状态

@end

NS_ASSUME_NONNULL_END

//
//  TMFStatisticsManager+JSBridge.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsManager.h"

NS_ASSUME_NONNULL_BEGIN

#define JSBridge_setPageName @"setPageName"
#define JSBridge_trackCustomKVEvent @"trackCustomKVEvent"
#define JSBridge_trackCustomKVTimeIntervalEvent @"trackCustomKVTimeIntervalEvent"
#define JSBridge_setCustomUserId @"setCustomUserId"

@interface TMFStatisticsManager (JSBridge)

- (void)JSInvokeWithMethodName:(NSString *)methodName args:(NSDictionary *)args configuration:(nullable TMFStatisticsConfiguration *)configuration;

- (BOOL)canHandleURL:(NSURL *)URL;
- (void)handleURL:(NSURL *)URL configuration:(nullable TMFStatisticsConfiguration *)configuration;

@end

NS_ASSUME_NONNULL_END

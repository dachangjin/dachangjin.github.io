

#ifndef __QuickSortUseContext__
#define __QuickSortCompare(p1, p2) comp(p1, p2)
#else	//__QuickSortUseContext__
#define __QuickSortCompare(p1, p2) comp(context, p1, p2)
#endif	//__QuickSortUseContext__



#ifndef __QuickSortUseContext__
template<typename T>
void TccQuickSort(T * base, ti32 num, ti32(*comp)(const T&, const T&))
#else
template<typename T, typename _Context>
void TccQuickSortEx(T * base, ti32 num, const _Context& context, ti32(*comp)(const _Context&, const T&, const T&))
#endif //__QuickSortUseContext__
{

	ti32 lo;
	ti32 hi;				/* ends of sub-array currently sorting */
	ti32 mid;				/* points to middle of subarray */
	ti32 loguy;
	ti32 higuy;			/* traveling pointers for partition step */
	ti32 size;			/* size of the sub-array */

	/* Note: the number of stack entries required is no more than
	1 + log2(num), so 30 is sufficient for any array */
	ti32 lostk[(8 * sizeof(void*) - 1)]; 
	ti32 histk[(8 * sizeof(void*) - 1)];
	ti32 stkptr;                 /* stack for saving sub-array to be processed */

	/* validation section */
	TccAssert((base != NULL || num == 0));
	TccAssert(comp != NULL);

	if (num < 2) return;
	lostk[0] = 0;
	histk[0] = 0;
	stkptr = 1;                 /* initialize stack */
	lo = 0;
	hi = num - 1;        /* initialize limits */

	while (stkptr > 0) {
		size = hi - lo + 1;        /* number of el's to sort */
		do {
			/* below a certain size, it is faster to use a O(n^2) sorting method */
			if (size <= 8) {  /* testing shows that this is good value */
				//TccQuickSortInsertionSort(base, lo, hi, comp);
				// higuy is max ptr
				while (hi > lo) {
					higuy = lo;
					for (loguy = lo + 1; loguy <= hi; loguy++) {
						if (__QuickSortCompare(base[loguy], base[higuy]) > 0){
							higuy = loguy;
						}
					}
					TccCntrArrSwap(base, higuy, hi);
					hi--;
				}
			}
			else {

				mid = lo + (size / 2); 

				// Sort the first, middle, last elements into order
				if (__QuickSortCompare(base[lo], base[mid]) > 0) {
					TccCntrArrSwap(base, lo, mid);
				}
				if (__QuickSortCompare(base[lo], base[hi]) > 0) {
					TccCntrArrSwap(base, lo, hi);
				}
				if (__QuickSortCompare(base[mid], base[hi]) > 0) {
					TccCntrArrSwap(base, mid, hi);
				}

				loguy = lo;
				higuy = hi;
				for (;;) {
					if (mid > loguy) {
						do  {
							loguy++;
						} while (loguy < mid && __QuickSortCompare(base[loguy], base[mid]) <= 0);
					}
					if (mid <= loguy) {
						do  {
							loguy++;
						} while (loguy <= hi && __QuickSortCompare(base[loguy], base[mid]) <= 0);
					}

					/* lo < loguy <= hi+1, A[i] <= A[mid] for lo <= i < loguy,
					either loguy > hi or A[loguy] > A[mid] */

					do  {
						higuy--;
					} while (higuy > mid && __QuickSortCompare(base[higuy], base[mid]) > 0);

					/* lo <= higuy < hi, A[i] > A[mid] for higuy < i < hi,
					either higuy == lo or A[higuy] <= A[mid] */
					if (higuy < loguy)
						break;

					TccCntrArrSwap(base, loguy, higuy);

					if (mid == higuy)
						mid = loguy;
				}

				higuy++;

				if (mid < higuy) {
					do  {
						higuy--;
					} while (higuy > mid && __QuickSortCompare(base[higuy], base[mid]) == 0);
				}
				if (mid >= higuy) {
					do  {
						higuy--;
					} while (higuy > lo && __QuickSortCompare(base[higuy], base[mid]) == 0);
				}

				if ( higuy - lo >= hi - loguy ) {
					if (lo < higuy) {
						lostk[stkptr] = lo;
						histk[stkptr] = higuy;
						++stkptr;
					}                           /* save big recursion for later */
					if (loguy < hi) {
						lo = loguy;
						break;          /* do small recursion */
					}
				}
				else {
					if (loguy < hi) {
						lostk[stkptr] = loguy;
						histk[stkptr] = hi;
						++stkptr;               /* save big recursion for later */
					}
					if (lo < higuy) {
						hi = higuy;
						break;           /* do small recursion */
					}
				}
			}

			--stkptr;
			lo = lostk[stkptr];
			hi = histk[stkptr];           /* pop subarray from stack */
			//if stkptr == 0, then all subarrays done, will stop.

		} while(0);
	}
}



#ifndef __QuickSortUseContext__
template<typename KeyT, typename T>
ti32 TccBinarySearch(const KeyT& key, const T* base, ti32 num, ti32(*comp)(const KeyT&, const T&))
#else
template<typename KeyT, typename T, typename _Context>
ti32 TccBinarySearchEx(const KeyT& key, const T* base, ti32 num, const _Context& context, ti32(*comp)(const _Context&, const KeyT&, const T&))
#endif //__QuickSortUseContext__
{
	ti32 lo = 0;
	ti32 hi = num - 1;
	ti32 mid;
	ti32 half;
	ti32 result;

	TccAssert((base != NULL || num == 0));
	TccAssert(comp != NULL);

	while (lo <= hi){
		if ((half = num / 2) != 0){
			mid = lo + (num & 1 ? half : (half - 1));
			if ((result = __QuickSortCompare(key, base[mid])) == 0){
				return (mid);
			}
			else if (result < 0){
				hi = mid - 1;
				num = num & 1 ? half : half - 1;
			}
			else{
				lo = mid + 1;
				num = half;
			}
		}
		else if (num){
			return (__QuickSortCompare(key, base[lo]) ? -1 : lo);
		}
		else{
			break;
		}
	}
	return -1;
}

#undef __QuickSortCompare
#undef __QuickSortUseContext__


//
//  WAJSCustomFilleHandler.h
//  WedaSDK_Example
//
//  Created by tommywwang on 2021/11/11.
//  Copyright © 2021 tommywwang. All rights reserved.
//

#import "JSCustomFileHandler.h"

NS_ASSUME_NONNULL_BEGIN

@interface JSCustomFileHandler : WAJSCustomCallBaseHandler

@end

NS_ASSUME_NONNULL_END

//
//  TMFStatisticsPool.h
//  TMFStatistics
//
//  Created by hauzhong on 2019/11/1.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TMFStatisticsThreadPool : NSObject

+ (instancetype)dispatch_queue_serial;

@property (nonatomic, assign, readonly) dispatch_queue_t queue;

- (void)invokeAsyncWithBlock:(dispatch_block_t)block;
- (void)invokeSyncWithBlock:(dispatch_block_t)block;

@end

NS_ASSUME_NONNULL_END

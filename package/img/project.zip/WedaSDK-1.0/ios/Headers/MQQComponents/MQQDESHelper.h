//
//  MQQDESHelper.h
//  MQQQRCodeDemo
//
//  Created by Kloudz Liang on 14-1-23.
//  Copyright (c) 2014年 Klaudz Liang. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXTERN
NSData * MQQDESEncrypt(NSData *data, NSString *key);

FOUNDATION_EXTERN
NSData * MQQDESDecrypt(NSData *data, NSString *key);

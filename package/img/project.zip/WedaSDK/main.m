//
//  main.m
//  WedaSDK
//
//  Created by tommywwang on 08/18/2021.
//  Copyright (c) 2021 tommywwang. All rights reserved.
//

@import UIKit;
#import "WAAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WAAppDelegate class]));
    }
}

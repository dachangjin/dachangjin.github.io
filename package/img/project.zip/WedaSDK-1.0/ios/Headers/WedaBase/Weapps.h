//
//  Weapps.h
//  weapps
//
//  Created by tommywwang on 2020/7/1.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UserNotifications/UserNotifications.h>
#import "WASDKConfig.h"
#import "WAJSCustomCallBaseHandler.h"

NS_ASSUME_NONNULL_BEGIN

/// WASDKDelegate
@protocol WASDKDelegate <NSObject>

/// 胶囊按钮 关闭按钮点击回调
/// @param bid bid
- (void)closeButtonClickedForBid:(NSString *)bid;

/// 胶囊按钮 菜单按钮点击回调
/// @param bid bid
- (void)menuButtonClickedForBid:(NSString *)bid;

/// 胶囊按钮 关闭按钮点击回调
/// @param URL URL
- (void)closeButtonClickedForURL:(NSURL *)URL;

/// 胶囊按钮 菜单按钮点击回调
/// @param URL URL
- (void)menuButtonClickedForURL:(NSURL *)URL;

/// 打开小程序时的loading视图，返回nil使用默认加载视图
/// @param bid bid
- (UIView *)loadingViewForBid:(NSString *)bid;

/// 打开小程序时的loading视图，返回nil使用默认加载视图
/// @param URL URL
- (UIView *)loadingViewForURL:(NSURL *)URL;

@end

/// Weapps
@interface Weapps : NSObject <UIApplicationDelegate, UNUserNotificationCenterDelegate>


/// 配置
@property (nonatomic, strong, readonly) WASDKConfig *SDKConfig;

/**
 *  严格单例，唯一获得实例的方法.
 *
 *  @return 实例对象.
 */
+ (instancetype)sharedApps;

/// 初始化SDK
/// @param config 初始化配置参数
- (void)initWithConfig:(WASDKConfig *)config;

/// 注册自定义js方法调用处理器
- (void)registerCustomHandler:(WAJSCustomCallBaseHandler *)handler;

/// 设置delegate
/// @param delegate delegate
- (void)setDelegate:(id<WASDKDelegate>)delegate;

/// 打开小程序
/// 查询本地是否存在业务数据，若不存在会先下载业务数据资源。数据资源需要提前在离线资源控制台预先发布
/// @param bid 业务id
/// @param enableBackground 关闭小程序后是否允许后台运行，最大允许后台运行数可在WASDKConfig中设置
/// @param completion 完成回调
- (void)startMiniAppWithBid:(NSString *)bid
           enableBackground:(BOOL)enableBackground
                 completion:(void(^ __nullable)(BOOL success))completion;


/// 重新打开小程序
/// 查询本地是否存在业务数据，若不存在会先下载业务数据资源。数据资源需要提前在离线资源控制台预先发布
/// @param bid 业务id
/// @param enableBackground 关闭小程序后是否允许后台运行，最大允许后台运行数可在WASDKConfig中设置
/// @param completion 完成回调
- (void)restartMiniAppWithBid:(NSString *)bid
             enableBackground:(BOOL)enableBackground
                   completion:(void(^ __nullable)(BOOL success))completion;


/// 打开小程序
/// 打开在线或本地小程序
/// @param URL url地址
/// @param enableBackground 关闭小程序后是否允许后台运行，最大允许后台运行数可在WASDKConfig中设置
/// @param completion 完成回调
- (void)startMiniAppWithURL:(NSURL *)URL
           enableBackground:(BOOL)enableBackground
                 completion:(void(^ __nullable)(BOOL success))completion;


/// 重新打开小程序
/// @param URL url地址
/// @param enableBackground 关闭小程序后是否允许后台运行，最大允许后台运行数可在WASDKConfig中设置
/// @param completion 完成回调
- (void)restartMiniAppWithURL:(NSURL *)URL
             enableBackground:(BOOL)enableBackground
                   completion:(void(^ __nullable)(BOOL success))completion;



/// 关闭小程序
/// @param bid 业务id
- (void)endMiniAppWithBid:(NSString *)bid;

/// 关闭小程序
/// @param URL 小程序URL
- (void)endMiniAppWithURL:(NSURL *)URL;

@end

NS_ASSUME_NONNULL_END

//
//  TMFWebOfflineService.h
//  TMFWebOffline
//
//  Created by hauzhong on 2019/4/15.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "TMFWebOfflineUtilities.h"
#import "TMFWebOfflineServiceOptions.h"
#import "TMFWebOfflineConfiguration.h"
#import "TMFWebOfflinePackageInfo.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString *const TMFWebOfflineServiceShouldUpdateNotification;
extern NSString *const TMFWebOfflineServiceUpdatedBIDsKey; // userInfo contains NSArray<NSString *> with updated BIDs

extern NSString *const TMFWebOfflineInitSuccessNotification;

typedef void(*TMFWebOffline_DownloadProgress)(NSString *Bid, NSProgress *progress);

/**
 @brief 离线包服务提供类，提供离线包检查更新，是否安装等功能
 */
@interface TMFWebOfflineService : NSObject

/**
 @brief 生效离线包
 @note 在 `-application:didFinishLaunchingWithOptions:` App函数中调用
 @note 强烈建议放置到前面初始化，在网关配置之后，其他代码初始化之前调用
 */
+ (void)activate;


/**
 @brief 根据离线包业务ID检查更新并预加载离线包，回调更新结果
 
 @param BID 离线包业务ID
 @param completionHandler 检查更新回调。`isUpdated` 更新的成功(YES)或者失败(NO)；`error` 提供更新时候的错误信息。
 */
+ (void)checkAndUpdateWithBID:(NSString *)BID completionHandler:(void(^)(BOOL isUpdated, NSError * _Nullable error))completionHandler;

/**
 @brief 根据离线包业务ID检查更新并预加载离线包，回调更新结果
 
 @param BID 离线包业务ID
 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 检查更新回调。`isUpdated` 更新的成功(YES)或者失败(NO)；`error` 提供更新时候的错误信息。
 */
+ (void)checkAndUpdateWithBID:(NSString *)BID options:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(BOOL isUpdated, NSError * _Nullable error))completionHandler;

/**
 @brief 根据批量离线包业务ID检查更新并预加载离线包，回调可更新的业务ID列表
 
 @param BIDs 离线包业务ID列表
 @param completionHandler 检查更新回调。`updatedBIDs` 可更新的离线包业务ID列表
 */
+ (void)checkAndUpdateWithBIDs:(NSArray<NSString *> *)BIDs completionHandler:(void(^)(NSArray<NSString *> *updatedBIDs))completionHandler;

/**
 @brief 根据批量离线包业务ID检查更新并预加载离线包，回调可更新的业务ID列表
 
 @param BIDs 离线包业务ID列表
 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 检查更新回调。`updatedBIDs` 可更新的离线包业务ID列表
 */
+ (void)checkAndUpdateWithBIDs:(NSArray<NSString *> *)BIDs options:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(NSArray<NSString *> *updatedBIDs))completionHandler;

/**
 @brief 检查全量可更新的离线包并预加载离线包，回调可更新的业务ID列表
 
 @param completionHandler 检查更新回调。`updatedBIDs` 可更新的离线包业务ID列表
 */
+ (void)checkAndUpdateAllAvailablePackagesWithCompletionHandler:(void(^)(NSArray<NSString *> *updatedBIDs))completionHandler;

/**
 @brief 检查全量可更新的离线包并预加载离线包，回调可更新的业务ID列表
 
 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 检查更新回调。`updatedBIDs` 可更新的离线包业务ID列表
 */
+ (void)checkAndUpdateAllAvailablePackagesWithOptions:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(NSArray<NSString *> *updatedBIDs))completionHandler;

/**
 @brief 生效已经下载更新的离线包
 */
+ (void)uncompressPackagesIfNeeded;

/**
 @brief 获取本地离线包的版本号
 
 @param BID 离线包业务ID
 */
+ (int)localVersionForBID:(NSString *)BID;

/**
 @brief 获取本地离线包的存储目录
 
 @param BID 离线包业务ID
 */
+ (NSString *)localPathForBID:(NSString *)BID;


/**
 @brief 移除本地离线包
 
 @param BID 离线包业务ID
 */
+ (void)removeLocalPackageWithBID:(NSString *)BID;

/**
 @brief 批量移除本地离线包
 
 @param BIDs 离线包业务ID列表
 */
+ (void)removeLocalPackageWithBIDs:(NSArray<NSString *> *)BIDs;

/**
 @brief 全部移除本地离线包
 */
+ (void)removeAllLocalPackage;

/**
 @brief 离线包文件验签功能，公钥设置。
 */
+ (void)setPublicKey:(NSString *)publicKey;


#pragma mark - Download Progress
/**
 @brief 注册离线包的下载进度监听
 @note  这个是可选的
 */
+ (void)registerDownloadProgressHandler:(TMFWebOffline_DownloadProgress)downlodaProgressHandler;

#pragma mark - Fallback

/**
 @brief 是否支持 fallback 功能。
 
 @note 如果 fallback 功能开启，`-[TMFWebOfflineHandler determinedURLWithURL:]` 会判断 URL 对应的离线包是否已经下载完成，如果未下载完成，将会返回该离线包的 fallbackURL。
 @note 默认为 `NO`。
 */
@property (class, nonatomic, assign) BOOL fallbackEnabled;

#pragma mark - Log

/**
 @brief 注册SDK内部日志回调，用于输出SDK内部日志
 
 @param logger 离线包日志输出回调
 */
+ (void)registerLogger:(TMFWebOffline_Logger)logger;

/**
 @brief 注册SDK内部统计事件回调，用于输出SDK内部事件
 
 @param reporter 离线包日志上报回调
 */
+ (void)registerReporter:(TMFWebOffline_Reporter)reporter;

#pragma mark - Log (Deprecated)

/**
 @brief 获取debug日志
 */
+ (NSDictionary *)getWebLogDic __attribute__((deprecated("Use +registerLogger: instead.")));
+ (NSDictionary *)getStartLogDic __attribute__((deprecated("Use +registerLogger: instead.")));
+ (NSDictionary *)getPluginLogDic __attribute__((deprecated("Use +registerLogger: instead.")));
+ (NSDictionary *)getOfflineLogDic __attribute__((deprecated("Use +registerLogger: instead.")));
+ (NSString *)getWebviewSumLog __attribute__((deprecated("Use +registerLogger: instead.")));

+ (void)clearLog __attribute__((deprecated("Use +registerLogger: instead.")));

#pragma mark - WKWebView (Deprecated)

/**
 @brief WkWebView离线包配置项
 */
+ (WKWebViewConfiguration *)configurationForWKWebView API_AVAILABLE(macosx(10.13), ios(11.0));

@end


/**
 @brief 离线包服务进阶功能，提供自定义网络配置，检查离线包更新信息，离线包下载接口等
 */
@interface TMFWebOfflineService (Optional)

/**
 @brief 自定义配置生效离线包
 
 @param configuration 离线包下载的网络配置
 @note 调用时机与 `-activate` 一致
 @note 该配置只能设置一次，在离线包下载的网络会话中一直有效!!!
 */
+ (void)activateWithConfiguration:(TMFWebOfflineConfiguration *)configuration;

/**
 @brief 根据批量离线包业务ID检查更新，回调可更新的离线包信息

 @param BIDs 离线包业务ID列表
 @param completionHandler 检查更新回调。`packageInfos` 可更新的离线包信息列表；`error` 发生错误时的信息
 */
+ (void)checkPackageInfosWithBIDs:(NSArray<NSString *> *)BIDs completionHandler:(void(^)(NSArray<TMFWebOfflinePackageInfo *> *packageInfos, NSError * _Nullable error))completionHandler;

/**
 @brief 根据批量离线包业务ID检查更新，回调可更新的离线包信息

 @param BIDs 离线包业务ID列表
 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 检查更新回调。`packageInfos` 可更新的离线包信息列表；`error` 发生错误时的信息
 */
+ (void)checkPackageInfosWithBIDs:(NSArray<NSString *> *)BIDs options:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(NSArray<TMFWebOfflinePackageInfo *> *packageInfos, NSError * _Nullable error))completionHandler;

/**
 @brief 检查全量可更新的离线包，回调可更新的离线包信息

 @param completionHandler 检查更新回调。`packageInfos` 可更新的离线包信息列表；`error` 发生错误时的信息
 */
+ (void)checkAllAvailablePackageInfosWithCompletionHandler:(void(^)(NSArray<TMFWebOfflinePackageInfo *> *packageInfos, NSError * _Nullable error))completionHandler;

/**
 @brief 检查全量可更新的离线包，回调可更新的离线包信息

 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 检查更新回调。`packageInfos` 可更新的离线包信息列表；`error` 发生错误时的信息
 */
+ (void)checkAllAvailablePackageInfosWithOptions:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(NSArray<TMFWebOfflinePackageInfo *> *packageInfos, NSError * _Nullable error))completionHandler;

/**
 @brief 下载指定版本的离线包
 
 @param packageInfo 离线包更新信息
 @param options 可选参数，详见 `TMFWebOfflineServiceOptions` 定义
 @param completionHandler 下载结果回调。`error` 下载错误时的信息
 */
+ (void)downloadPackageWithInfo:(TMFWebOfflinePackageInfo *)packageInfo options:(TMFWebOfflineServiceOptions *)options completionHandler:(void(^)(NSError * _Nullable error))completionHandler;

/**
 @brief 取消下载离线包

 @param packageInfo 离线包更新信息
 */
+ (void)cancelDownloadPackageWithInfo:(TMFWebOfflinePackageInfo *)packageInfo;


/**
 暂停连接拦截
 */
+ (void)pauseHandler;

/**
 重启连接拦截
 */
+ (void)resumeHandler;

@end

NS_ASSUME_NONNULL_END

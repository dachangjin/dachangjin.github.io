//
//  Weapps+ext.h
//  WedaSDK_Example
//
//  Created by tommywwang on 2021/11/9.
//  Copyright © 2021 tommywwang. All rights reserved.
//

#import "Weapps.h"

NS_ASSUME_NONNULL_BEGIN

@interface Weapps (ext)

@end

NS_ASSUME_NONNULL_END

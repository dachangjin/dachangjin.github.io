//
//  TMFDistributionDefines.h
//  TMFDistribution
//
//  Created by bentonxiu on 2019/8/26.
//

#ifndef TMFDistributionDefines_h
#define TMFDistributionDefines_h

/**
 *  组件内部调试日志等级
 */
typedef NS_OPTIONS(NSUInteger, TMFDistributionLogLevel) {
    TMFDistributionLogLevelNone  = 0,        ///< 无日志
    TMFDistributionLogLevelInfo  = 1 << 0,   ///< 普通日志
    TMFDistributionLogLevelWarn  = 1 << 1,   ///< 警告日志
    TMFDistributionLogLevelError = 1 << 2,   ///< 错误日志
    
    TMFDistributionLogLevelAll   = 0xFF,     ///< 全部日志
};

#endif /* TMFDistributionDefines_h */

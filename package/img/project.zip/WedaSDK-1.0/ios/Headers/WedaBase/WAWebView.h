//
//  WAWebView.h
//  weapps
//
//  Created by tommywwang on 2020/6/4.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN


@protocol WebHost <NSObject>

@optional

- (void)openWindowWithPathComponent:(NSString *)pathComponent
                            success:(void(^)(NSDictionary *_Nullable))successBlock
                               fail:(void(^)(NSError *_Nullable))failBlock;

- (void)popWithDelta:(NSUInteger)delta
             success:(void(^)(NSDictionary *_Nullable))successBlock
                fail:(void(^)(NSError *_Nullable))failBlock;

- (void)changeNavBarLeftPage:(NSString *)leftPage
                   rightPage:(NSString *)rightPage
                        type:(NSString *)type
                 stackLength:(NSInteger)stackLength
                     success:(void(^)(NSDictionary *_Nullable))successBlock
                        fail:(void(^)(NSError *_Nullable))failBlock;

- (void)pageDidFinishRender:(NSString *)type
                       page:(NSString *)page
                    success:(void(^)(NSDictionary *_Nullable))successBlock
                       fail:(void(^)(NSError *_Nullable))failBlock;

- (void)navBarAnimationLeftPage:(NSString *)leftPage
                      rightPage:(NSString *)rightPage
                    stackLength:(NSInteger)stackLength
                        success:(void(^)(NSDictionary *_Nullable))successBlock
                           fail:(void(^)(NSError *_Nullable))failBlock;

- (void)navBarBackAnimationLeftPage:(NSString *)leftPage
                          rightPage:(NSString *)rightPage
                           progress:(CGFloat)progress
                               back:(BOOL)back
                               type:(NSString *)type
                        stackLength:(NSInteger)stackLength
                            success:(void(^)(NSDictionary *_Nullable))successBlock
                               fail:(void(^)(NSError *_Nullable))failBlock;

//****************************************导航栏**********************************************
- (void)showNavigationBarLoadingWithSuccess:(void(^)(NSDictionary *_Nullable result))successBlock
                                       fail:(void(^)(NSError *_Nullable error))failBlock;

- (void)hideNavigationBarLoadingWithSuccess:(void(^)(NSDictionary *_Nullable result))successBlock
                                       fail:(void(^)(NSError *_Nullable error))failBlock;

- (void)setNavigationBarTitle:(NSString *)title
                  withSuccess:(void(^)(NSDictionary *_Nullable result))successBlock
                         fail:(void(^)(NSError *_Nullable error))failBlock;


- (void)setNavigationBarBackgroundColor:(UIColor *)color
                             frontColor:(UIColor *)color
                      animationDuration:(CGFloat)animationDuration
                             timingFunc:(NSString *)timingFunc
                            withSuccess:(void(^)(NSDictionary *_Nullable result))successBlock
                                   fail:(void(^)(NSError *_Nullable error))failBlock;

- (void)hideHomeButtonWithSuccess:(void(^)(NSDictionary *_Nullable result))successBlock
                             fail:(void(^)(NSError *_Nullable error))failBlock;

- (void)setNavigationBarBackgroundColor:(UIColor *)bgColor
                                  title:(NSString *)title
                           barTintColor:(UIColor *)tintColor
                           hideBackItem:(BOOL)hideBackItem;

- (void)setNavigationBarHidden:(BOOL)hidden;


@end

typedef NS_ENUM(NSUInteger, WebViewState) {
    WebViewStateInit,
    WebViewStateLoadFinished,
};

@class WAWebView;
typedef void(^WebViewBlock)(WAWebView *webView);

@interface WAWebView : WKWebView

@property (nonatomic, weak)id <WebHost>webHost;
@property (nonatomic, assign) WebViewState state;

//

#pragma mark webView 生命周期

/// 需在webView所在ViewController里面手动调用，调用后会执行所有didAppear生命周期回调
- (void)viewDidAppear;

/// 需在webView所在ViewController里面手动调用，调用后会执行所有willDisappear生命周期回调
- (void)viewWillDisappear;

- (void)navigateBack;

- (void)goToHome;
@end

NS_ASSUME_NONNULL_END

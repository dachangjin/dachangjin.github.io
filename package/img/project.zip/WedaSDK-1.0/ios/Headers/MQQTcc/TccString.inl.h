
#if defined(__TccUnicodeImplement__)
#define tcc_cchar			twchar
#define tcc_tchar			twchar
#define tcc_rowstr			const twchar*

#define TccDesCX			TccDesC16
#define TccDesX				TccDes16
#define TccPtrCX			TccPtrC16
#define TccPtrX				TccPtr16
#define TccBufX				TccBuf16
#define TccStrX				TccStr16
#define TccLitCX			TccLitC16
#define TccTcslen			TccWcslen
#define TccAlignStr			_TccAlign16
#define __TRefBStrCX		__TRefStrC16


#define SYTUintX			TUint16
#define SYTDesCX			TDesC16
#define SYTPtrCX			TPtrC16
#define SYTTRefDesCX		__TRefDesC16

#define TagArrayStr _tstr16

#else
#define tcc_cchar			tchar
#define tcc_tchar			tu8
#define tcc_rowstr			const void*

#define TccDesCX			TccDesC8
#define TccDesX				TccDes8
#define TccPtrCX			TccPtrC8
#define TccPtrX				TccPtr8
#define TccBufX				TccBuf8
#define TccLitCX			TccLitC8
#define TccStrX				TccStr8

#define TccTcslen			TccStrlen
#define TccAlignStr			_TccAlign32
#define __TRefBStrCX		__TRefStrC8

#define SYTUintX			TUint8
#define SYTDesCX			TDesC8
#define SYTPtrCX			TPtrC8
#define SYTTRefDesCX		__TRefDesC8

#define TagArrayStr _tstr8

#endif


#if defined(__TccSymbian__) && !defined(_TccStrForceZeroTerminate)
/*
inline const SYTDesCX* TccDesCX::operator&() const {
	return reinterpret_cast<const SYTDesCX*>(this);
}
inline const SYTDesCX& TccDesCX::operator()() const {
	return *operator&();
}
inline TccDesCX::operator const SYTDesCX&() const {
	return *operator&();
}
inline TccDesCX::operator const SYTTRefDesCX() const {
	return *operator&();
}
inline const TccDesCX& TccDesCX::operator=(const SYTDesCX& aStr){
	return *(reinterpret_cast<const TccDesCX*>(&aStr));
}
*/
inline const SYTDesCX& TccDesCX::operator()() const {
	return *(reinterpret_cast<const SYTDesCX*>(this));
}
inline TccDesCX::operator const SYTDesCX&() const {
	return *(reinterpret_cast<const SYTDesCX*>(this));
}
#if !defined(__TccSymbianKernel__)
inline TccDesCX::operator const SYTTRefDesCX() const {
	return *(reinterpret_cast<const SYTDesCX*>(this));
}
#endif
inline const TccDesCX& TccDesCX::operator=(const SYTDesCX& aStr){
	return *(reinterpret_cast<const TccDesCX*>(&aStr));
}
inline const SYTDesCX* TccDesCX::TDesPtr() const {
	return reinterpret_cast<const SYTDesCX*>(this);
}
#endif

inline tbool TccDesCX::operator<(const TccDesCX &aDes) const {
	return (Compare(aDes) < 0);
}
inline tbool TccDesCX::operator<=(const TccDesCX &aDes) const {
	return (Compare(aDes) <= 0);
}
inline tbool TccDesCX::operator>(const TccDesCX &aDes) const {
	return (Compare(aDes) > 0);
}
inline tbool TccDesCX::operator>=(const TccDesCX &aDes) const {
	return (Compare(aDes) >= 0);
}
inline tbool TccDesCX::operator==(const TccDesCX &aDes) const {
	return (Compare(aDes) == 0);
}
inline tbool TccDesCX::operator!=(const TccDesCX &aDes) const {
	return (Compare(aDes) != 0);
}

inline tbool TccDesCX::Empty() const{
	return (tbool)(0 == (iLength & _TccStrMaskLength)); 
}

inline ti32 TccDesCX::Length() const {
	return (ti32)(iLength & _TccStrMaskLength);
}

inline ti32 TccDesCX::Compare(const tcc_cchar* aStr) const {
	return Compare((const tcc_tchar*)aStr, TccTcslen(aStr));
}
inline ti32 TccDesCX::Compare(const TccDesCX& aDes) const {
	return Compare(aDes.Ptr(), aDes.Length());
}

inline ti32 TccDesCX::Compare(ti32 aPos, const tcc_cchar* aStr) const {
	return Compare(aPos, (const tcc_tchar*)aStr, TccTcslen(aStr));
}
inline ti32 TccDesCX::Compare(ti32 aPos, const TccDesCX& aDes) const {
	return Compare(aPos, aDes.Ptr(), aDes.Length());
}

inline ti32 TccDesCX::CompareN(const tcc_cchar* aStr, ti32 aMaxCount) const {
	return CompareN((const tcc_tchar*)aStr, TccTcslen(aStr), aMaxCount);
}
inline ti32 TccDesCX::CompareN(const TccDesCX& aDes, ti32 aMaxCount) const {
	return CompareN(aDes.Ptr(), aDes.Length(), aMaxCount);
}

inline ti32 TccDesCX::CompareN(ti32 aPos, const tcc_cchar* aStr, ti32 aMaxCount) const {
	return CompareN(aPos, (const tcc_tchar*)aStr, TccTcslen(aStr), aMaxCount);
}
inline ti32 TccDesCX::CompareN(ti32 aPos, const TccDesCX& aDes, ti32 aMaxCount) const {
	return CompareN(aPos, aDes.Ptr(), aDes.Length(), aMaxCount);
}

inline ti32 TccDesCX::CompareF(const tcc_cchar* aStr) const {
	return CompareF((const tcc_tchar*)aStr, TccTcslen(aStr));
}
inline ti32 TccDesCX::CompareF(const TccDesCX &aDes) const {
	return CompareF(aDes.Ptr(), aDes.Length());
}

inline ti32 TccDesCX::CompareF(ti32 aPos, const tcc_cchar* aStr) const {
	return CompareF(aPos, (const tcc_tchar*)aStr, TccTcslen(aStr));
}
inline ti32 TccDesCX::CompareF(ti32 aPos, const TccDesCX &aDes) const {
	return CompareF(aPos, aDes.Ptr(), aDes.Length());
}

inline ti32 TccDesCX::CompareNF(const tcc_cchar* aStr, ti32 aMaxCount) const {
	return CompareNF((const tcc_tchar*)aStr, TccTcslen(aStr), aMaxCount);
}
inline ti32 TccDesCX::CompareNF(const TccDesCX &aDes, ti32 aMaxCount) const {
	return CompareNF(aDes.Ptr(), aDes.Length(), aMaxCount);
}

inline tbool TccDesCX::IsEndWith(const tcc_cchar* aStr) const {
	return IsEndWith((const tcc_tchar*)aStr, TccTcslen(aStr));
}
inline tbool TccDesCX::IsEndWith(const TccDesCX &aDes) const {
	return IsEndWith(aDes.Ptr(), aDes.Length());
}

inline ti32 TccDesCX::Find(const tcc_cchar* aStr, ti32 pos) const {
	return Find((const tcc_tchar*)aStr, TccTcslen(aStr), pos);
}
inline ti32 TccDesCX::Find(const TccDesCX &aDes, ti32 pos) const {
	return Find(aDes.Ptr(), aDes.Length(), pos);
}

inline ti32 TccDesCX::FindF(const tcc_cchar* aStr, ti32 pos) const {
	return FindF((const tcc_tchar*)aStr, TccTcslen(aStr), pos);
}
inline ti32 TccDesCX::FindF(const TccDesCX &aDes, ti32 pos) const {
	return FindF(aDes.Ptr(), aDes.Length(), pos);
}



inline ti32 TccDesCX::ScanList(tcc_rowstr aFmt, ti32 aLength, TccVaList aArgPtr)const{return ScanListP(0, aFmt, aLength, aArgPtr);}
inline ti32 TccDesCX::ScanList(const TccDesCX& aFmt, TccVaList aArgPtr)const{return ScanListP(0, aFmt.Ptr(), aFmt.Length(), aArgPtr);}
inline ti32 TccDesCX::ScanListP(ti32 aPos, const TccDesCX& aFmt, TccVaList aArgPtr)const{return ScanListP(aPos, aFmt.Ptr(), aFmt.Length(), aArgPtr);}
inline ti32 TccDesCX::ScanListP(ti32 aPos, tcc_rowstr aFmt, ti32 aLength, TccVaList aArgPtr)const{
#if defined(__TccUnicodeImplement__)
	return TccVScanfW(Ptr() + aPos, Length() - aPos, aFmt, aLength, aArgPtr);
#else
	return TccVScanfA(Ptr() + aPos, Length() - aPos, (const tu8*)aFmt, aLength, aArgPtr);
#endif
}



inline TccDesCX::TccDesCX(){}
inline TccDesCX::TccDesCX(tint aType, tint aLength) : iLength(aLength | (aType << _TccStrShiftType)) {

}
inline tint TccDesCX::Type() const{
	return (iLength >> _TccStrShiftType);
}

#if defined(_TccStrForceZeroTerminate)
inline void TccDesCX::DoSetLength(tint aType, tint aLength) const { iLength = (aLength | (aType << _TccStrShiftType));}
#endif


inline void TccDesCX::DoSetLength(ti32 aLength){
	iLength = (iLength & (~_TccStrMaskLength)) | aLength;
}
#if !defined(__TccUnicodeImplement__)
inline ti32 TccDesC8::StepLength(){
	iLength++;
	return (ti32)(iLength & _TccStrMaskLength) - 1;
}
#endif
	
//------------------------------------------------------------------
inline void TccDesX::Zero(){
	DoSetLength(0);
}

inline tcc_tchar* TccDesX::WPtr(){
	return (tcc_tchar*)Ptr();
}

inline ti32 TccDesX::MaxLength() const{
#if defined(_TccStrForceZeroTerminate)
	return (ti32)(iMaxLen);
#else
	return (ti32)(iMaxLen & _TccStrMaskLength);
#endif
}

inline void TccDesX::SetLength(ti32 aLength){
	TccAssert((aLength >= 0 && aLength <= MaxLength()));
	DoSetLength(aLength);
}

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
inline void TccDesX::CopyA(const SYTDesCX& aStr){CopyA((tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendA(const SYTDesCX& aStr){AppendA((tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::InsertA(ti32 aPos, const SYTDesCX& aStr){InsertA(aPos, (tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::ReplaceA(ti32 aPos, ti32 aLength, const SYTDesCX& aStr){ReplaceA(aPos, aLength, (tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::CopyA(const TagArrayStr& aStr){CopyA((tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendA(const TagArrayStr& aStr){AppendA((tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::InsertA(ti32 aPos, const TagArrayStr& aStr){InsertA(aPos, (tcc_rowstr)aStr.Ptr(), aStr.Length());}
inline void TccDesX::ReplaceA(ti32 aPos, ti32 aLength, const TagArrayStr& aStr){ReplaceA(aPos, aLength, (tcc_rowstr)aStr.Ptr(), aStr.Length());}
#endif

inline void TccDesX::CopyA(const TccDesCX& aStr){
	CopyA(aStr.Ptr(), aStr.Length());
}
inline void TccDesX::CopyA(const tcc_cchar* aStr){
	if(NULL == aStr){
		Zero();
	}
	else{
		CopyA(aStr, TccTcslen(aStr));
	}
}

inline void TccDesX::AppendA(const TccDesCX& aStr){
	AppendA(aStr.Ptr(), aStr.Length());
}
inline void TccDesX::AppendA(const tcc_cchar* aStr){
	if(NULL != aStr){
		AppendA(aStr, TccTcslen(aStr));
	}
}

inline void TccDesX::InsertA(ti32 aPos, const TccDesCX& aStr){
	InsertA(aPos, aStr.Ptr(), aStr.Length());
}
inline void TccDesX::InsertA(ti32 aPos, const tcc_cchar* aStr){
	if(NULL != aStr){
		InsertA(aPos, aStr, TccTcslen(aStr));
	}
}
inline void TccDesX::ReplaceA(ti32 aPos, ti32 aLength, const TccDesCX& aStr){
	ReplaceA(aPos, aLength, aStr.Ptr(), aStr.Length());
}
inline void TccDesX::ReplaceA(ti32 aPos, ti32 aLength, const tcc_cchar* aStr){
	if(NULL != aStr){
		ReplaceA(aPos, aLength, aStr, TccTcslen(aStr));
	}
	else{
		ReplaceA(aPos, aLength, aStr, 0);
	}
}

inline void TccDesX::FormatListA(tcc_rowstr aFmt, ti32 aLength, TccVaList aArgPtr){
	DoSetLength(0);
	AppendFormatListA(aFmt, aLength, aArgPtr);
}

inline void TccDesX::FormatListA(const TccDesCX& aFmt, TccVaList aArgPtr){
	DoSetLength(0);
	AppendFormatListA(aFmt.Ptr(), aFmt.Length(), aArgPtr);
}

inline void TccDesX::AppendFormatListA(const TccDesCX& aFmt, TccVaList aArgPtr){
	AppendFormatListA(aFmt.Ptr(), aFmt.Length(), aArgPtr);
}

inline void TccDesX::Trim(){
	TrimRight();
	TrimLeft();
}






#if !defined(__TccUnicodeImplement__)
inline terror TccDes8::XXTeaEncryptA(const TccDesC8& aKey){return XXTeaEncryptA(aKey.Ptr(), aKey.Length());}
inline terror TccDes8::XXTeaEncryptA(const tchar* aKey){return XXTeaEncryptA(aKey, TccStrlen(aKey));}
inline terror TccDes8::XXTeaDecrypt(const TccDesC8& aKey){return XXTeaDecrypt(aKey.Ptr(), aKey.Length());}
inline terror TccDes8::XXTeaDecrypt(const tchar* aKey){return XXTeaDecrypt(aKey, TccStrlen(aKey));}

inline terror TccDes8::DecodeBase64A(const TccDesC8& aStr){return DecodeBase64A(aStr.Ptr(), aStr.Length());}
inline terror TccDes8::DecodeBase64A(const tchar* aStr){return DecodeBase64A(aStr, TccStrlen(aStr));}
inline terror TccDes8::EncodeBase64A(const TccDesC8& aStr){return EncodeBase64A(aStr.Ptr(), aStr.Length());}
inline terror TccDes8::EncodeBase64A(const tchar* aStr){return EncodeBase64A(aStr, TccStrlen(aStr));}
inline terror TccDes8::AppendDecodeBase64A(const TccDesC8& aStr){return AppendDecodeBase64A(aStr.Ptr(), aStr.Length());}
inline terror TccDes8::AppendDecodeBase64A(const tchar* aStr){return AppendDecodeBase64A(aStr, TccStrlen(aStr));}
inline terror TccDes8::AppendEncodeBase64A(const TccDesC8& aStr){return AppendEncodeBase64A(aStr.Ptr(), aStr.Length());}
inline terror TccDes8::AppendEncodeBase64A(const tchar* aStr){return AppendEncodeBase64A(aStr, TccStrlen(aStr));}
inline terror TccDes8::AppendEncodeBase64A(ti32 aMaxlinelen, const TccDesC8& aStr){return AppendEncodeBase64A(aMaxlinelen, aStr.Ptr(), aStr.Length());}
inline terror TccDes8::AppendEncodeBase64A(ti32 aMaxlinelen, const tchar* aStr){return AppendEncodeBase64A(aMaxlinelen, aStr, TccStrlen(aStr));}


#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
inline void TccDesX::ToUtf8A(const TDesC16& aStr){ ToUtf8A((twchar*)(aStr.Ptr()), aStr.Length()); }
inline void TccDesX::ToUtf8A(const _tstr16& aStr){ ToUtf8A((twchar*)(aStr.Ptr()), aStr.Length()); }
inline void TccDesX::AppendToUtf8A(const TDesC16& aStr){AppendToUtf8A((const twchar*)aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendToUtf8A(const _tstr16& aStr){AppendToUtf8A((const twchar*)aStr.Ptr(), aStr.Length());}
#endif
inline void TccDesX::ToUtf8A(const TccDesC16& aStr){ToUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::ToUtf8A(const twchar* aStr){ToUtf8A(aStr, TccWcslen(aStr));}
inline void TccDesX::AppendToUtf8A(const TccDesC16& aStr){AppendToUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendToUtf8A(const twchar* aStr){AppendToUtf8A(aStr, TccWcslen(aStr));}
#if !defined(__TccSymbianTcbMode__)
#if defined(__TccSymbian__)
inline void TccDesX::ToGbkA(const TDesC16& aStr){ToGbkA((const twchar*)aStr.Ptr(), aStr.Length());}
inline void TccDesX::ToGbkA(const _tstr16& aStr){ToGbkA((const twchar*)aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendToGbkA(const TDesC16& aStr){AppendToGbkA((const twchar*)aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendToGbkA(const _tstr16& aStr){AppendToGbkA((const twchar*)aStr.Ptr(), aStr.Length());}
#endif
inline void TccDesX::ToGbkA(const TccDesC16& aStr){ToGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::ToGbkA(const twchar* aStr){ToGbkA(aStr, TccWcslen(aStr));}
inline void TccDesX::AppendToGbkA(const TccDesC16& aStr){AppendToGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendToGbkA(const twchar* aStr){AppendToGbkA(aStr, TccWcslen(aStr));}
#endif
#else

#if defined(__TccSymbian__)
inline void TccDesX::FromUtf8A(const TDesC8& aStr){FromUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::FromUtf8A(const _tstr8& aStr){FromUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromUtf8A(const TDesC8& aStr){AppendFromUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromUtf8A(const _tstr8& aStr){AppendFromUtf8A(aStr.Ptr(), aStr.Length());}
#endif
inline void TccDesX::FromUtf8A(const TccDesC8& aStr){FromUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::FromUtf8A(const tchar* aStr){FromUtf8A(aStr, TccStrlen(aStr));}
inline void TccDesX::AppendFromUtf8A(const TccDesC8& aStr){AppendFromUtf8A(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromUtf8A(const tchar* aStr){AppendFromUtf8A(aStr, TccStrlen(aStr));}
#if !defined(__TccSymbianTcbMode__)
#if defined(__TccSymbian__)
inline void TccDesX::FromGbkA(const TDesC8& aStr){FromGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::FromGbkA(const _tstr8& aStr){FromGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromGbkA(const TDesC8& aStr){AppendFromGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromGbkA(const _tstr8& aStr){AppendFromGbkA(aStr.Ptr(), aStr.Length());}
#endif
inline void TccDesX::FromGbkA(const TccDesC8& aStr){FromGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::FromGbkA(const tchar* aStr){FromGbkA(aStr, TccStrlen(aStr));}
inline void TccDesX::AppendFromGbkA(const TccDesC8& aStr){AppendFromGbkA(aStr.Ptr(), aStr.Length());}
inline void TccDesX::AppendFromGbkA(const tchar* aStr){AppendFromGbkA(aStr, TccStrlen(aStr));}
#endif
#endif


inline TccDesX::TccDesX(){}

#if defined(_TccStrForceZeroTerminate)
inline TccDesX::TccDesX(tint aType, tint aLength, tint aMaxLength) : TccDesCX(aType, aLength), iMaxLen(aMaxLength){ }
inline void TccDesX::DoSetMaxLen(ti32 aMaxLen){ iMaxLen = aMaxLen;}
#else
inline TccDesX::TccDesX(tint aType, tint aLength, tint aExType, tint aMaxLength) : TccDesCX(aType, aLength), iMaxLen(aMaxLength | (aExType << _TccStrShiftType)){ }
inline tint TccDesX::ExType() const { return (iMaxLen >> _TccStrShiftType);}
inline void TccDesX::DoSetMaxLen(ti32 aMaxLen){ iMaxLen = (iMaxLen & (~_TccStrMaskLength)) | aMaxLen;}
inline void TccDesX::DoSetMaxLen(tint aExType, ti32 aMaxLen){ iMaxLen = (aMaxLen | (aExType << _TccStrShiftType));}
#endif



inline TccDesX& TccDesX::operator=(const tcc_cchar *aStr){
	_TccLeaveIfError(CopyEx(aStr, TccTcslen(aStr)));
	return *this;
}
inline TccDesX& TccDesX::operator=(const TccDesCX& aStr){
	_TccLeaveIfError(CopyEx(aStr.Ptr(), aStr.Length()));
	return *this;
}
inline TccDesX& TccDesX::operator=(const TccDesX& aStr){
	_TccLeaveIfError(CopyEx(aStr.Ptr(), aStr.Length()));
	return *this;
}

//--------------------------------------------------------------
inline TccPtrCX& TccPtrCX::operator=(const TccPtrCX& aStr){
	DoSetLength(aStr.Length());
	iPtr = aStr.Ptr();
	return *this;
}

inline void TccPtrCX::Set(const TccDesCX& aStr){
	DoSetLength(aStr.Length());
	iPtr = aStr.Ptr();
}
inline void TccPtrCX::Set(const tcc_cchar* aStr){
	DoSetLength(TccTcslen(aStr));
	iPtr = (const tcc_tchar*)aStr;
}
inline void TccPtrCX::Set(tcc_rowstr aStr, ti32 aLength){
	DoSetLength(aLength);
	iPtr = (const tcc_tchar*)aStr;
}
#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
inline void TccPtrCX::Set(const SYTDesCX& aStr){
	DoSetLength(aStr.Length());
	iPtr = (const tcc_tchar*)aStr.Ptr();
}
inline void TccPtrCX::Set(const TagArrayStr& aStr){
	DoSetLength(aStr.Length());
	iPtr = (const tcc_tchar*)aStr.Ptr();
}
#endif

//--------------------------------------------------------------

#if defined(_TccStrForceZeroTerminate)
template<ti32 S>
TccBufX<S>::TccBufX() : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ }

template<ti32 S>
TccBufX<S>::TccBufX(const TccDesCX& aStr) : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ CopyA(aStr.Ptr(), aStr.Length()); }

template<ti32 S>
TccBufX<S>::TccBufX(const tcc_cchar* aStr) : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ CopyA(aStr, TccTcslen(aStr)); }

template<ti32 S>
TccBufX<S>::TccBufX(tcc_rowstr aStr, ti32 aLength) : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ CopyA(aStr, aLength);}

#if defined(__TccSymbian__)
template<ti32 S>
TccBufX<S>::TccBufX(const SYTDesCX& aStr) : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ CopyA((const tcc_tchar*)aStr.Ptr(), aStr.Length()); }
template<ti32 S>
TccBufX<S>::TccBufX(const TagArrayStr& aStr) : TccDesX(ETccStrBuf, 0, TccAlignStr(S + 1) - 1){ CopyA((const tcc_tchar*)aStr.Ptr(), aStr.Length()); }
#endif

#else
template<ti32 S>
TccBufX<S>::TccBufX() : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ }

template<ti32 S>
TccBufX<S>::TccBufX(const TccDesCX& aStr) : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ CopyA(aStr.Ptr(), aStr.Length()); }

template<ti32 S>
TccBufX<S>::TccBufX(const tcc_cchar* aStr) : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ CopyA(aStr, TccTcslen(aStr)); }

template<ti32 S>
TccBufX<S>::TccBufX(tcc_rowstr aStr, ti32 aLength) : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ CopyA(aStr, aLength);}

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
template<ti32 S>
TccBufX<S>::TccBufX(const SYTDesCX& aStr) : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ CopyA((const tcc_tchar*)aStr.Ptr(), aStr.Length()); }
template<ti32 S>
TccBufX<S>::TccBufX(const TagArrayStr& aStr) : TccDesX(ETccStrBuf, 0, ETccStrPtrConst, TccAlignStr(S + 1) - 1){ CopyA((const tcc_tchar*)aStr.Ptr(), aStr.Length()); }
#endif
#endif

template<ti32 S>
TccBufX<S>::~TccBufX(){}

template<ti32 S>
inline TccBufX<S>& TccBufX<S>::operator=(const tcc_cchar* aStr){
	_TccLeaveIfError(CopyEx(aStr, TccTcslen(aStr)));
	return *this;
}
template<ti32 S>
inline TccBufX<S>& TccBufX<S>::operator=(const TccDesCX& aDes){
	_TccLeaveIfError(CopyEx(aDes.Ptr(), aDes.Length()));
	return *this;
}
template<ti32 S>
inline TccBufX<S>& TccBufX<S>::operator=(const TccBufX<S>& aBuf){
	_TccLeaveIfError(CopyEx(aBuf.Ptr(), aBuf.Length()));
	return *this;
}

//----------------------------------------------------------------------
//TccPtrX
inline TccPtrX& TccPtrX::operator=(const tcc_cchar* aStr){
	_TccLeaveIfError(CopyEx(aStr, TccTcslen(aStr)));
	return *this;
}
inline TccPtrX& TccPtrX::operator=(const TccDesCX& aDes){
	_TccLeaveIfError(CopyEx(aDes.Ptr(), aDes.Length()));
	return *this;
}
inline TccPtrX& TccPtrX::operator=(const TccPtrX& aPtr){
	_TccLeaveIfError(CopyEx(aPtr.Ptr(), aPtr.Length()));
	return *this;
}


//--------------------------------------------------------------
//TccStr

inline TccStrX& TccStrX::operator=(const tcc_cchar* aStr){
	_TccLeaveIfError(Copy(aStr, TccTcslen(aStr)));
	return *this;
}
inline TccStrX& TccStrX::operator=(const TccDesCX& aDes){
	_TccLeaveIfError(Copy(aDes.Ptr(), aDes.Length()));
	return *this;
}
inline TccStrX& TccStrX::operator=(const TccStrX& aPtr){
	_TccLeaveIfError(Copy(aPtr.Ptr(), aPtr.Length()));
	return *this;
}

inline const tcc_tchar& TccStrX::operator[](ti32 anIndex) const {
	return iPtr[anIndex];
}

inline tcc_tchar& TccStrX::operator[](ti32 anIndex){
	return iPtr[anIndex];
}

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
inline terror TccStrX::Copy(const SYTDesCX& aStr){return Copy((const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Append(const SYTDesCX& aStr){return Append((const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Insert(ti32 aPos, const SYTDesCX& aStr){return Insert(aPos, (const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Replace(ti32 aPos, ti32 aLength, const SYTDesCX& aStr){return Replace(aPos, aLength, (const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Copy(const TagArrayStr& aStr){return Copy((const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Append(const TagArrayStr& aStr){return Append((const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Insert(ti32 aPos, const TagArrayStr& aStr){return Insert(aPos, (const tcc_tchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Replace(ti32 aPos, ti32 aLength, const TagArrayStr& aStr){return Replace(aPos, aLength, (const tcc_tchar*)aStr.Ptr(), aStr.Length());}
#endif

inline terror TccStrX::Copy(const TccDesCX& aStr){return Copy(aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Copy(const tcc_cchar* aStr){
	if(NULL == aStr){
		Zero();
		return _TccErrNone;
	}
	return Copy(aStr, TccTcslen(aStr));
}

inline terror TccStrX::Append(const TccDesCX& aStr){return Append(aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Append(const tcc_cchar* aStr){
	if(NULL == aStr){return _TccErrNone;}
	return Append(aStr, TccTcslen(aStr));
}

inline terror TccStrX::Insert(ti32 aPos, const TccDesCX& aStr){return Insert(aPos, aStr.Ptr(), aStr.Length());}
inline terror TccStrX::Insert(ti32 aPos, const tcc_cchar* aStr){
	if(NULL == aStr){
		return _TccErrNone;
	}
	return Insert(aPos, aStr, TccTcslen(aStr));
}

inline terror TccStrX::Replace(ti32 aPos, ti32 aLength, const TccDesCX& aStr){
	return Replace(aPos, aLength, aStr.Ptr(), aStr.Length());
}
inline terror TccStrX::Replace(ti32 aPos, ti32 aLength, const tcc_cchar* aStr){
	return Replace(aPos, aLength, aStr, TccTcslen(aStr));
}

inline terror TccStrX::FormatList(tcc_rowstr aFmt, ti32 aLength, TccVaList aArgPtr){
	DoSetLength(0);
	return AppendFormatList(aFmt, aLength, aArgPtr);
}
inline terror TccStrX::FormatList(const TccDesCX& aFmt, TccVaList aArgPtr){
	DoSetLength(0);
	return AppendFormatList(aFmt.Ptr(), aFmt.Length(), aArgPtr);
}
inline terror TccStrX::AppendFormatList(const TccDesCX& aFmt, TccVaList aArgPtr){
	return AppendFormatList(aFmt.Ptr(), aFmt.Length(), aArgPtr);
}


#if defined(__TccUnicodeImplement__)

#if defined(__TccSymbian__)
inline terror TccStr16::FromUtf8(const TDesC8& aStr){return FromUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromUtf8(const TDesC8& aStr){return AppendFromUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::FromUtf8(const _tstr8& aStr){return FromUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromUtf8(const _tstr8& aStr){return AppendFromUtf8(aStr.Ptr(), aStr.Length());}
#endif
inline terror TccStr16::FromUtf8(const TccDesC8& aStr){return FromUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::FromUtf8(const tchar* aStr){return FromUtf8(aStr, TccStrlen(aStr));}
inline terror TccStr16::AppendFromUtf8(const TccDesC8& aStr){return AppendFromUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromUtf8(const tchar* aStr){return AppendFromUtf8(aStr, TccStrlen(aStr));}
#if !defined(__TccSymbianTcbMode__)
#if defined(__TccSymbian__)
inline terror TccStr16::FromGbk(const TDesC8& aStr){return FromGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromGbk(const TDesC8& aStr){return AppendFromGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::FromGbk(const _tstr8& aStr){return FromGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromGbk(const _tstr8& aStr){return AppendFromGbk(aStr.Ptr(), aStr.Length());}
#endif
inline terror TccStr16::FromGbk(const TccDesC8& aStr){return FromGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::FromGbk(const tchar* aStr){return FromGbk(aStr, TccStrlen(aStr));}
inline terror TccStr16::AppendFromGbk(const TccDesC8& aStr){return AppendFromGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr16::AppendFromGbk(const tchar* aStr){return AppendFromGbk(aStr, TccStrlen(aStr));}
#endif
#else

#if defined(__TccSymbian__) && !defined(__TccSymbianKernel__)
inline terror TccStr8::ToUtf8(const TDesC16& aStr){return ToUtf8((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::ToUtf8(const _tstr16& aStr){return ToUtf8((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToUtf8(const TDesC16& aStr){return AppendToUtf8((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToUtf8(const _tstr16& aStr){return AppendToUtf8((const twchar*)aStr.Ptr(), aStr.Length());}
#endif
inline terror TccStr8::ToUtf8(const TccDesC16& aStr){return ToUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::ToUtf8(const twchar* aStr){return ToUtf8(aStr, TccWcslen(aStr));}
inline terror TccStr8::AppendToUtf8(const TccDesC16& aStr){return AppendToUtf8(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToUtf8(const twchar* aStr){return AppendToUtf8(aStr, TccWcslen(aStr));}
#if !defined(__TccSymbianTcbMode__)
#if defined(__TccSymbian__)
inline terror TccStr8::ToGbk(const TDesC16& aStr){return ToGbk((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToGbk(const TDesC16& aStr){return AppendToGbk((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::ToGbk(const _tstr16& aStr){return ToGbk((const twchar*)aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToGbk(const _tstr16& aStr){return AppendToGbk((const twchar*)aStr.Ptr(), aStr.Length());}
#endif
inline terror TccStr8::ToGbk(const TccDesC16& aStr){return ToGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::ToGbk(const twchar* aStr){return ToGbk(aStr, TccWcslen(aStr));}
inline terror TccStr8::AppendToGbk(const TccDesC16& aStr){return AppendToGbk(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendToGbk(const twchar* aStr){return AppendToGbk(aStr, TccWcslen(aStr));}
#endif
inline terror TccStr8::AppendDecodeBase64(const TccDesC8& aStr){return AppendDecodeBase64(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendDecodeBase64(const tchar* aStr){return AppendDecodeBase64(aStr, TccStrlen(aStr));}

inline terror TccStr8::AppendEncodeBase64(const TccDesC8& aStr){return AppendEncodeBase64(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendEncodeBase64(const tchar* aStr){return AppendEncodeBase64(aStr, TccStrlen(aStr));}

inline terror TccStr8::AppendEncodeBase64(ti32 aMaxlinelen, const TccDesC8& aStr){return AppendEncodeBase64(aMaxlinelen, aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendEncodeBase64(ti32 aMaxlinelen, const tchar* aStr){return AppendEncodeBase64(aMaxlinelen, aStr, TccStrlen(aStr));}

inline terror TccStr8::AppendEncodeQuotedPrintable(const TccDesC8& aStr){return AppendEncodeQuotedPrintable(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendEncodeQuotedPrintable(const tchar* aStr){return AppendEncodeQuotedPrintable(aStr, TccStrlen(aStr));}

inline terror TccStr8::AppendDecodeQuotedPrintable(const TccDesC8& aStr){return AppendDecodeQuotedPrintable(aStr.Ptr(), aStr.Length());}
inline terror TccStr8::AppendDecodeQuotedPrintable(const tchar* aStr){return AppendDecodeQuotedPrintable(aStr, TccStrlen(aStr));}


#endif


//--------------------------------------------------------------

template <int S>
inline const TccDesCX* TccLitCX<S>::operator&() const {
	return reinterpret_cast<const TccDesCX*>(this);
}
template <int S>
inline const TccDesCX& TccLitCX<S>::operator()() const {
	return *operator&();
}
template <int S>
inline TccLitCX<S>::operator const TccDesCX&() const {
	return *operator&();
}
template <int S>
inline TccLitCX<S>::operator const __TRefBStrCX() const {
	return *operator&();
}

#if defined(__TccSymbian__)
/*
template <int S>
inline const SYTDesCX* TccLitCX<S>::operator&() const {
	
}
template <int S>
inline const SYTDesCX& TccLitCX<S>::operator()() const {
	return *operator&();
}
*/
template <int S>
inline TccLitCX<S>::operator const SYTDesCX&() const {
	return *(reinterpret_cast<const SYTDesCX*>(this));
}
#if !defined(__TccSymbianKernel__)
template <int S>
inline TccLitCX<S>::operator const SYTTRefDesCX() const {
	return *(reinterpret_cast<const SYTDesCX*>(this));
//	return *operator&();
}
#endif
#endif

#undef __TccUnicodeImplement__
#undef tcc_cchar
#undef tcc_tchar
#undef tcc_rowstr
#undef TccDesCX
#undef TccDesX
#undef TccPtrCX
#undef TccPtrX
#undef TccBufX
#undef TccStrX
#undef TccLitCX
#undef TccTcslen
#undef TccAlignStr
#undef __TRefBStrCX
#undef SYTUintX
#undef SYTDesCX
#undef SYTPtrCX
#undef SYTTRefDesCX
#undef TagArrayStr





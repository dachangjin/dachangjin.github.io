//
//  TMFStatisticsManager+Protected.h
//  TMFStatistics
//
//  Created by hauzhong on 2020/3/2.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "TMFStatisticsManager.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^TMFStatisticsTrackEndPageBlock)(NSString *page);

@interface TMFStatisticsManager (Private)

#pragma mark - 页面统计事件

- (void)trackBeginPage:(NSString *)page configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

- (void)trackEndPage:(NSString *)page labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

- (void)trackApperPage:(NSString *)page;

- (void)trackDisapperPage:(NSString *)page labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

#pragma mark - 自定义统计事件

- (void)trackCustomKVEvent:(NSString *)eventID props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

- (void)trackCustomKVTimeIntervalEvent:(NSString *)eventID duration:(NSInteger)duration props:(nullable NSDictionary *)kvs labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

#pragma mark - 用户信息

- (void)setCustomUserID:(NSString *)customUserID labels:(nullable NSDictionary *)labels configuration:(nullable TMFStatisticsConfiguration *)configuration hybridH5:(BOOL)hybridH5;

@end

NS_ASSUME_NONNULL_END

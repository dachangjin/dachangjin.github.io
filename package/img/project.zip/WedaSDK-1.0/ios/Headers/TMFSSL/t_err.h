
#ifndef __TCC_ERROR_H__
#define __TCC_ERROR_H__



#if defined(_WIN32)
#include <time.h>
#include <crtdbg.h>
#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#endif

typedef int t_err;

#define Error_None					0
#define Error_No_Memory				-4
//#define ALLOCATION_MEMORY_FAIL       -10


#define INVALID_NULL_VALUE_INPUT     -5
#define INVALID_INPUT_LENGTH         -6
#define INVALID_NULL_OUTPUT		     -7

#define CREATE_SM2_KEY_PAIR_FAIL     -8
#define COMPUTE_SM3_DIGEST_FAIL      -9
#define COMPUTE_SM2_SIGNATURE_FAIL   -11
#define INVALID_SM2_SIGNATURE        -12
#define VERIFY_SM2_SIGNATURE_FAIL    -13
#define EC_POINT_IS_AT_INFINITY      -14
#define COMPUTE_SM2_CIPHERTEXT_FAIL  -15
#define COMPUTE_SM2_KDF_FAIL         -16
#define INVALID_SM2_CIPHERTEXT       -17
#define SM2_DECRYPT_FAIL             -18
#define INVALID_INPUT_KEY	         -19

#endif //__TCC_ERROR_H__

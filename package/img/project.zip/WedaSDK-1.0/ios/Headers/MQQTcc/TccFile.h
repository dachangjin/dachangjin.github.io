#ifndef __TCC_FILE_H_DEFINED__
#define __TCC_FILE_H_DEFINED__

#include "TccBase.h"
#include "TccString.h"
#include "TccTime.h"

#if defined(__TccWinMetroAPP__)
//metro app
#define _TccFileUseCRunTimeApi_
#elif defined(__TccWindows__)
#define _TccFileUseWindowsApi_
#elif defined(__TccSymbian__)
#define _TccFileUseSymbianApi_
#else
#define _TccFileUseCRunTimeApi_
#endif

//#define _TccFileUseCRunTimeApi_


#if defined(_TccFileUseSymbianApi_)
#include <f32file.h>
//#if defined(__AVKON_ELAF__) || defined(__AVKON_APAC__) 
#define _TccFileNeedGivenRFs_ //symbian
//#endif
#endif

#if defined(_TccFileUseWindowsApi_)
#include <windows.h>
#endif

/*
 CloseHandle This function closes an open object handle. 

 FindFirstFile This function searches a directory for a file or subdirectory whose name matches the specified file name.  
 FindFirstFileEx This function searches a directory for a file whose name and attributes match those specified in the function call. 
 FindNextFile This function continues a file search from a previous call to the FindFirstFile function.  
 FindClose This function closes the specified search handle. 

 CreateDirectory This function creates a new directory. 
 CopyFile This function copies an existing file to a new file. 
 CopyFileEx This function copies an existing file to a new file. 
 DeleteAndRenameFile This function deletes the source file after it copies the content of the source file to the destination file. 
 MoveFile This function renames an existing file or a directory, including all its children.  
 DeleteFile This function deletes an existing file from a file system. 
 RemoveDirectory This function deletes an existing empty directory. 

 FindFirstChangeNotification This function creates a change notification handle and sets up initial change notification filter conditions. 
 FindNextChangeNotification This function requests that the operating system (OS) signal a change notification handle the next time it detects an appropriate change.  
 FindCloseChangeNotification This function stops change notification handle monitoring.  

 GetDiskFreeSpaceEx This function obtains information about the amount of space available on a disk volume: the total amount of space, the total amount of free space, and the total amount of free space available to the user associated with the calling thread. 
 GetStoreInformation This function fills in a STORE_INFORMATION structure with the size of the object store and the amount of free space currently in the object store. 
 */

/*
 class TccFileServer
 {
 protected:
 public:
 ti8 MkDir(const TDesC& aPath);
 ti8 MkDirAll(const TDesC& aPath);
 ti8 RmDir(const TDesC& aPath);
 ti8 GetDir(const TDesC& aName,TUint anEntryAttMask,TUint anEntrySortKey,CDir*& anEntryList) const;
 ti8 GetDir(const TDesC& aName,TUint anEntryAttMask,TUint anEntrySortKey,CDir*& anEntryList,CDir*& aDirList) const;
 ti8 GetDir(const TDesC& aName,const TUidType& anEntryUid,TUint anEntrySortKey,CDir*& aFileList) const;
 ti8 Delete(const TDesC& aName);
 ti8 Rename(const TDesC& anOldName,const TDesC& aNewName);
 ti8 Replace(const TDesC& anOldName,const TDesC& aNewName);
 };
 */

/*
 GetFileAttributes This function returns attributes for a specified file or directory. 
 GetFileAttributesEx This function obtains attribute information about a specified file or directory. 
 GetFileInformationByHandle This function retrieves information about the specified file. 

 SetFileAttributes This function sets the attributes of a file. 
 SetEndOfFile This function moves the end-of-file position for the specified file to the current position of the file pointer. 
 SetFilePointer This function moves the file pointer of an open file. 

 LockFileEx This function locks the specified file for exclusive access by the calling process. 
 UnlockFileEx This function unlocks a region in an open file. Unlocking a region enables other processes to access the region. 
 ReadFile This function reads data from a file, starting at the position indicated by the file pointer. 
 WriteFile This function writes data to a file. 
 CreateFile This function creates, opens, or truncates a file, COM port, device, service, or console.  
 GetFileSize This function retrieves the size, in bytes, of the specified file. 
 GetFileVersionInfo This function returns version information about a specified file. 
 GetFileVersionInfoSize This function determines whether the operating system (OS) can obtain version information about a specified file. 
 FlushFileBuffers This function clears the buffers for the specified file and causes all buffered data to be written to the file. 

 GetTempPath This function retrieves the path of the directory designated for temporary files. 
 GetTempFileName This function creates a name for a temporary file. 
 */

#if defined(__TccWindows__) || defined(__TccSymbian__)

class TccDirSearch {

public:
	TCCIMPORT TccDirSearch();
	TCCIMPORT ~TccDirSearch();
#if !defined(__TccSymbian__)
	TCCIMPORT terror First(const TccDesC16& aPathName);
#else
	terror First(const TccDesC16& aPathName){
		return First(aPathName, KEntryAttNormal);
	}
#endif
	
	TCCIMPORT terror Next();
	TCCIMPORT void Close();


#if defined(__TccSymbian__)
	TCCIMPORT terror First(const TccDesC16& aPathName, TUint aMask);

#if defined(_TccFileNeedGivenRFs_)
	RFs iRfs;
#endif
	CDir* iDir;
	ti32 iPos;
	//	RDir iDir;
	//	TEntry iFindData;

	TCCIMPORT const TEntry& GetCurrItem();
	inline TccPtrC16 GetCurrItemName(){return 
		TccPtrC16(((*iDir)[iPos]).iName);
	}
	inline tbool CurrItemIsDirectory(){return ((*iDir)[iPos]).IsDir();}
	
#else //Win32
	HANDLE iDir;
	WIN32_FIND_DATAW iFindData;

	TCCIMPORT WIN32_FIND_DATAW* GetCurrItem();
	inline TccPtrC16 GetCurrItemName(){return TccPtrC16(iFindData.cFileName);}
	//inline tbool CurrItemIsDirectory(){return (tbool)(iFindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ? ttrue : tfalse);}
	inline tbool CurrItemIsDirectory(){return (0 != (iFindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY));}

#endif

	TCCIMPORT static ti32 GetDirFileList(const TccDesC16& strDir, const TccDesC16& strExt, tbool bGetDir, TccStr16** strFilelist);
};

#endif	// #if defined(__TccWindows__) || defined(__TccSymbian__)


class TccFile {
protected:

#if defined(_TccFileUseWindowsApi_)
	HANDLE iFile;
#elif defined(_TccFileUseSymbianApi_)
	RFile iFile;
#if defined(_TccFileNeedGivenRFs_)
	RFs iRfs;
#endif
#else //_TccFileUseCRunTimeApi_
	FILE* iFile;
#endif

public:

	TCCIMPORT TccFile();
	TCCIMPORT ~TccFile();

	enum EFileMode {
		EReadWrite = 0x0000,
		EReadOnly = 0x0001,
		EWriteOnly = 0x0002,
		EAppend = 0x0003
	};
	TCCIMPORT terror Open(const twchar* aFileName, EFileMode aMode);
	TCCIMPORT terror Open(const TccDesC8& aFileName, EFileMode aMode);
	TCCIMPORT terror Open(const TccDesC16& aFileName, EFileMode aMode);

	TCCIMPORT void Close();
	TCCIMPORT terror Flush();
	TCCIMPORT ti32 Size();

#if defined(_TccFileUseCRunTimeApi_)
	//typedef int TccFileSeek;
	enum TccFileSeek {
		EFileStart = SEEK_SET,
		EFileCurrent = SEEK_CUR,
		EFileEnd = SEEK_END
	};
#endif
#if defined(_TccFileUseWindowsApi_)
	//#define TccFileSeek DWORD
	enum TccFileSeek {
		EFileStart = FILE_BEGIN,
		EFileCurrent = FILE_CURRENT,
		EFileEnd = FILE_END
	};
#endif
#if defined(_TccFileUseSymbianApi_)
	//#define TccFileSeek			TSeek
	//#define EFileStart		ESeekStart
	//#define EFileCurrent	ESeekCurrent
	//#define EFileEnd		ESeekEnd
	enum TccFileSeek {
		EFileStart = ESeekStart,
		EFileCurrent = ESeekCurrent,
		EFileEnd = ESeekEnd
	};
#endif

	TCCIMPORT terror Seek(TccFileSeek aMode, ti32 aPos);
	inline terror SeekTo(ti32 aPos){return Seek(EFileStart, aPos);}


	//ftell
	TCCIMPORT ti32 PositionL();
	TCCIMPORT terror Position(ti32& aPos);

	//���ش��ڵ���0�Ƕ�������Ŀ, С��0�Ǵ�����,
	//�������ֵ������,������С��aNumberOfBytesToRead,��ô�����ļ���EOF��״̬��.
	TCCIMPORT ti32 Read(void* buf, ti32 aNumberOfBytesToRead);
	TCCIMPORT ti32 ReadA(TccDes8& aBuf, ti32 aNumberOfBytesToRead);
	TCCIMPORT ti32 ReadA(TccDes16& aBuf, ti32 aNumberOfWcharsToRead);
	TCCIMPORT ti32 Read(TccStr8& aBuf, ti32 aNumberOfBytesToRead);
	TCCIMPORT ti32 Read(TccStr16& aBuf, ti32 aNumberOfWcharsToRead);

	//���ش�����,�����ļ���β(EOF)��ʱ��,�᷵��һ��EOF��terror.
	TCCIMPORT terror ReadExact(void* buf, ti32 aNumberOfBytesToRead);
	TCCIMPORT terror ReadExactA(TccDes8& aBuf, ti32 aNumberOfBytesToRead);
	TCCIMPORT terror ReadExactA(TccDes16& aBuf, ti32 aNumberOfWcharsToRead);
	TCCIMPORT terror ReadExact(TccStr8& aBuf, ti32 aNumberOfBytesToRead);
	TCCIMPORT terror ReadExact(TccStr16& aBuf, ti32 aNumberOfWcharsToRead);

	//����terror,Ҫ��ȫ��д��...
	TCCIMPORT terror Write(const void* aBuf, ti32 aWriteSize);
	TCCIMPORT terror Write(const TccDesC8& aBuf);
	TCCIMPORT terror Write(const TccDesC16& aBuf);

	TCCIMPORT static tbool IsFileExist(const TccDesC16& szPath);
	TCCIMPORT static tbool IsFileExist(const TccDesC16& szDir, const TccDesC16& szName);

	TCCIMPORT static terror MkDirAll(const TccDesC16& szDir);
	TCCIMPORT static void MkDirAllL(const TccDesC16& szDir);

	
	TCCIMPORT static terror CopyFile(const TccDesC16& aFileSrcPath1, const TccDesC16& aFileDesPath2);	
	TCCIMPORT static terror DeleteFile(const TccDesC16& aFileName);
	TCCIMPORT static void DeleteFileL(const TccDesC16& aFileName);
	//static QBOOL DeleteFile(const TccDesC16& aFilePath, const TccDesC16& aFileName);
	TCCIMPORT static terror RenameFile(const TccDesC16& aOldFileName, const TccDesC16& aNewFileName);
	TCCIMPORT static void RenameFileL(const TccDesC16& aOldFileName, const TccDesC16& aNewFileName);

	TCCIMPORT static terror GetModifyTime(const TccDesC16& aOldFileName, TccTime& aTime);
	
	TCCIMPORT static terror Rmdir(const TccDesC16& aDirPath); // �ݹ�ɾ���ļ��������еĶ���

	/** ��ȡ�洢���̷� Get the first removable drive
	* @return the first removable drive, or KErrNotFound if not found
	*/
	TCCIMPORT static ti32 FirstRemovableDriveL();


	/*
	ti8 Create();
	ti8 Temp(); //Creates and opens a temporary file with a unique name for writing and reading.
	ti8 Replace();
	*/

	//	ChangeMode(); //Switches an open file's access mode between EFileShareExclusive and EFileShareReadersOnly (allowing or disallowing read-only access by other files without having to close and re-open the file).

	//Modified(); //modify time
	//SetModified(); //modify time

	//Att(); 
	//SetAtt();
	//Set(); //Sets the file's attributes and the date and time it was last modified. It combines the SetAtt() and SetModified() functions. The function uses two bitmasks, the first of which controls which attributes should be set, and the second controls which attributes should be cleared.
	//SetSize();

	//	Lock();
	//	UnLock();

#if 0

	enum SeekPosition {begin = 0x0, current = 0x1, end = 0x2};

	EXPORT_C virtual QBOOL Open( LPCWSTR lpFileName , QUINT nOpenFlags);
	EXPORT_C virtual QBOOL Open( CQSString& strFileName , QUINT nOpenFlags);
	EXPORT_C virtual void Close();

	EXPORT_C virtual QINT Read(void* lpBuf, QUINT nCount);
	EXPORT_C virtual QINT Write(const void* lpBuf, QUINT nCount);

	EXPORT_C virtual QBOOL Seek(QINT lOff, QUINT nFrom);
	EXPORT_C virtual QUINT GetLength() const;

	EXPORT_C QBOOL SeekToBegin();
	EXPORT_C QBOOL SeekToEnd();

	//static Operators
	EXPORT_C static QBOOL DeleteFile(LPCWSTR lpFileName);
	EXPORT_C static QBOOL DeleteFile(LPCWSTR lpFilePath , LPCWSTR lpFileName);
	EXPORT_C static QBOOL RenameFile(LPCWSTR lpOldFileName ,LPCWSTR lpNewFileName);
	EXPORT_C static QBOOL CopyFile(LPCWSTR lpSrcFilePath , LPCWSTR lpDstFilePath);

	EXPORT_C static QBOOL GetFileName(CQWString * pFilePath , CQWString & strFileName);
	//    EXPORT_C static QBOOL  GetDirName(CQWString * pFilePath , CQWString & strDirName) ;
	//    EXPORT_C static QBOOL  GetDriverName(CQWString * pFilePath , CQWString & strDirverName) ;

	EXPORT_C static QBOOL CreateDirectory(LPCWSTR szPath);
	EXPORT_C static QBOOL DelDir(LPCWSTR lpFileName);
	EXPORT_C static QINT GetCurrentDiskFreeSpace();

	EXPORT_C static QBOOL IsValidName(LPCWSTR szPath);

	EXPORT_C static QINT GetFileLenght(LPCWSTR szDir, LPCWSTR szName);

	//Caller should del strFilelist[]
	EXPORT_C static QINT GetDir(CQWString& strDir, CQWString** strFilelist);

private:
	QBOOL Open( TDesC& desFileName , QUINT nOpenFlags);

private:
	QUINT m_fileMode;
	QBOOL m_bOpen;

	//for symbian file system
	RFs m_objFs;
	RFile m_objFile;
#endif

};


typedef TccBuf16<0x100> TccPath;

/*

 GetModuleFileName

 static inline void GetAppPath(TDes &aPath) {
 TParse parse;
 aPath = CEikonEnv::Static()->EikAppUi()->Application()->AppFullName();
 #if defined(__WINS__) && (__TccSymbianEka1__)
 parse.Set(_L("c:"), &aPath, NULL);
 #else
 parse.Set(aPath, NULL, NULL);
 #endif

 #if (__TccSymbianEka2__)
 CCoeEnv::Static()->FsSession().PrivatePath(aPath);
 aPath.Insert(0, parse.Drive());
 #else
 aPath = parse.DriveAndPath();
 #endif // __TccSymbian__

 }

 */

#endif //__TCC_FILE_H_DEFINED__

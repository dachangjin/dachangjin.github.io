#ifndef __TCC_TAG_TYPE_H_DEFINE__
#define __TCC_TAG_TYPE_H_DEFINE__

#include "TccString.h"

//Ϊ�˽��s60��1,2�汾û��ԭ��64λ���͵���������ڵ�
typedef union __tti64 {  
	struct {
		tu32 iLow;
		ti32 iHigh;
	} l;
	struct {
		tu32 iLow;
		tu32 iHigh;
	} u;
#if !defined(__TccSymbianEka1__)
	ti64 iQuadPart;
	inline operator ti64()const{return iQuadPart;}
#else
	inline operator TInt64()const{return TInt64(u.iHigh, u.iLow);}
#endif

} _tti64;
typedef _tti64 _ttime;

//2��������
struct _tbinary{
	ti32 iLen;
	void* iData;
};


class TccTagData;

//8λ�ַ���,Ϊ�˿��Է���union������...��tcc����ַ����������,Ҫ�ı����tcc����ַ�����������
class _tstr8{
private:
	tu32 iLen;
	const tchar* iData;
protected:
	friend class TccTagData;
	inline void Set(const void* aPtr, ti32 aLen){
		iData = (const tchar*)aPtr; 
		iLen = (aLen | (ETccStrPtrC << _TccStrShiftType));
	}
public:
	inline const tchar* Ptr() const {return iData;}
	inline ti32 Length() const {return (ti32)(iLen & _TccStrMaskLength);}
	inline const TccDesC8* operator&() const {return reinterpret_cast<const TccDesC8*>(this);}
	inline const TccDesC8& operator()() const {return *operator&();}
	inline operator const TccDesC8&() const {return *operator&();}
	inline operator const __TRefStrC8() const {return *operator&();}
#if defined(__TccSymbian__)
	//inline const TDesC8& Des() const {return *(reinterpret_cast<const TccDesC8*>(this));}
	inline operator const TDesC8&() const {return *(reinterpret_cast<const TccDesC8*>(this));}
#if !defined(__TccSymbianKernel__)
	inline operator const __TRefDesC8() const {return *(reinterpret_cast<const TccDesC8*>(this));}
#endif
#endif
	inline void Clear(){
#if defined(_TccStrForceZeroTerminate)
		if(ETccStrPtrCAlloc == (iLen >> _TccStrShiftType)){ delete []iData; }
#endif
		iData = NULL;
		iLen = (0 | (ETccStrPtrC << _TccStrShiftType));
	}
};

//16λ�ַ���,Ϊ�˿��Է���union������...��tcc����ַ����������,Ҫ�ı����tcc����ַ�����������
class _tstr16{
private:
	tu32 iLen;
	const twchar* iData;
protected:
	friend class TccTagData;
	inline void Set(const void* aPtr, ti32 aLen){
		iData = (const twchar*)aPtr;
		iLen = ((aLen / sizeof(twchar)) | (ETccStrPtrC << _TccStrShiftType));
	}
public:
	inline const twchar* Ptr() const {return iData;}
	inline ti32 Length() const {return (ti32)(iLen & _TccStrMaskLength);}
	inline const TccDesC16* operator&() const {return reinterpret_cast<const TccDesC16*>(this);}
	inline const TccDesC16& operator()() const {return *operator&();}
	inline operator const TccDesC16&() const {return *operator&();}
	inline operator const __TRefStrC16() const {return *operator&();}
#if defined(__TccSymbian__)
	//inline const TDesC16& Des() const {return *(reinterpret_cast<const TccDesC16*>(this));}
	inline operator const TDesC16&() const {return *(reinterpret_cast<const TccDesC16*>(this));}
#if !defined(__TccSymbianKernel__)
	inline operator const __TRefDesC16() const {return *(reinterpret_cast<const TccDesC16*>(this));}
#endif
#endif
	inline void Clear(){
#if defined(_TccStrForceZeroTerminate)
		if(ETccStrPtrCAlloc == (iLen >> _TccStrShiftType)){ delete []iData; }
#endif
		iData = NULL;
		iLen = (0 | (ETccStrPtrC << _TccStrShiftType));
	}
};

struct _tm_float{
	ti32 iNum;
	float* iData;
};

struct _tm_doulbe{
	ti32 iNum;
	double* iData;
};

struct _tm_ti16{
	ti32 iNum;
	ti16* iData;
};

struct _tm_ti32{
	ti32 iNum;
	ti32* iData;
};

struct _tm_ti64{
	ti32 iNum;
	_tti64* iData;
};

struct _tm_tu16{
	ti32 iNum;
	tu16* iData;
};

struct _tm_tu32{
	ti32 iNum;
	tu32* iData;
};

struct _tm_binary{
	ti32 iNum;
	_tbinary* iPtrBuf;
};

struct _tm_str8{
	ti32 iNum;
	_tstr8* iPtrBuf;
};

struct _tm_str16{
	ti32 iNum;
	_tstr16* iPtrBuf;
};

#endif //__TCC_TAG_TYPE_H_DEFINE__




//
//  WAJSCustomTestHandler.m
//  WadaExtensionTest
//
//  Created by tommywwang on 2021/11/8.
//

#import "WAJSCustomTestHandler.h"

@implementation WAJSCustomTestHandler


/// 支持的方法集合
- (NSArray<NSString *> *)supportMethods
{
    return @[@"test"];
}

/// 处理事件
/// @param event 事件
- (void)handleEvent:(WAJSCustomEvent *)event
{
    if ([event.funcName isEqualToString:@"test"]) {
        NSLog(@"receive test");
        event.callback(nil);
    }
}

@end

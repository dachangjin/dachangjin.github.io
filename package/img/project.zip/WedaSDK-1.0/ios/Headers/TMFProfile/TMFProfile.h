//  TMFProfile.h
//
//  Created by bentonxiu on _08/05/2019_.
//  Copyright © _2019_ Tencent. All rights

#ifndef TMFProfile_h
#define TMFProfile_h

#import "TMFProfileDefines.h"
#import "TMFProfileReporter.h"

#endif /* TMFProfile_h */
